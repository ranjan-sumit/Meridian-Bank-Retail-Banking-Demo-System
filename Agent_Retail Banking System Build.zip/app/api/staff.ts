import { z } from "zod";
import { and, desc, eq, like, or, sql, count, gte, inArray } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, staffProcedure, managerProcedure } from "./middleware";
import { getDb } from "./queries/connection";
import {
  accounts,
  alerts,
  auditLog,
  branches,
  cards,
  customers,
  employees,
  kycCases,
  loans,
  loanPayments,
  loanProducts,
  transactions,
} from "@db/schema";
import { appendAudit } from "./queries/audit";

const num = (v: string | number | null) => (v == null ? 0 : Number(v));
const PAGE = 20;

export const staffRouter = createRouter({
  dashboardKpis: staffProcedure.query(async () => {
    const db = getDb();
    const [{ deposits }] = await db
      .select({ deposits: sql<string>`COALESCE(SUM(${accounts.balance}),0)` })
      .from(accounts)
      .where(inArray(accounts.type, ["checking", "savings"]));
    const [{ activeLoans, loanVolume }] = await db
      .select({
        activeLoans: count(),
        loanVolume: sql<string>`COALESCE(SUM(${loans.remainingBalance}),0)`,
      })
      .from(loans)
      .where(inArray(loans.status, ["active", "delinquent"]));
    const [{ pendingKyc }] = await db
      .select({ pendingKyc: count() })
      .from(kycCases)
      .where(inArray(kycCases.status, ["pending", "under_review"]));
    const [{ flaggedTxns }] = await db
      .select({ flaggedTxns: count() })
      .from(transactions)
      .where(eq(transactions.status, "flagged"));
    const [{ openAlerts }] = await db
      .select({ openAlerts: count() })
      .from(alerts)
      .where(inArray(alerts.status, ["open", "investigating"]));
    // 30-day daily deposit (cr) series
    const since = new Date(Date.UTC(2025, 0, 15));
    const series = await db
      .select({
        day: sql<string>`DATE_FORMAT(${transactions.occurredAt}, '%Y-%m-%d')`,
        total: sql<string>`COALESCE(SUM(${transactions.amount}),0)`,
      })
      .from(transactions)
      .where(and(eq(transactions.direction, "cr"), gte(transactions.occurredAt, since)))
      .groupBy(sql`DATE_FORMAT(${transactions.occurredAt}, '%Y-%m-%d')`)
      .orderBy(sql`DATE_FORMAT(${transactions.occurredAt}, '%Y-%m-%d')`);
    return {
      totalDeposits: num(deposits),
      activeLoans: Number(activeLoans),
      loanVolume: num(loanVolume),
      pendingKyc: Number(pendingKyc),
      flaggedTxns: Number(flaggedTxns),
      openAlerts: Number(openAlerts),
      depositSeries: series.map((r) => ({ day: r.day, total: num(r.total) })),
    };
  }),

  listCustomers: staffProcedure
    .input(
      z.object({
        search: z.string().optional(),
        status: z.enum(["verified", "pending", "under_review", "rejected"]).optional(),
        page: z.number().min(1).default(1),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conds = [];
      if (input.search) {
        const q = `%${input.search}%`;
        conds.push(or(
          like(customers.firstName, q), like(customers.lastName, q),
          like(customers.email, q), like(customers.customerNo, q),
        )!);
      }
      if (input.status) conds.push(eq(customers.kycStatus, input.status));
      const where = conds.length ? and(...conds) : undefined;
      const [{ total }] = await db.select({ total: count() }).from(customers).where(where);
      const rows = await db
        .select({ customer: customers, branch: branches })
        .from(customers)
        .leftJoin(branches, eq(customers.branchId, branches.id))
        .where(where)
        .orderBy(customers.lastName)
        .limit(PAGE)
        .offset((input.page - 1) * PAGE);
      return { customers: rows.map((r) => ({ ...r.customer, branch: r.branch })), total, page: input.page, pageSize: PAGE };
    }),

  customer360: staffProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [cust] = await db
        .select({ customer: customers, branch: branches })
        .from(customers)
        .leftJoin(branches, eq(customers.branchId, branches.id))
        .where(eq(customers.id, input.id))
        .limit(1);
      if (!cust) throw new TRPCError({ code: "NOT_FOUND", message: "Customer not found" });
      const accts = await db.select().from(accounts).where(eq(accounts.customerId, input.id));
      const custCards = await db.select().from(cards).where(eq(cards.customerId, input.id));
      const custLoans = await db
        .select({ loan: loans, product: loanProducts })
        .from(loans)
        .innerJoin(loanProducts, eq(loans.productId, loanProducts.id))
        .where(eq(loans.customerId, input.id));
      const kyc = await db.select().from(kycCases).where(eq(kycCases.customerId, input.id)).orderBy(desc(kycCases.submittedAt));
      const recentTxns = await db
        .select({ txn: transactions, accountNickname: accounts.nickname, accountLast4: accounts.last4 })
        .from(transactions)
        .innerJoin(accounts, eq(transactions.accountId, accounts.id))
        .where(eq(accounts.customerId, input.id))
        .orderBy(desc(transactions.occurredAt))
        .limit(15);
      const custAlerts = await db.select().from(alerts).where(eq(alerts.customerId, input.id)).orderBy(desc(alerts.createdAt));
      const audit = await db
        .select()
        .from(auditLog)
        .where(eq(auditLog.entityId, cust.customer.customerNo))
        .orderBy(desc(auditLog.createdAt))
        .limit(20);
      return {
        customer: { ...cust.customer, branch: cust.branch },
        accounts: accts,
        cards: custCards,
        loans: custLoans.map((r) => ({ ...r.loan, product: r.product })),
        kycCases: kyc,
        recentTransactions: recentTxns.map((r) => ({ ...r.txn, accountNickname: r.accountNickname, accountLast4: r.accountLast4 })),
        alerts: custAlerts,
        auditTrail: audit,
      };
    }),

  kycQueue: staffProcedure
    .input(z.object({ status: z.enum(["pending", "under_review", "approved", "rejected"]).optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      const where = input.status ? eq(kycCases.status, input.status) : inArray(kycCases.status, ["pending", "under_review"]);
      return db
        .select({ kycCase: kycCases, customer: customers })
        .from(kycCases)
        .innerJoin(customers, eq(kycCases.customerId, customers.id))
        .where(where)
        .orderBy(desc(kycCases.submittedAt))
        .then((rows) => rows.map((r) => ({ ...r.kycCase, customer: r.customer })));
    }),

  reviewKyc: staffProcedure
    .input(
      z.object({
        caseId: z.number(),
        approve: z.boolean(),
        reason: z.string().max(255).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [kase] = await db.select().from(kycCases).where(eq(kycCases.id, input.caseId)).limit(1);
      if (!kase) throw new TRPCError({ code: "NOT_FOUND", message: "KYC case not found" });
      if (kase.level === "enhanced" && ctx.session.role === "teller") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Enhanced due diligence requires manager or admin" });
      }
      if (!input.approve && !input.reason) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Rejection reason required" });
      }
      const status = input.approve ? "approved" : "rejected";
      await db.update(kycCases).set({
        status, reviewedBy: ctx.session.name, reviewedAt: new Date(),
        rejectionReason: input.approve ? null : input.reason!,
      }).where(eq(kycCases.id, kase.id));
      await db.update(customers).set({
        kycStatus: input.approve ? "verified" : "rejected",
      }).where(eq(customers.id, kase.customerId));
      await appendAudit({
        actorType: "staff", actorName: ctx.session.name,
        action: input.approve ? "kyc.approved" : "kyc.rejected",
        entityType: "kycCase", entityId: kase.caseNo,
        detail: input.approve ? "KYC case approved." : `KYC rejected: ${input.reason}`,
      });
      return { ok: true, status };
    }),

  monitoringTxns: staffProcedure
    .input(
      z.object({
        search: z.string().optional(),
        status: z.enum(["posted", "pending", "flagged"]).optional(),
        type: z.string().optional(),
        page: z.number().min(1).default(1),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conds = [];
      if (input.search) {
        const q = `%${input.search}%`;
        conds.push(or(
          like(transactions.description, q), like(transactions.merchant, q),
          like(transactions.txnId, q), like(customers.lastName, q),
        )!);
      }
      if (input.status) conds.push(eq(transactions.status, input.status));
      if (input.type) conds.push(eq(transactions.type, input.type as never));
      const where = conds.length ? and(...conds) : undefined;
      const base = db
        .select({ txn: transactions, account: accounts, customer: customers })
        .from(transactions)
        .innerJoin(accounts, eq(transactions.accountId, accounts.id))
        .innerJoin(customers, eq(accounts.customerId, customers.id));
      const [{ total }] = await db
        .select({ total: count() })
        .from(transactions)
        .innerJoin(accounts, eq(transactions.accountId, accounts.id))
        .innerJoin(customers, eq(accounts.customerId, customers.id))
        .where(where);
      const rows = await base.where(where).orderBy(desc(transactions.occurredAt)).limit(PAGE).offset((input.page - 1) * PAGE);
      return {
        transactions: rows.map((r) => ({
          ...r.txn, accountNickname: r.account.nickname, accountLast4: r.account.last4,
          customerName: `${r.customer.firstName} ${r.customer.lastName}`, customerNo: r.customer.customerNo,
        })),
        total, page: input.page, pageSize: PAGE,
      };
    }),

  flaggedQueue: staffProcedure.query(async () => {
    const db = getDb();
    const rows = await db
      .select({ txn: transactions, account: accounts, customer: customers })
      .from(transactions)
      .innerJoin(accounts, eq(transactions.accountId, accounts.id))
      .innerJoin(customers, eq(accounts.customerId, customers.id))
      .where(eq(transactions.status, "flagged"))
      .orderBy(desc(transactions.occurredAt));
    return rows.map((r) => ({
      ...r.txn, accountNickname: r.account.nickname, accountLast4: r.account.last4,
      customerName: `${r.customer.firstName} ${r.customer.lastName}`, customerNo: r.customer.customerNo,
    }));
  }),

  listAlerts: staffProcedure
    .input(z.object({ status: z.enum(["open", "investigating", "resolved", "dismissed"]).optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      const where = input.status ? eq(alerts.status, input.status) : undefined;
      const rows = await db
        .select({ alert: alerts, customer: customers })
        .from(alerts)
        .innerJoin(customers, eq(alerts.customerId, customers.id))
        .where(where)
        .orderBy(desc(alerts.createdAt));
      return rows.map((r) => ({
        ...r.alert,
        customerName: `${r.customer.firstName} ${r.customer.lastName}`, customerNo: r.customer.customerNo,
      }));
    }),

  updateAlert: staffProcedure
    .input(z.object({
      id: z.number(),
      status: z.enum(["open", "investigating", "resolved", "dismissed"]),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [alert] = await db.select().from(alerts).where(eq(alerts.id, input.id)).limit(1);
      if (!alert) throw new TRPCError({ code: "NOT_FOUND", message: "Alert not found" });
      await db.update(alerts).set({ status: input.status, assignedTo: ctx.session.name }).where(eq(alerts.id, alert.id));
      await appendAudit({
        actorType: "staff", actorName: ctx.session.name, action: "alert.status_changed",
        entityType: "alert", entityId: alert.alertNo,
        detail: `Alert ${alert.alertNo} moved ${alert.status} → ${input.status}.`,
      });
      return { ok: true };
    }),

  loanQueue: staffProcedure
    .input(z.object({ status: z.enum(["pending", "approved", "rejected", "active", "delinquent", "paid_off"]).optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      const where = input.status ? eq(loans.status, input.status) : undefined;
      const rows = await db
        .select({ loan: loans, product: loanProducts, customer: customers })
        .from(loans)
        .innerJoin(loanProducts, eq(loans.productId, loanProducts.id))
        .innerJoin(customers, eq(loans.customerId, customers.id))
        .where(where)
        .orderBy(desc(loans.appliedAt));
      return rows.map((r) => ({
        ...r.loan, product: r.product,
        customerName: `${r.customer.firstName} ${r.customer.lastName}`, customerNo: r.customer.customerNo,
      }));
    }),

  decideLoan: managerProcedure
    .input(z.object({ loanId: z.number(), approve: z.boolean(), reason: z.string().max(255).optional() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [loan] = await db.select().from(loans).where(eq(loans.id, input.loanId)).limit(1);
      if (!loan) throw new TRPCError({ code: "NOT_FOUND", message: "Loan not found" });
      if (loan.status !== "pending" && loan.status !== "approved") {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Loan is already ${loan.status}` });
      }
      if (!input.approve && !input.reason) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Rejection reason required" });
      }
      const status = input.approve ? "approved" : "rejected";
      const now = new Date();
      await db.update(loans).set({
        status, decidedAt: now, decidedBy: ctx.session.name,
        disbursementAt: input.approve ? now : null,
      }).where(eq(loans.id, loan.id));
      if (input.approve) {
        // generate amortization schedule
        const r = num(loan.rateApr) / 1200;
        const pmt = num(loan.monthlyPayment);
        let bal = num(loan.principal);
        const rows = [];
        for (let i = 1; i <= loan.termMonths; i++) {
          const interest = +(bal * r).toFixed(2);
          const principalPart = +(pmt - interest).toFixed(2);
          const due = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + i, 1));
          rows.push({
            loanId: loan.id, dueDate: due.toISOString().slice(0, 10),
            amount: pmt.toFixed(2), principalPart: principalPart.toFixed(2), interestPart: interest.toFixed(2),
            status: "due" as const,
          });
          bal = +(bal - principalPart).toFixed(2);
          if (i >= loan.termMonths) break;
        }
        // insert in chunks
        for (let i = 0; i < rows.length; i += 120) {
          await db.insert(loanPayments).values(rows.slice(i, i + 120));
        }
      }
      await appendAudit({
        actorType: "staff", actorName: ctx.session.name,
        action: input.approve ? "loan.approved" : "loan.rejected",
        entityType: "loan", entityId: loan.loanNo,
        detail: input.approve ? `Loan ${loan.loanNo} approved and schedule generated.` : `Loan rejected: ${input.reason}`,
      });
      return { ok: true, status };
    }),

  cardRequests: staffProcedure.query(async () => {
    const db = getDb();
    const rows = await db
      .select({ card: cards, customer: customers })
      .from(cards)
      .innerJoin(customers, eq(cards.customerId, customers.id))
      .where(eq(cards.status, "pending"))
      .orderBy(desc(cards.issuedAt));
    return rows.map((r) => ({ ...r.card, customerName: `${r.customer.firstName} ${r.customer.lastName}`, customerNo: r.customer.customerNo }));
  }),

  listCards: staffProcedure.query(async () => {
    const db = getDb();
    const rows = await db
      .select({ card: cards, customer: customers })
      .from(cards)
      .innerJoin(customers, eq(cards.customerId, customers.id))
      .orderBy(desc(cards.issuedAt));
    return rows.map((r) => ({ ...r.card, customerName: `${r.customer.firstName} ${r.customer.lastName}`, customerNo: r.customer.customerNo }));
  }),

  decideCardRequest: staffProcedure
    .input(z.object({ cardId: z.number(), approve: z.boolean(), reason: z.string().max(255).optional() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [card] = await db.select().from(cards).where(eq(cards.id, input.cardId)).limit(1);
      if (!card) throw new TRPCError({ code: "NOT_FOUND", message: "Card not found" });
      if (card.status !== "pending") throw new TRPCError({ code: "BAD_REQUEST", message: "Card is not pending issuance" });
      const status = input.approve ? "active" : "blocked";
      await db.update(cards).set({ status }).where(eq(cards.id, card.id));
      await appendAudit({
        actorType: "staff", actorName: ctx.session.name,
        action: input.approve ? "card.issued" : "card.request_rejected",
        entityType: "card", entityId: `card-${card.last4}`,
        detail: input.approve ? `Card ••••${card.last4} issued to ${card.holder}.` : `Issuance rejected: ${input.reason ?? "n/a"}`,
      });
      return { ok: true, status };
    }),

  setCardStatus: staffProcedure
    .input(z.object({ cardId: z.number(), status: z.enum(["active", "frozen", "blocked"]) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [card] = await db.select().from(cards).where(eq(cards.id, input.cardId)).limit(1);
      if (!card) throw new TRPCError({ code: "NOT_FOUND", message: "Card not found" });
      await db.update(cards).set({ status: input.status }).where(eq(cards.id, card.id));
      await appendAudit({
        actorType: "staff", actorName: ctx.session.name, action: `card.${input.status}`,
        entityType: "card", entityId: `card-${card.last4}`,
        detail: `Card ••••${card.last4} set to ${input.status} by staff.`,
      });
      return { ok: true };
    }),

  listEmployees: staffProcedure.query(async () => {
    const db = getDb();
    const rows = await db
      .select({ employee: employees, branch: branches })
      .from(employees)
      .leftJoin(branches, eq(employees.branchId, branches.id))
      .orderBy(employees.name);
    return rows.map((r) => ({ ...r.employee, branch: r.branch }));
  }),

  listBranches: staffProcedure.query(() => getDb().select().from(branches)),

  auditLog: staffProcedure
    .input(
      z.object({
        page: z.number().min(1).default(1),
        search: z.string().optional(),
        actorType: z.enum(["customer", "staff", "system"]).optional(),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conds = [];
      if (input.actorType) conds.push(eq(auditLog.actorType, input.actorType));
      if (input.search) {
        const q = `%${input.search}%`;
        conds.push(or(
          like(auditLog.actorName, q), like(auditLog.action, q),
          like(auditLog.entityId, q), like(auditLog.detail, q),
        )!);
      }
      const where = conds.length ? and(...conds) : undefined;
      const [{ total }] = await db.select({ total: count() }).from(auditLog).where(where);
      const rows = await db.select().from(auditLog).where(where)
        .orderBy(desc(auditLog.createdAt)).limit(PAGE).offset((input.page - 1) * PAGE);
      return { entries: rows, total, page: input.page, pageSize: PAGE };
    }),
});
