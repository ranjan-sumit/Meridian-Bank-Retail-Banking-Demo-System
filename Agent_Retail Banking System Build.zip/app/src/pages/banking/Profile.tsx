import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Check } from "lucide-react";
import { toast } from "sonner";
import BankingLayout from "@/components/banking/BankingLayout";
import StatusBadge from "@/components/shared/StatusBadge";
import { trpc } from "@/providers/trpc";
import { fmtDate } from "@/components/banking/format";
import { cn } from "@/lib/utils";

const SECTIONS = ["Profile", "Security", "Notifications", "Alerts inbox", "Linked accounts", "Preferences"] as const;
type Section = (typeof SECTIONS)[number];

export default function Profile() {
  const [section, setSection] = useState<Section>("Profile");
  return (
    <BankingLayout>
      <h1 className="font-display text-[28px] font-bold text-navy">Profile &amp; Settings</h1>
      <div className="mt-6 flex flex-col gap-6 lg:flex-row">
        <nav className="w-full shrink-0 rounded-xl border border-slate-200 bg-white p-2 shadow-sm lg:w-[240px]">
          {SECTIONS.map((s) => (
            <button
              key={s}
              onClick={() => setSection(s)}
              className={cn(
                "relative block w-full rounded-lg px-3.5 py-2.5 text-left text-sm font-medium transition",
                section === s ? "bg-navy/5 text-navy" : "text-subtle hover:bg-slate-50 hover:text-navy"
              )}
            >
              {section === s && <span className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r bg-gold" />}
              {s}
            </button>
          ))}
        </nav>
        <div className="min-w-0 flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={section}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              {section === "Profile" && <ProfileSection />}
              {section === "Security" && <SecuritySection />}
              {section === "Notifications" && <NotificationsSection />}
              {section === "Alerts inbox" && <AlertsSection />}
              {section === "Linked accounts" && <LinkedSection />}
              {section === "Preferences" && <PreferencesSection />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </BankingLayout>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
      <h2 className="font-display text-[17px] font-semibold text-navy">{title}</h2>
      <div className="mt-4">{children}</div>
    </div>
  );
}

function ProfileSection() {
  const q = trpc.customer.profile.useQuery();
  const utils = trpc.useUtils();
  const update = trpc.customer.updateProfile.useMutation({
    onSuccess: () => {
      toast.success("Profile saved");
      setEditing(false);
      utils.customer.profile.invalidate();
    },
    onError: (e) => toast.error("Couldn't save profile", { description: e.message }),
  });
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ email: "", phone: "", address: "" });
  const c = q.data;

  if (q.isLoading) return <div className="h-72 animate-pulse rounded-xl border border-slate-200 bg-white" />;
  if (!c) return <p className="text-sm text-subtle">Profile unavailable.</p>;

  return (
    <div className="space-y-6">
      <Card title="Personal information">
        <div className="flex items-center gap-5">
          <div className="group relative">
            <img src="/avatar-elena.png" alt="" className="h-24 w-24 rounded-full object-cover" />
            <button
              onClick={() => toast("Photo upload is disabled in this demo")}
              className="absolute inset-0 flex items-center justify-center rounded-full bg-navy-deep/60 text-xs font-medium text-white opacity-0 transition group-hover:opacity-100"
            >
              Change photo
            </button>
          </div>
          <div>
            <p className="font-display text-lg font-semibold text-navy">
              {c.firstName} {c.lastName}
            </p>
            <p className="text-sm text-subtle">
              Customer since {fmtDate(c.createdAt)} · Customer ID {c.customerNo}
            </p>
            <StatusBadge status="Verified" className="mt-1.5" />
          </div>
        </div>
        <div className="mt-6 space-y-3 text-sm">
          {(
            [
              ["Email", "email", c.email],
              ["Phone", "phone", c.phone],
              ["Address", "address", c.address],
            ] as const
          ).map(([label, key, value]) => (
            <div key={key} className="flex items-center justify-between gap-4 border-b border-slate-50 pb-3">
              <span className="w-28 text-subtle">{label}</span>
              {editing ? (
                <input
                  value={form[key]}
                  onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                  className="h-9 flex-1 rounded-lg border border-slate-300 px-3 outline-none focus:border-navy"
                />
              ) : (
                <span className="flex-1 font-medium text-body">{value}</span>
              )}
            </div>
          ))}
        </div>
        <div className="mt-4 flex gap-2">
          {!editing ? (
            <button
              onClick={() => {
                setForm({ email: c.email, phone: c.phone, address: c.address });
                setEditing(true);
              }}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-navy transition hover:border-navy"
            >
              Edit
            </button>
          ) : (
            <>
              <button
                disabled={update.isPending}
                onClick={() => update.mutate({ email: form.email, phone: form.phone, address: form.address })}
                className="rounded-lg bg-gold px-4 py-2 text-sm font-semibold text-navy transition hover:bg-gold-hover disabled:opacity-60"
              >
                {update.isPending ? "Saving…" : "Save"}
              </button>
              <button
                onClick={() => setEditing(false)}
                className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-navy"
              >
                Cancel
              </button>
            </>
          )}
        </div>
      </Card>
    </div>
  );
}

function SecuritySection() {
  const [pwOpen, setPwOpen] = useState(false);
  const [codesOpen, setCodesOpen] = useState(false);
  const [twoFa, setTwoFa] = useState(true);
  const [bio, setBio] = useState(false);
  const [pw, setPw] = useState({ cur: "", next: "", confirm: "" });

  const strength = Math.min(3, Math.floor(pw.next.length / 4));
  const strengthColor = ["bg-red-500", "bg-amber-500", "bg-amber-400", "bg-money"][strength];

  return (
    <div className="space-y-6">
      <Card title="Password">
        <div className="flex items-center justify-between">
          <p className="text-sm text-subtle">Last changed Oct 3, 2024</p>
          <button
            onClick={() => setPwOpen(true)}
            className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-navy hover:border-navy"
          >
            Change password
          </button>
        </div>
      </Card>

      <Card title="Two-factor authentication">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-body">Authenticator app</p>
            <p className="text-xs text-subtle">Backup codes (8 remaining)</p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => setCodesOpen(true)} className="text-sm font-medium text-navy hover:underline">
              View codes
            </button>
            <Toggle on={twoFa} onChange={setTwoFa} />
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
          <p className="text-sm font-medium text-body">Biometric login (Face ID)</p>
          <Toggle
            on={bio}
            onChange={(v) => {
              setBio(v);
              if (v) toast.success("Enabled on this device");
            }}
          />
        </div>
      </Card>

      <Card title="Active sessions">
        <ul className="divide-y divide-slate-50 text-sm">
          {[
            ["MacBook Pro · Chrome", "New York, NY", "Current session", true],
            ["iPhone 15 · Meridian App", "New York, NY", "Feb 13, 8:02 PM", false],
          ].map(([dev, loc, when, current]) => (
            <li key={String(dev)} className="flex items-center justify-between py-3 transition hover:bg-slate-50">
              <div className="flex items-center gap-2.5">
                {Boolean(current) && <span className="h-2 w-2 rounded-full bg-money" />}
                <div>
                  <p className="font-medium text-body">{dev}</p>
                  <p className="text-xs text-subtle">
                    {loc} · {when}
                  </p>
                </div>
              </div>
              {!current && (
                <button
                  onClick={() => toast.success("Session signed out")}
                  className="text-xs font-medium text-[#B42318] hover:underline"
                >
                  Sign out
                </button>
              )}
            </li>
          ))}
        </ul>
        <button
          onClick={() => toast.success("All other sessions signed out")}
          className="mt-3 text-sm font-medium text-[#B42318] hover:underline"
        >
          Sign out all other sessions
        </button>
      </Card>

      <Card title="Login history">
        <ul className="divide-y divide-slate-50 text-sm">
          {[
            ["Feb 12, 9:41 AM", "73.112.44.8", "MacBook Pro · Chrome", "Active"],
            ["Feb 11, 6:15 PM", "73.112.44.8", "iPhone 15 · App", "Active"],
            ["Feb 08, 8:03 AM", "73.112.44.8", "MacBook Pro · Chrome", "Active"],
            ["Feb 02, 11:47 PM", "91.203.66.14", "Unknown · Firefox", "Rejected"],
            ["Jan 30, 7:22 AM", "73.112.44.8", "iPhone 15 · App", "Active"],
          ].map(([ts, ip, dev, st]) => (
            <li key={ts + ip} className="flex items-center justify-between py-2.5">
              <div>
                <p className="text-body">{dev}</p>
                <p className="text-xs text-subtle">
                  {ts} · IP <span className="font-mono">{ip}</span>
                </p>
              </div>
              <StatusBadge status={st === "Active" ? "Active" : "Rejected"} />
            </li>
          ))}
        </ul>
        <p className="mt-2 text-xs text-[#B42318]">Feb 02 · Failed — wrong password</p>
      </Card>

      {/* Change password modal */}
      <AnimatePresence>
        {pwOpen && (
          <Modal onClose={() => setPwOpen(false)} title="Change password">
            <div className="space-y-3">
              <input
                type="password"
                placeholder="Current password"
                value={pw.cur}
                onChange={(e) => setPw({ ...pw, cur: e.target.value })}
                className="h-11 w-full rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-navy"
              />
              <input
                type="password"
                placeholder="New password"
                value={pw.next}
                onChange={(e) => setPw({ ...pw, next: e.target.value })}
                className="h-11 w-full rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-navy"
              />
              <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
                <div className={cn("h-full rounded-full transition-all", strengthColor)} style={{ width: `${(strength / 3) * 100}%` }} />
              </div>
              <input
                type="password"
                placeholder="Confirm new password"
                value={pw.confirm}
                onChange={(e) => setPw({ ...pw, confirm: e.target.value })}
                className="h-11 w-full rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-navy"
              />
              <button
                onClick={() => {
                  setPwOpen(false);
                  setPw({ cur: "", next: "", confirm: "" });
                  toast.success("Password updated (demo)");
                }}
                disabled={!pw.cur || pw.next.length < 8 || pw.next !== pw.confirm}
                className="h-11 w-full rounded-lg bg-gold font-semibold text-navy transition hover:bg-gold-hover disabled:opacity-40"
              >
                Update password
              </button>
            </div>
          </Modal>
        )}
        {codesOpen && (
          <Modal onClose={() => setCodesOpen(false)} title="Backup codes">
            <div className="grid grid-cols-2 gap-2 font-mono text-sm">
              {["8F2K-91XQ", "M4B7-22PD", "T9QW-05ZL", "C3HN-77RA", "K8D2-40VF", "P6XS-19MB", "W2LQ-83NC", "R7YB-56KT"].map((c) => (
                <span key={c} className="rounded-lg bg-slate-50 px-3 py-2 text-center text-body">
                  {c}
                </span>
              ))}
            </div>
            <button
              onClick={() => toast.success("New backup codes generated (demo)")}
              className="mt-4 text-sm font-medium text-navy hover:underline"
            >
              Regenerate codes
            </button>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  );
}

function Toggle({ on, onChange, disabled }: { on: boolean; onChange?: (v: boolean) => void; disabled?: boolean }) {
  return (
    <button
      disabled={disabled}
      onClick={() => onChange?.(!on)}
      className={cn(
        "relative h-6 w-11 rounded-full transition-colors",
        on ? "bg-money" : "bg-slate-300",
        disabled && "cursor-not-allowed opacity-50"
      )}
      aria-pressed={on}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 500, damping: 32 }}
        className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white shadow", on ? "left-[22px]" : "left-0.5")}
      />
    </button>
  );
}

function Modal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-navy-deep/50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.96, y: 12 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.97, y: 8 }}
        className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-display text-lg font-semibold text-navy">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-navy">
            <X className="h-5 w-5" />
          </button>
        </div>
        {children}
      </motion.div>
    </motion.div>
  );
}

function NotificationsSection() {
  const rows: [string, boolean][] = [
    ["Large transactions over $200", true],
    ["Payment due reminders", true],
    ["Statement ready", true],
    ["Marketing offers", false],
  ];
  const [matrix, setMatrix] = useState<Record<string, boolean[]>>(() =>
    Object.fromEntries(rows.map(([r]) => [r, [true, true, false]]))
  );
  const [saved, setSaved] = useState(false);

  return (
    <Card title="Notification preferences">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-[11px] uppercase tracking-[0.06em] text-slate-500">
            <th className="py-2 font-medium">Alert</th>
            {["Email", "SMS", "Push"].map((c) => (
              <th key={c} className="py-2 text-center font-medium">
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map(([label]) => (
            <tr key={label} className="border-t border-slate-50">
              <td className="py-3 text-body">{label}</td>
              {[0, 1, 2].map((ci) => (
                <td key={ci} className="py-3 text-center">
                  <Toggle
                    on={matrix[label][ci]}
                    onChange={(v) =>
                      setMatrix((m) => ({
                        ...m,
                        [label]: m[label].map((x, i) => (i === ci ? v : x)),
                      }))
                    }
                  />
                </td>
              ))}
            </tr>
          ))}
          <tr className="border-t border-slate-50">
            <td className="py-3 text-body">
              Security alerts <span className="text-xs text-subtle">(always on)</span>
            </td>
            {[0, 1, 2].map((ci) => (
              <td key={ci} className="py-3 text-center">
                <Toggle on disabled />
              </td>
            ))}
          </tr>
        </tbody>
      </table>
      <button
        onClick={() => {
          setSaved(true);
          toast.success("Preferences saved");
          setTimeout(() => setSaved(false), 1500);
        }}
        className="mt-4 flex items-center gap-2 rounded-lg bg-navy px-4 py-2 text-sm font-semibold text-white transition hover:bg-navy-deep"
      >
        {saved && <Check className="h-4 w-4" />} {saved ? "Saved" : "Save preferences"}
      </button>
    </Card>
  );
}

function AlertsSection() {
  const q = trpc.customer.listNotifications.useQuery();
  const mark = trpc.customer.markNotificationRead.useMutation({ onSuccess: () => q.refetch() });
  const [page, setPage] = useState(1);
  const items = q.data ?? [];
  const per = 10;
  const shown = useMemo(() => items.slice((page - 1) * per, page * per), [items, page]);

  return (
    <Card title="Alerts inbox">
      <div className="mb-3 flex justify-end">
        <button
          onClick={() => items.filter((n) => !n.read).forEach((n) => mark.mutate({ id: n.id }))}
          className="text-xs font-medium text-navy hover:underline"
        >
          Mark all read
        </button>
      </div>
      {q.isLoading ? (
        <div className="space-y-2">{[0, 1, 2].map((i) => <div key={i} className="h-12 animate-pulse rounded-lg bg-slate-50" />)}</div>
      ) : shown.length === 0 ? (
        <p className="py-6 text-center text-sm text-subtle">No alerts.</p>
      ) : (
        <ul className="divide-y divide-slate-50">
          {shown.map((n) => (
            <li
              key={n.id}
              onClick={() => !n.read && mark.mutate({ id: n.id })}
              className={cn("flex cursor-pointer items-start gap-3 py-3 transition hover:bg-slate-50", !n.read && "font-medium")}
            >
              {!n.read ? <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-gold" /> : <span className="mt-1.5 h-2 w-2 shrink-0" />}
              <div className="flex-1">
                <p className="text-sm text-body">{n.title}</p>
                <p className="mt-0.5 text-xs font-normal text-subtle">{n.body}</p>
              </div>
              <span className="whitespace-nowrap text-xs font-normal text-subtle">{fmtDate(n.createdAt, "MMM d")}</span>
            </li>
          ))}
        </ul>
      )}
      <div className="mt-3 flex items-center justify-between text-xs text-subtle">
        <span className="tabular-nums">
          Showing {items.length === 0 ? 0 : (page - 1) * per + 1}–{Math.min(page * per, items.length)} of {items.length}
        </span>
        <div className="flex gap-2">
          <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="rounded border border-slate-200 px-2 py-1 disabled:opacity-40">
            Prev
          </button>
          <button disabled={page * per >= items.length} onClick={() => setPage((p) => p + 1)} className="rounded border border-slate-200 px-2 py-1 disabled:opacity-40">
            Next
          </button>
        </div>
      </div>
    </Card>
  );
}

function LinkedSection() {
  const [open, setOpen] = useState(false);
  return (
    <Card title="Linked external accounts">
      <ul className="space-y-3 text-sm">
        <li className="flex items-center justify-between rounded-lg bg-slate-50 px-4 py-3">
          <span className="font-medium text-body">Chase ••••9912</span>
          <StatusBadge status="Verified" />
        </li>
        <li className="flex items-center justify-between rounded-lg bg-slate-50 px-4 py-3">
          <span className="font-medium text-body">Vanguard Brokerage ••••0044</span>
          <StatusBadge status="Pending" />
        </li>
      </ul>
      <p className="mt-1.5 text-xs text-subtle">Vanguard: pending micro-deposit verification.</p>
      <button
        onClick={() => setOpen(true)}
        className="mt-4 rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-navy hover:border-navy"
      >
        Link an account
      </button>
      <AnimatePresence>
        {open && (
          <Modal onClose={() => setOpen(false)} title="Link an external account">
            <input
              placeholder="Search institutions…"
              className="h-11 w-full rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-navy"
            />
            <ul className="mt-3 space-y-1 text-sm">
              {["Chase", "Bank of America", "Wells Fargo", "Vanguard", "Fidelity"].map((b) => (
                <li key={b}>
                  <button
                    onClick={() => {
                      setOpen(false);
                      toast.success("Institution selected (demo)", { description: "Credential step is stubbed in this demo." });
                    }}
                    className="w-full rounded-lg px-3 py-2 text-left text-body transition hover:bg-slate-50"
                  >
                    {b}
                  </button>
                </li>
              ))}
            </ul>
          </Modal>
        )}
      </AnimatePresence>
    </Card>
  );
}

function PreferencesSection() {
  const [paperless, setPaperless] = useState(true);
  return (
    <Card title="Preferences">
      <div className="space-y-4 text-sm">
        {(
          [
            ["Language", ["English (US)", "Español"]],
            ["Timezone", ["America/New_York", "America/Chicago", "America/Los_Angeles"]],
            ["Currency display", ["USD", "EUR"]],
            ["Theme", ["Light"]],
          ] as const
        ).map(([label, opts]) => (
          <div key={label} className="flex items-center justify-between border-b border-slate-50 pb-3">
            <span className="text-subtle">{label}</span>
            <select className="h-9 rounded-lg border border-slate-200 px-2.5 text-sm outline-none focus:border-navy">
              {opts.map((o) => (
                <option key={o}>{o}</option>
              ))}
            </select>
          </div>
        ))}
        <div className="flex items-center justify-between">
          <span className="text-subtle">Paperless statements</span>
          <Toggle on={paperless} onChange={(v) => { setPaperless(v); toast.success("Preference saved"); }} />
        </div>
      </div>
    </Card>
  );
}
