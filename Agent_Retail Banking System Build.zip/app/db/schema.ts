import {
  mysqlTable,
  mysqlEnum,
  // serial unused (MariaDB DDL compat); using bigint autoincrement
  varchar,
  text,
  boolean,
  timestamp,
  date,
  decimal,
  bigint,
  index,
} from "drizzle-orm/mysql-core";

const ref = (name: string) =>
  bigint(name, { mode: "number", unsigned: true });

export const branches = mysqlTable("branches", {
  id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  code: varchar("code", { length: 16 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  address: varchar("address", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 32 }).notNull(),
});

export const customers = mysqlTable(
  "customers",
  {
    id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
    customerNo: varchar("customerNo", { length: 16 }).notNull().unique(),
    firstName: varchar("firstName", { length: 64 }).notNull(),
    lastName: varchar("lastName", { length: 64 }).notNull(),
    email: varchar("email", { length: 320 }).notNull().unique(),
    phone: varchar("phone", { length: 32 }).notNull(),
    dob: date("dob", { mode: "string" }).notNull(),
    address: varchar("address", { length: 255 }).notNull(),
    ssnLast4: varchar("ssnLast4", { length: 4 }).notNull(),
    kycStatus: mysqlEnum("kycStatus", [
      "verified",
      "pending",
      "under_review",
      "rejected",
    ])
      .notNull()
      .default("pending"),
    branchId: ref("branchId").notNull(),
    createdAt: timestamp("createdAt").notNull().defaultNow(),
  },
  (t) => ({ nameIdx: index("customers_name_idx").on(t.lastName) }),
);

export const users = mysqlTable("users", {
  id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  username: varchar("username", { length: 320 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 128 }).notNull(),
  role: mysqlEnum("role", ["customer", "teller", "manager", "admin"]).notNull(),
  customerId: ref("customerId"),
  name: varchar("name", { length: 128 }).notNull(),
  lastLoginAt: timestamp("lastLoginAt"),
});

export const sessions = mysqlTable(
  "sessions",
  {
    id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
    token: varchar("token", { length: 128 }).notNull().unique(),
    userId: ref("userId").notNull(),
    expiresAt: timestamp("expiresAt").notNull(),
    createdAt: timestamp("createdAt").notNull().defaultNow(),
  },
  (t) => ({ tokenIdx: index("sessions_token_idx").on(t.token) }),
);

export const employees = mysqlTable("employees", {
  id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  employeeNo: varchar("employeeNo", { length: 16 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  role: mysqlEnum("role", ["teller", "manager", "admin"]).notNull(),
  branchId: ref("branchId").notNull(),
  status: mysqlEnum("status", ["active", "on_leave", "terminated"])
    .notNull()
    .default("active"),
  hiredAt: date("hiredAt", { mode: "string" }).notNull(),
});

export const accounts = mysqlTable(
  "accounts",
  {
    id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
    accountNumber: varchar("accountNumber", { length: 32 }).notNull().unique(),
    last4: varchar("last4", { length: 4 }).notNull(),
    type: mysqlEnum("type", ["checking", "savings", "credit", "mortgage"]).notNull(),
    nickname: varchar("nickname", { length: 128 }).notNull(),
    balance: decimal("balance", { precision: 14, scale: 2 }).notNull().default("0"),
    currency: varchar("currency", { length: 3 }).notNull().default("USD"),
    status: mysqlEnum("status", ["active", "frozen", "closed"])
      .notNull()
      .default("active"),
    apy: decimal("apy", { precision: 6, scale: 3 }),
    creditLimit: decimal("creditLimit", { precision: 14, scale: 2 }),
    customerId: ref("customerId").notNull(),
    branchId: ref("branchId").notNull(),
    openedAt: date("openedAt", { mode: "string" }).notNull(),
  },
  (t) => ({ custIdx: index("accounts_customer_idx").on(t.customerId) }),
);

export const transactions = mysqlTable(
  "transactions",
  {
    id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
    txnId: varchar("txnId", { length: 32 }).notNull().unique(),
    accountId: ref("accountId").notNull(),
    counterAccountId: ref("counterAccountId"),
    type: mysqlEnum("type", [
      "transfer",
      "deposit",
      "withdrawal",
      "fee",
      "interest",
      "payment",
      "purchase",
    ]).notNull(),
    amount: decimal("amount", { precision: 14, scale: 2 }).notNull(),
    direction: mysqlEnum("direction", ["dr", "cr"]).notNull(),
    merchant: varchar("merchant", { length: 128 }),
    description: varchar("description", { length: 255 }).notNull(),
    category: varchar("category", { length: 64 }).notNull().default("General"),
    status: mysqlEnum("status", ["posted", "pending", "flagged"])
      .notNull()
      .default("posted"),
    flagReason: varchar("flagReason", { length: 255 }),
    occurredAt: timestamp("occurredAt").notNull(),
    createdBy: varchar("createdBy", { length: 128 }).notNull().default("system"),
  },
  (t) => ({
    acctIdx: index("txn_account_idx").on(t.accountId),
    statusIdx: index("txn_status_idx").on(t.status),
    occurredIdx: index("txn_occurred_idx").on(t.occurredAt),
  }),
);

export const payees = mysqlTable("payees", {
  id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  customerId: ref("customerId").notNull(),
  name: varchar("name", { length: 128 }).notNull(),
  accountNumber: varchar("accountNumber", { length: 32 }).notNull(),
  bank: varchar("bank", { length: 128 }).notNull(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
});

export const cards = mysqlTable("cards", {
  id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  last4: varchar("last4", { length: 4 }).notNull(),
  fullNumber: varchar("fullNumber", { length: 19 }).notNull(),
  type: mysqlEnum("type", ["debit", "credit"]).notNull(),
  network: mysqlEnum("network", ["visa", "mastercard"]).notNull(),
  holder: varchar("holder", { length: 128 }).notNull(),
  customerId: ref("customerId").notNull(),
  accountId: ref("accountId").notNull(),
  status: mysqlEnum("status", ["active", "frozen", "blocked", "pending"])
    .notNull()
    .default("active"),
  creditLimit: decimal("creditLimit", { precision: 14, scale: 2 }),
  availableCredit: decimal("availableCredit", { precision: 14, scale: 2 }),
  expiresAt: date("expiresAt", { mode: "string" }).notNull(),
  issuedAt: date("issuedAt", { mode: "string" }).notNull(),
});

export const loanProducts = mysqlTable("loanProducts", {
  id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  code: varchar("code", { length: 16 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  rateApr: decimal("rateApr", { precision: 6, scale: 3 }).notNull(),
  minAmount: decimal("minAmount", { precision: 14, scale: 2 }).notNull(),
  maxAmount: decimal("maxAmount", { precision: 14, scale: 2 }).notNull(),
  termMonths: bigint("termMonths", { mode: "number" }).notNull(),
});

export const loans = mysqlTable(
  "loans",
  {
    id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
    loanNo: varchar("loanNo", { length: 16 }).notNull().unique(),
    customerId: ref("customerId").notNull(),
    productId: ref("productId").notNull(),
    principal: decimal("principal", { precision: 14, scale: 2 }).notNull(),
    remainingBalance: decimal("remainingBalance", { precision: 14, scale: 2 }).notNull(),
    rateApr: decimal("rateApr", { precision: 6, scale: 3 }).notNull(),
    termMonths: bigint("termMonths", { mode: "number" }).notNull(),
    monthlyPayment: decimal("monthlyPayment", { precision: 14, scale: 2 }).notNull(),
    purpose: varchar("purpose", { length: 255 }).notNull(),
    status: mysqlEnum("status", [
      "pending",
      "approved",
      "rejected",
      "active",
      "delinquent",
      "paid_off",
    ])
      .notNull()
      .default("pending"),
    appliedAt: timestamp("appliedAt").notNull().defaultNow(),
    decidedAt: timestamp("decidedAt"),
    decidedBy: varchar("decidedBy", { length: 128 }),
    disbursementAt: timestamp("disbursementAt"),
    branchId: ref("branchId").notNull(),
  },
  (t) => ({ custIdx: index("loans_customer_idx").on(t.customerId) }),
);

export const loanPayments = mysqlTable(
  "loanPayments",
  {
    id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
    loanId: ref("loanId").notNull(),
    dueDate: date("dueDate", { mode: "string" }).notNull(),
    amount: decimal("amount", { precision: 14, scale: 2 }).notNull(),
    principalPart: decimal("principalPart", { precision: 14, scale: 2 }).notNull(),
    interestPart: decimal("interestPart", { precision: 14, scale: 2 }).notNull(),
    status: mysqlEnum("status", ["paid", "due", "overdue"])
      .notNull()
      .default("due"),
    paidAt: timestamp("paidAt"),
  },
  (t) => ({ loanIdx: index("loanpay_loan_idx").on(t.loanId) }),
);

export const kycCases = mysqlTable("kycCases", {
  id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  caseNo: varchar("caseNo", { length: 16 }).notNull().unique(),
  customerId: ref("customerId").notNull(),
  level: mysqlEnum("level", ["standard", "enhanced"]).notNull().default("standard"),
  status: mysqlEnum("status", ["pending", "under_review", "approved", "rejected"])
    .notNull()
    .default("pending"),
  idDocType: varchar("idDocType", { length: 64 }).notNull(),
  riskRating: mysqlEnum("riskRating", ["low", "medium", "high"])
    .notNull()
    .default("low"),
  submittedAt: timestamp("submittedAt").notNull().defaultNow(),
  reviewedBy: varchar("reviewedBy", { length: 128 }),
  reviewedAt: timestamp("reviewedAt"),
  rejectionReason: varchar("rejectionReason", { length: 255 }),
  notes: text("notes"),
});

export const alerts = mysqlTable("alerts", {
  id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  alertNo: varchar("alertNo", { length: 16 }).notNull().unique(),
  type: mysqlEnum("type", [
    "structuring",
    "high_velocity",
    "unusual_amount",
    "geo_anomaly",
  ]).notNull(),
  severity: mysqlEnum("severity", ["low", "medium", "high", "critical"]).notNull(),
  customerId: ref("customerId").notNull(),
  transactionId: ref("transactionId"),
  status: mysqlEnum("status", ["open", "investigating", "resolved", "dismissed"])
    .notNull()
    .default("open"),
  description: varchar("description", { length: 500 }).notNull(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  assignedTo: varchar("assignedTo", { length: 128 }),
});

export const notifications = mysqlTable(
  "notifications",
  {
    id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
    customerId: ref("customerId").notNull(),
    title: varchar("title", { length: 128 }).notNull(),
    body: varchar("body", { length: 500 }).notNull(),
    type: mysqlEnum("type", ["info", "warning", "action"]).notNull().default("info"),
    read: boolean("read").notNull().default(false),
    createdAt: timestamp("createdAt").notNull().defaultNow(),
  },
  (t) => ({ custIdx: index("notif_customer_idx").on(t.customerId) }),
);

export const auditLog = mysqlTable(
  "auditLog",
  {
    id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
    actorType: mysqlEnum("actorType", ["customer", "staff", "system"]).notNull(),
    actorName: varchar("actorName", { length: 128 }).notNull(),
    action: varchar("action", { length: 128 }).notNull(),
    entityType: varchar("entityType", { length: 64 }).notNull(),
    entityId: varchar("entityId", { length: 64 }).notNull(),
    detail: text("detail"),
    prevHash: varchar("prevHash", { length: 64 }).notNull(),
    hash: varchar("hash", { length: 64 }).notNull(),
    createdAt: timestamp("createdAt").notNull().defaultNow(),
  },
  (t) => ({ entityIdx: index("audit_entity_idx").on(t.entityType, t.entityId) }),
);
