import { createHash } from "crypto";
import { desc } from "drizzle-orm";
import { getDb } from "./connection";
import { auditLog } from "@db/schema";

export function sha256(input: string) {
  return createHash("sha256").update(input).digest("hex");
}

/** Append an entry to the hash-chained audit log. */
export async function appendAudit(entry: {
  actorType: "customer" | "staff" | "system";
  actorName: string;
  action: string;
  entityType: string;
  entityId: string;
  detail?: string;
}) {
  const db = getDb();
  const [last] = await db
    .select({ hash: auditLog.hash })
    .from(auditLog)
    .orderBy(desc(auditLog.id))
    .limit(1);
  const prevHash = last?.hash ?? "0".repeat(64);
  const at = new Date();
  const payload = `${at.toISOString()}|${entry.actorType}|${entry.actorName}|${entry.action}|${entry.entityType}|${entry.entityId}|${entry.detail ?? ""}`;
  const hash = sha256(prevHash + payload);
  await db.insert(auditLog).values({
    actorType: entry.actorType,
    actorName: entry.actorName,
    action: entry.action,
    entityType: entry.entityType,
    entityId: entry.entityId,
    detail: entry.detail ?? null,
    prevHash,
    hash,
    createdAt: at,
  });
}
