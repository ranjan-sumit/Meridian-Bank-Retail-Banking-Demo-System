import type { ReactNode } from "react";
import { Routes, Route } from "react-router";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Dashboard from "@/pages/banking/Dashboard";
import Accounts from "@/pages/banking/Accounts";
import AccountDetail from "@/pages/banking/AccountDetail";
import Transfers from "@/pages/banking/Transfers";
import Cards from "@/pages/banking/Cards";
import Loans from "@/pages/banking/Loans";
import Profile from "@/pages/banking/Profile";
import StaffLogin from "@/pages/staff/StaffLogin";
import StaffLayout from "@/components/staff/StaffLayout";
import StaffDashboard from "@/pages/staff/StaffDashboard";
import StaffCustomers from "@/pages/staff/StaffCustomers";
import StaffCustomerDetail from "@/pages/staff/StaffCustomerDetail";
import StaffKyc from "@/pages/staff/StaffKyc";
import StaffMonitoring from "@/pages/staff/StaffMonitoring";
import StaffLoans from "@/pages/staff/StaffLoans";
import StaffCards from "@/pages/staff/StaffCards";
import StaffEmployees from "@/pages/staff/StaffEmployees";
import StaffAudit from "@/pages/staff/StaffAudit";

function PublicShell({ children }: { children: ReactNode }) {
  return <Layout>{children}</Layout>;
}

/** Staff ops pages are content-only; wrap them in the staff console shell. */
function StaffShell({ children }: { children: ReactNode }) {
  return <StaffLayout>{children}</StaffLayout>;
}

export default function App() {
  return (
    <Routes>
      {/* Public landing — wrapped in public Layout (Navbar/Footer) */}
      <Route
        path="/"
        element={
          <PublicShell>
            <Home />
          </PublicShell>
        }
      />

      {/* Front office (customer portal) — pages self-wrap in BankingLayout */}
      <Route path="/login" element={<Login />} />
      <Route path="/banking" element={<Dashboard />} />
      <Route path="/banking/accounts" element={<Accounts />} />
      <Route path="/banking/accounts/:id" element={<AccountDetail />} />
      <Route path="/banking/transfers" element={<Transfers />} />
      <Route path="/banking/cards" element={<Cards />} />
      <Route path="/banking/loans" element={<Loans />} />
      <Route path="/banking/profile" element={<Profile />} />

      {/* Back office (staff console) — dark theme */}
      <Route path="/staff/login" element={<StaffLogin />} />
      <Route path="/staff" element={<StaffDashboard />} />
      <Route path="/staff/customers" element={<StaffCustomers />} />
      <Route path="/staff/customers/:id" element={<StaffCustomerDetail />} />
      <Route
        path="/staff/kyc"
        element={
          <StaffShell>
            <StaffKyc />
          </StaffShell>
        }
      />
      <Route
        path="/staff/monitoring"
        element={
          <StaffShell>
            <StaffMonitoring />
          </StaffShell>
        }
      />
      <Route
        path="/staff/loans"
        element={
          <StaffShell>
            <StaffLoans />
          </StaffShell>
        }
      />
      <Route
        path="/staff/cards"
        element={
          <StaffShell>
            <StaffCards />
          </StaffShell>
        }
      />
      <Route
        path="/staff/employees"
        element={
          <StaffShell>
            <StaffEmployees />
          </StaffShell>
        }
      />
      <Route
        path="/staff/audit"
        element={
          <StaffShell>
            <StaffAudit />
          </StaffShell>
        }
      />

      <Route path="*" element={<Login />} />
    </Routes>
  );
}
