import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { NavLink, Link, useNavigate } from "react-router";
import {
  LayoutDashboard,
  Wallet,
  ArrowLeftRight,
  CreditCard,
  Landmark,
  UserRound,
  Search,
  Bell,
  LogOut,
  ChevronDown,
} from "lucide-react";
import { useSession } from "@/hooks/useSession";
import { trpc } from "@/providers/trpc";
import { Toaster } from "@/components/ui/sonner";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/banking", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/banking/accounts", label: "Accounts", icon: Wallet },
  { to: "/banking/transfers", label: "Transfers", icon: ArrowLeftRight },
  { to: "/banking/cards", label: "Cards", icon: CreditCard },
  { to: "/banking/loans", label: "Loans", icon: Landmark },
  { to: "/banking/profile", label: "Profile", icon: UserRound },
];

export default function BankingLayout({ children }: { children: ReactNode }) {
  const { user, role, logout } = useSession();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [bellOpen, setBellOpen] = useState(false);

  const notifQ = trpc.customer.listNotifications.useQuery(undefined, {
    enabled: role === "customer",
  });
  const markRead = trpc.customer.markNotificationRead.useMutation({
    onSuccess: () => notifQ.refetch(),
  });
  const utils = trpc.useUtils();
  const unread = useMemo(
    () => (notifQ.data ?? []).filter((n) => !n.read).length,
    [notifQ.data]
  );

  useEffect(() => {
    if (!user || role !== "customer") {
      navigate("/login", { replace: true });
    }
  }, [user, role, navigate]);

  if (!user || role !== "customer") return null;

  const firstName = user.name.split(" ")[0];

  return (
    <div className="theme-front min-h-[100dvh] bg-canvas text-body">
      <Toaster position="top-right" richColors />
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 flex w-[240px] flex-col bg-navy">
        <Link to="/" className="flex h-[60px] items-center gap-2 px-5">
          <img src="/logo.svg" alt="Meridian Bank" className="h-7 w-auto brightness-0 invert" />
        </Link>
        <nav className="mt-2 flex-1 space-y-0.5 px-3">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                cn(
                  "relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-white/10 text-white"
                    : "text-slate-300 hover:bg-white/5 hover:text-white"
                )
              }
            >
              {({ isActive }) => (
                <>
                  {isActive && (
                    <span className="absolute left-0 top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-r bg-gold" />
                  )}
                  <Icon className="h-[18px] w-[18px]" />
                  {label}
                </>
              )}
            </NavLink>
          ))}
        </nav>
        <div className="border-t border-white/10 p-4 text-[11px] leading-relaxed text-slate-400">
          Member FDIC. Equal Housing Lender.
          <br />
          Meridian Bank is a fictional demo institution.
        </div>
      </aside>

      {/* Top bar */}
      <header className="fixed inset-x-0 top-0 z-30 ml-[240px] flex h-[60px] items-center gap-4 border-b border-slate-200 bg-white px-6">
        <div className="relative w-80">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            placeholder="Search accounts, transactions…  (⌘K)"
            className="h-9 w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-sm outline-none transition focus:border-navy focus:bg-white"
            onKeyDown={(e) => {
              if (e.key === "Enter") navigate("/banking/accounts");
            }}
          />
        </div>
        <div className="ml-auto flex items-center gap-4">
          <span className="hidden text-xs text-subtle lg:block">
            Last sign-in: Feb 12, 2025 at 9:41 AM · New York, NY
          </span>
          <div className="relative">
            <button
              onClick={() => setBellOpen((v) => !v)}
              className="relative rounded-full p-2 text-slate-500 transition hover:bg-slate-100 hover:text-navy"
              aria-label="Notifications"
            >
              <Bell className="h-5 w-5" />
              {unread > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#B42318] px-1 text-[10px] font-semibold text-white">
                  {unread}
                </span>
              )}
            </button>
            {bellOpen && (
              <div className="absolute right-0 top-11 w-[380px] rounded-xl border border-slate-200 bg-white shadow-lg">
                <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
                  <p className="text-sm font-semibold text-navy">Notifications</p>
                  <button
                    className="text-xs font-medium text-navy hover:underline"
                    onClick={() =>
                      (notifQ.data ?? [])
                        .filter((n) => !n.read)
                        .forEach((n) => markRead.mutate({ id: n.id }))
                    }
                  >
                    Mark all read
                  </button>
                </div>
                <ul className="max-h-80 overflow-auto">
                  {(notifQ.data ?? []).slice(0, 6).map((n) => (
                    <li
                      key={n.id}
                      className={cn(
                        "cursor-pointer border-b border-slate-50 px-4 py-3 text-sm transition hover:bg-slate-50",
                        !n.read && "font-medium"
                      )}
                      onClick={() => markRead.mutate({ id: n.id })}
                    >
                      <div className="flex items-start gap-2">
                        {!n.read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-gold" />}
                        <div>
                          <p className="text-body">{n.title}</p>
                          <p className="mt-0.5 text-xs text-subtle">{n.body}</p>
                        </div>
                      </div>
                    </li>
                  ))}
                  {(notifQ.data ?? []).length === 0 && (
                    <li className="px-4 py-6 text-center text-sm text-subtle">
                      You're all caught up.
                    </li>
                  )}
                </ul>
              </div>
            )}
          </div>
          <div className="relative">
            <button
              onClick={() => setMenuOpen((v) => !v)}
              className="flex items-center gap-2 rounded-full py-1 pl-1 pr-2 transition hover:bg-slate-100"
            >
              <img src="/avatar-elena.png" alt={user.name} className="h-8 w-8 rounded-full object-cover" />
              <span className="text-sm font-medium text-navy">{firstName}</span>
              <ChevronDown className="h-4 w-4 text-slate-400" />
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-11 w-52 rounded-xl border border-slate-200 bg-white py-1 shadow-lg">
                <Link
                  to="/banking/profile"
                  onClick={() => setMenuOpen(false)}
                  className="block px-4 py-2 text-sm text-body hover:bg-slate-50"
                >
                  Profile &amp; settings
                </Link>
                <button
                  onClick={async () => {
                    await logout();
                    utils.invalidate();
                    navigate("/login");
                  }}
                  className="flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-[#B42318] hover:bg-slate-50"
                >
                  <LogOut className="h-4 w-4" /> Sign out
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="ml-[240px] pt-[60px]">
        <div className="mx-auto max-w-[1280px] px-8 py-8">{children}</div>
      </main>
    </div>
  );
}
