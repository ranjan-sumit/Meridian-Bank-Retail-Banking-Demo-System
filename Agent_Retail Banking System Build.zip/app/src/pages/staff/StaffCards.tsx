import { useMemo, useState } from "react";
import { format } from "date-fns";
import { toast, Toaster } from "sonner";
import { CreditCard, Snowflake, Ban, Unlock, Search } from "lucide-react";
import { trpc } from "@/providers/trpc";
import DataTable, { type Column } from "@/components/shared/DataTable";
import StatusBadge from "@/components/shared/StatusBadge";
import MoneyText from "@/components/shared/MoneyText";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

type CardRow = {
  id: number;
  last4: string;
  fullNumber: string;
  type: "debit" | "credit";
  network: "visa" | "mastercard";
  holder: string;
  customerId: number;
  status: "active" | "frozen" | "blocked" | "pending";
  creditLimit: string | null;
  availableCredit: string | null;
  expiresAt: string;
  issuedAt: string;
  customerName: string;
  customerNo: string;
};

const STATUS_LABEL: Record<string, string> = {
  active: "Active", frozen: "Frozen", blocked: "Blocked", pending: "Pending",
};

export default function StaffCards() {
  const utils = trpc.useUtils();
  const [tab, setTab] = useState<"requests" | "all" | "blocked">("requests");
  const requestsQuery = trpc.staff.cardRequests.useQuery();
  const cardsQuery = trpc.staff.listCards.useQuery();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const [declineTarget, setDeclineTarget] = useState<CardRow | null>(null);
  const [declineReason, setDeclineReason] = useState("");
  const [approveTarget, setApproveTarget] = useState<CardRow | null>(null);
  const [statusTarget, setStatusTarget] = useState<{ card: CardRow; next: "active" | "frozen" | "blocked" } | null>(null);

  const decideRequest = trpc.staff.decideCardRequest.useMutation({
    onSuccess: (_d, vars) => {
      toast.success(vars.approve ? `Card request approved — ••••${approveTarget?.last4} issued` : `Card request ••••${declineTarget?.last4} declined`);
      void utils.staff.cardRequests.invalidate();
      void utils.staff.listCards.invalidate();
      setApproveTarget(null);
      setDeclineTarget(null);
      setDeclineReason("");
    },
    onError: (e) => toast.error(e.message),
  });

  const setStatus = trpc.staff.setCardStatus.useMutation({
    onSuccess: (_d, vars) => {
      const verb = vars.status === "blocked" ? "blocked" : vars.status === "frozen" ? "frozen" : "unblocked";
      toast.success(`Card ••••${statusTarget?.card.last4} ${verb}`);
      void utils.staff.listCards.invalidate();
      void utils.staff.cardRequests.invalidate();
      setStatusTarget(null);
    },
    onError: (e) => toast.error(e.message),
  });

  const requests = (requestsQuery.data ?? []) as CardRow[];
  const cards = (cardsQuery.data ?? []) as CardRow[];
  const filteredCards = useMemo(() => {
    let list = cards;
    if (tab === "blocked") list = list.filter((c) => c.status === "frozen" || c.status === "blocked");
    if (statusFilter !== "all") list = list.filter((c) => c.status === statusFilter);
    if (search) {
      const q = search.toLowerCase();
      list = list.filter((c) => c.customerName.toLowerCase().includes(q) || c.last4.includes(q) || c.holder.toLowerCase().includes(q));
    }
    return list;
  }, [cards, tab, statusFilter, search]);

  const cardArt = (c: CardRow) => (
    <div className="flex items-center gap-2.5">
      <img
        src={c.type === "credit" ? "/card-platinum.png" : "/card-debit.png"}
        alt=""
        className="h-8 w-12 rounded border border-staff-border object-cover"
      />
      <div>
        <div className="font-mono text-[12.5px] text-staff-text">••••{c.last4}</div>
        <div className="text-[11px] capitalize text-staff-subtle">{c.network}</div>
      </div>
    </div>
  );

  const requestColumns: Column<CardRow>[] = [
    { key: "id", header: "Request ID", render: (r) => <span className="font-mono text-[12.5px] text-[#2DD4A8]">CRD-REQ-{String(r.id).padStart(4, "0")}</span> },
    { key: "customer", header: "Customer", render: (r) => <span className="text-staff-text">{r.customerName}</span>, sortValue: (r) => r.customerName },
    { key: "product", header: "Product", render: (r) => <span className="text-staff-subtle">{r.type === "credit" ? "Platinum Rewards Credit" : "Debit"}</span> },
    { key: "requested", header: "Requested", render: (r) => <span className="tabular-nums text-staff-subtle">{format(new Date(r.issuedAt), "MMM d")}</span>, sortValue: (r) => r.issuedAt },
    {
      key: "credit", header: "Credit check",
      render: (r) => r.type === "credit"
        ? <span className="font-mono text-[12.5px] tabular-nums text-staff-text">Score {700 + (r.id % 80)}</span>
        : <span className="text-staff-subtle">n/a</span>,
    },
    { key: "status", header: "Status", render: () => <StatusBadge dark status="Pending" /> },
    {
      key: "actions", header: "",
      render: (r) => (
        <div className="flex gap-2">
          <button
            onClick={() => setApproveTarget(r)}
            className="rounded-md bg-[#2DD4A8] px-3 py-1 text-xs font-semibold text-[#0B1118] hover:bg-[#2DD4A8]/90"
          >
            Approve
          </button>
          <button
            onClick={() => setDeclineTarget(r)}
            className="rounded-md border border-red-500/40 px-3 py-1 text-xs font-medium text-red-300 hover:bg-red-500/10"
          >
            Decline
          </button>
        </div>
      ),
    },
  ];

  const cardColumns: Column<CardRow>[] = [
    { key: "card", header: "Card", render: cardArt, sortValue: (r) => r.last4 },
    { key: "holder", header: "Holder", render: (r) => <span className="text-staff-text">{r.customerName}</span>, sortValue: (r) => r.customerName },
    { key: "type", header: "Type", render: (r) => <span className="capitalize text-staff-subtle">{r.type}</span> },
    {
      key: "limit", header: "Limit / Spend", headerClassName: "text-right", className: "text-right",
      render: (r) => r.type === "credit" && r.creditLimit ? (
        <span className="font-mono text-[12px] tabular-nums text-staff-text">
          <MoneyText variant="neutral" amount={Number(r.creditLimit) - Number(r.availableCredit ?? r.creditLimit)} /> / <MoneyText variant="neutral" amount={Number(r.creditLimit)} />
        </span>
      ) : <span className="text-[12px] text-staff-subtle">ATM $500/day</span>,
    },
    { key: "status", header: "Status", render: (r) => <StatusBadge dark status={STATUS_LABEL[r.status]} /> },
    { key: "issued", header: "Issued", render: (r) => <span className="tabular-nums text-staff-subtle">{format(new Date(r.issuedAt), "MMM yyyy")}</span>, sortValue: (r) => r.issuedAt },
    { key: "expires", header: "Expires", render: (r) => <span className="font-mono text-[12px] tabular-nums text-staff-subtle">{r.expiresAt}</span> },
    {
      key: "actions", header: "",
      render: (r) => (
        <div className="flex gap-1.5">
          {r.status === "active" && (
            <>
              <button title="Freeze" onClick={() => setStatusTarget({ card: r, next: "frozen" })} className="rounded-md border border-staff-border p-1.5 text-staff-subtle hover:text-blue-300"><Snowflake className="h-3.5 w-3.5" /></button>
              <button title="Block" onClick={() => setStatusTarget({ card: r, next: "blocked" })} className="rounded-md border border-staff-border p-1.5 text-staff-subtle hover:text-red-300"><Ban className="h-3.5 w-3.5" /></button>
            </>
          )}
          {(r.status === "frozen" || r.status === "blocked") && (
            <button
              onClick={() => setStatusTarget({ card: r, next: "active" })}
              className="flex items-center gap-1 rounded-md border border-[#2DD4A8]/40 px-2.5 py-1 text-xs font-medium text-[#2DD4A8] hover:bg-[#2DD4A8]/10"
            >
              <Unlock className="h-3 w-3" /> Unblock
            </button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-5">
      <Toaster position="top-right" theme="dark" richColors />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-semibold text-staff-text">Card Management</h1>
          <p className="text-xs text-staff-subtle">Issuance pipeline and card inventory controls</p>
        </div>
        <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
          <TabsList className="border border-staff-border bg-staff-panel">
            <TabsTrigger value="requests">Issuance Requests ({requests.length})</TabsTrigger>
            <TabsTrigger value="all">All Cards</TabsTrigger>
            <TabsTrigger value="blocked">Blocked/Frozen</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {tab === "requests" && (
        requestsQuery.isLoading ? (
          <div className="space-y-2 rounded-xl border border-staff-border bg-staff-panel p-4">
            {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-11 w-full bg-staff-raised" />)}
          </div>
        ) : requestsQuery.isError ? (
          <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-6 text-sm text-red-300">Failed to load requests: {requestsQuery.error.message}</div>
        ) : (
          <DataTable dark columns={requestColumns} data={requests} pageSize={10} rowKey={(r) => r.id} emptyMessage="No pending issuance requests." />
        )
      )}

      {tab !== "requests" && (
        <>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-staff-subtle" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search holder or last4…"
                className="w-60 rounded-lg border border-staff-border bg-staff-panel py-2 pl-8 pr-3 text-[12.5px] text-staff-text placeholder:text-staff-subtle focus:outline-none focus:ring-1 focus:ring-[#2DD4A8]"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="h-9 w-36 border-staff-border bg-staff-panel text-xs text-staff-text"><SelectValue /></SelectTrigger>
              <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
                {["all", "active", "frozen", "blocked", "pending"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          {cardsQuery.isLoading ? (
            <div className="space-y-2 rounded-xl border border-staff-border bg-staff-panel p-4">
              {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-11 w-full bg-staff-raised" />)}
            </div>
          ) : (
            <DataTable dark columns={cardColumns} data={filteredCards} pageSize={10} rowKey={(r) => r.id} emptyMessage="No cards match the current filters." />
          )}
        </>
      )}

      {/* Approve request dialog */}
      <Dialog open={!!approveTarget} onOpenChange={(o) => !o && setApproveTarget(null)}>
        <DialogContent className="border-staff-border bg-staff-panel text-staff-text">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base"><CreditCard className="h-5 w-5 text-[#2DD4A8]" /> Approve issuance</DialogTitle>
            <DialogDescription className="text-staff-subtle">
              Issue a {approveTarget?.type} card ••••{approveTarget?.last4} to {approveTarget?.customerName}. The card becomes active immediately and an audit entry is written.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <button onClick={() => setApproveTarget(null)} className="rounded-lg border border-staff-border px-4 py-2 text-sm text-staff-subtle hover:text-staff-text">Cancel</button>
            <button
              disabled={decideRequest.isPending}
              onClick={() => approveTarget && decideRequest.mutate({ cardId: approveTarget.id, approve: true })}
              className="rounded-lg bg-[#2DD4A8] px-4 py-2 text-sm font-semibold text-[#0B1118] disabled:opacity-50"
            >
              {decideRequest.isPending ? "Issuing…" : "Confirm & issue"}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Decline dialog */}
      <Dialog open={!!declineTarget} onOpenChange={(o) => !o && setDeclineTarget(null)}>
        <DialogContent className="border-staff-border bg-staff-panel text-staff-text">
          <DialogHeader>
            <DialogTitle className="text-base">Decline request ••••{declineTarget?.last4}</DialogTitle>
            <DialogDescription className="text-staff-subtle">The customer will be notified. Reason is optional but recommended.</DialogDescription>
          </DialogHeader>
          <textarea
            value={declineReason}
            onChange={(e) => setDeclineReason(e.target.value)}
            placeholder="Reason (e.g. credit score below threshold, KYC hold)…"
            rows={3}
            className="w-full rounded-lg border border-staff-border bg-staff-raised px-3 py-2 text-sm text-staff-text placeholder:text-staff-subtle focus:outline-none focus:ring-1 focus:ring-red-400"
          />
          <DialogFooter className="gap-2">
            <button onClick={() => setDeclineTarget(null)} className="rounded-lg border border-staff-border px-4 py-2 text-sm text-staff-subtle hover:text-staff-text">Cancel</button>
            <button
              disabled={decideRequest.isPending}
              onClick={() => declineTarget && decideRequest.mutate({ cardId: declineTarget.id, approve: false, reason: declineReason || undefined })}
              className="rounded-lg bg-red-500 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
            >
              {decideRequest.isPending ? "Declining…" : "Confirm decline"}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Status change confirm */}
      <Dialog open={!!statusTarget} onOpenChange={(o) => !o && setStatusTarget(null)}>
        <DialogContent className="border-staff-border bg-staff-panel text-staff-text">
          <DialogHeader>
            <DialogTitle className="text-base capitalize">{statusTarget?.next === "active" ? "Unblock" : statusTarget?.next} card ••••{statusTarget?.card.last4}</DialogTitle>
            <DialogDescription className="text-staff-subtle">
              {statusTarget?.next === "blocked" && "Blocking is immediate and stops all authorizations. Logged to the audit trail."}
              {statusTarget?.next === "frozen" && "Freezing pauses new authorizations until unfrozen."}
              {statusTarget?.next === "active" && "The card will resume normal authorizations immediately."}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <button onClick={() => setStatusTarget(null)} className="rounded-lg border border-staff-border px-4 py-2 text-sm text-staff-subtle hover:text-staff-text">Cancel</button>
            <button
              disabled={setStatus.isPending}
              onClick={() => statusTarget && setStatus.mutate({ cardId: statusTarget.card.id, status: statusTarget.next })}
              className={cn(
                "rounded-lg px-4 py-2 text-sm font-semibold disabled:opacity-50",
                statusTarget?.next === "blocked" ? "bg-red-500 text-white" : "bg-[#2DD4A8] text-[#0B1118]"
              )}
            >
              {setStatus.isPending ? "Applying…" : "Confirm"}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
