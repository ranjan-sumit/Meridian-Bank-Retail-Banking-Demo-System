import { Fragment, useMemo, useState } from "react";
import { Link, useParams } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Search,
  FileText,
  Download,
  ArrowLeftRight,
  Snowflake,
} from "lucide-react";
import { toast } from "sonner";
import BankingLayout from "@/components/banking/BankingLayout";
import AccountNumber from "@/components/shared/AccountNumber";
import StatusBadge from "@/components/shared/StatusBadge";
import MoneyText from "@/components/shared/MoneyText";
import { trpc } from "@/providers/trpc";
import { fmtMoney, fmtDate, txnAmount, statusLabel, capitalize, num } from "@/components/banking/format";
import { cn } from "@/lib/utils";

const TABS = ["Transactions", "Details", "Statements"] as const;
const TXN_TYPE_OPTS = ["", "deposit", "withdrawal", "transfer", "fee", "interest", "payment", "purchase"];
const RANGES = [
  { label: "Last 30 days", days: 30 },
  { label: "Last 90 days", days: 90 },
  { label: "All time", days: 0 },
];

export default function AccountDetail() {
  const { id } = useParams();
  const accountId = Number(id);
  const [tab, setTab] = useState<(typeof TABS)[number]>("Transactions");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [search, setSearch] = useState("");
  const [type, setType] = useState("");
  const [rangeIdx, setRangeIdx] = useState(0);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [sortDesc, setSortDesc] = useState(true);

  const from = useMemo(() => {
    const days = RANGES[rangeIdx].days;
    return days > 0 ? new Date(Date.now() - days * 86400000) : undefined;
  }, [rangeIdx]);

  const q = trpc.customer.accountDetail.useQuery({
    id: accountId,
    page,
    pageSize,
    search: search || undefined,
    type: type || undefined,
    from,
  });

  const acct = q.data?.account;
  const total = q.data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / pageSize));

  const txns = useMemo(() => {
    const rows = [...(q.data?.transactions ?? [])];
    if (sortDesc) return rows;
    return rows.reverse();
  }, [q.data, sortDesc]);

  return (
    <BankingLayout>
      {/* Breadcrumb + header */}
      <p className="text-xs text-subtle">
        <Link to="/banking/accounts" className="hover:underline">
          Accounts
        </Link>{" "}
        / {acct?.nickname ?? "…"}
      </p>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mt-2 rounded-xl border border-slate-200 bg-white p-6 shadow-sm"
      >
        {q.isLoading ? (
          <div className="h-24 animate-pulse rounded bg-slate-50" />
        ) : !acct ? (
          <p className="text-sm text-[#B42318]">Account not found.</p>
        ) : (
          <div className="flex flex-wrap items-start justify-between gap-6">
            <div>
              <div className="flex items-center gap-3">
                <h1 className="font-display text-[22px] font-semibold text-navy">{acct.nickname}</h1>
                <StatusBadge status={statusLabel(acct.status)} />
              </div>
              <AccountNumber
                last4={acct.last4}
                full={acct.accountNumber}
                className="mt-1 text-sm text-subtle"
              />
              <p className="mt-1 text-xs text-subtle">
                Current balance {fmtMoney(acct.balance)} · Routing 021000089 · Opened{" "}
                {fmtDate(acct.openedAt)}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[11px] uppercase tracking-[0.06em] text-slate-500">
                {acct.type === "credit" ? "Current balance" : acct.type === "mortgage" ? "Remaining balance" : "Available balance"}
              </p>
              <p className="font-display text-[28px] font-bold tabular-nums text-navy">
                {fmtMoney(acct.balance)}
              </p>
              <div className="mt-2 flex gap-2">
                <Link
                  to="/banking/transfers"
                  className="flex items-center gap-1.5 rounded-lg bg-navy px-3.5 py-2 text-xs font-semibold text-white transition hover:bg-navy-deep"
                >
                  <ArrowLeftRight className="h-3.5 w-3.5" /> Transfer money
                </Link>
                <button
                  onClick={() => toast.success("Statement download started")}
                  className="flex items-center gap-1.5 rounded-lg border border-slate-300 px-3.5 py-2 text-xs font-semibold text-navy transition hover:border-navy"
                >
                  <Download className="h-3.5 w-3.5" /> Statement
                </button>
                <button
                  onClick={() => toast("Freeze request sent", { description: "A banker will confirm within 1 business day." })}
                  className="flex items-center gap-1.5 rounded-lg border border-[#B42318] px-3.5 py-2 text-xs font-semibold text-[#B42318] transition hover:bg-red-50"
                >
                  <Snowflake className="h-3.5 w-3.5" /> Freeze account
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="mt-6 flex gap-6 border-b border-slate-200">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                "relative pb-2.5 text-sm font-medium transition",
                tab === t ? "text-navy" : "text-subtle hover:text-navy"
              )}
            >
              {t}
              {tab === t && (
                <motion.span layoutId="acct-tab" className="absolute inset-x-0 -bottom-px h-0.5 bg-gold" />
              )}
            </button>
          ))}
        </div>
      </motion.div>

      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="mt-6"
        >
          {tab === "Transactions" && (
            <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
              {/* Filter bar */}
              <div className="flex flex-wrap items-center gap-3 border-b border-slate-100 p-4">
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    value={search}
                    onChange={(e) => {
                      setSearch(e.target.value);
                      setPage(1);
                    }}
                    placeholder="Search descriptions, merchants…"
                    className="h-9 w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-sm outline-none focus:border-navy focus:bg-white"
                  />
                </div>
                <select
                  value={rangeIdx}
                  onChange={(e) => {
                    setRangeIdx(Number(e.target.value));
                    setPage(1);
                  }}
                  className="h-9 rounded-lg border border-slate-200 bg-white px-2.5 text-sm outline-none focus:border-navy"
                >
                  {RANGES.map((r, i) => (
                    <option key={r.label} value={i}>
                      {r.label}
                    </option>
                  ))}
                </select>
                <select
                  value={type}
                  onChange={(e) => {
                    setType(e.target.value);
                    setPage(1);
                  }}
                  className="h-9 rounded-lg border border-slate-200 bg-white px-2.5 text-sm outline-none focus:border-navy"
                >
                  {TXN_TYPE_OPTS.map((t) => (
                    <option key={t} value={t}>
                      {t === "" ? "All types" : capitalize(t)}
                    </option>
                  ))}
                </select>
                {(search || type || rangeIdx !== 0) && (
                  <button
                    onClick={() => {
                      setSearch("");
                      setType("");
                      setRangeIdx(0);
                      setPage(1);
                    }}
                    className="text-xs font-medium text-navy hover:underline"
                  >
                    Reset filters
                  </button>
                )}
                <span className="ml-auto text-xs text-subtle tabular-nums">{total} transactions</span>
              </div>

              {/* Table */}
              <table className="w-full text-sm">
                <thead className="sticky top-[60px] bg-white">
                  <tr className="border-b border-slate-100 text-left text-[11px] uppercase tracking-[0.06em] text-slate-500">
                    <th
                      className="cursor-pointer px-5 py-3 font-medium"
                      onClick={() => setSortDesc((v) => !v)}
                    >
                      Date {sortDesc ? "↓" : "↑"}
                    </th>
                    <th className="px-3 py-3 font-medium">Description</th>
                    <th className="px-3 py-3 font-medium">Type</th>
                    <th className="px-3 py-3 font-medium">Status</th>
                    <th className="px-3 py-3 text-right font-medium">Amount</th>
                    <th className="px-5 py-3 text-right font-medium">Balance</th>
                  </tr>
                </thead>
                <tbody>
                  {q.isLoading &&
                    Array.from({ length: 5 }).map((_, i) => (
                      <tr key={i}>
                        <td colSpan={6} className="px-5 py-2">
                          <div className="h-8 animate-pulse rounded bg-slate-50" />
                        </td>
                      </tr>
                    ))}
                  {!q.isLoading && txns.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-5 py-12 text-center text-subtle">
                        No transactions match your filters.
                      </td>
                    </tr>
                  )}
                  {!q.isLoading &&
                    txns.map((t, i) => (
                      <Fragment key={t.id}>
                        <motion.tr
                          initial={{ opacity: 0, y: 6 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.03 }}
                          onClick={() => setExpanded(expanded === t.id ? null : t.id)}
                          className="cursor-pointer border-t border-slate-50 transition hover:bg-slate-50"
                        >
                          <td className="whitespace-nowrap px-5 py-3 text-subtle">
                            {fmtDate(t.occurredAt)}
                          </td>
                          <td className="px-3 py-3">
                            <span className="flex items-center gap-1 font-medium text-body">
                              {t.description}
                              <ChevronDown
                                className={cn(
                                  "h-3.5 w-3.5 text-slate-400 transition-transform",
                                  expanded === t.id && "rotate-180"
                                )}
                              />
                            </span>
                          </td>
                          <td className="px-3 py-3 text-subtle">{capitalize(t.type)}</td>
                          <td className="px-3 py-3">
                            <StatusBadge status={statusLabel(t.status)} />
                          </td>
                          <td className="px-3 py-3 text-right font-medium tabular-nums">
                            <MoneyText amount={txnAmount(t)} />
                          </td>
                          <td className="whitespace-nowrap px-5 py-3 text-right tabular-nums text-subtle">
                            {t.runningBalance != null ? fmtMoney(t.runningBalance) : "—"}
                          </td>
                        </motion.tr>
                        <AnimatePresence>
                          {expanded === t.id && (
                            <motion.tr
                              key={`${t.id}-detail`}
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              exit={{ opacity: 0 }}
                            >
                              <td colSpan={6} className="border-t border-slate-100 bg-slate-50/70 px-5 py-4">
                                <motion.div
                                  initial={{ height: 0, opacity: 0 }}
                                  animate={{ height: "auto", opacity: 1 }}
                                  exit={{ height: 0, opacity: 0 }}
                                  className="grid grid-cols-2 gap-x-8 gap-y-1.5 overflow-hidden text-xs md:grid-cols-4"
                                >
                                  <div>
                                    <p className="text-slate-500">Transaction ID</p>
                                    <p className="mt-0.5 font-mono text-body">{t.txnId}</p>
                                  </div>
                                  <div>
                                    <p className="text-slate-500">Category</p>
                                    <p className="mt-0.5">
                                      <span className="rounded-full bg-navy/5 px-2 py-0.5 font-medium text-navy">
                                        {t.category}
                                      </span>
                                    </p>
                                  </div>
                                  <div>
                                    <p className="text-slate-500">Merchant</p>
                                    <p className="mt-0.5 text-body">{t.merchant ?? "—"} · Brooklyn, NY</p>
                                  </div>
                                  <div className="flex items-end gap-3">
                                    <button
                                      className="font-medium text-navy hover:underline"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        toast.success("Receipt downloaded");
                                      }}
                                    >
                                      Download receipt
                                    </button>
                                    <button
                                      className="font-medium text-[#B42318] hover:underline"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        toast("Report submitted", {
                                          description: "Our fraud team will review this transaction.",
                                        });
                                      }}
                                    >
                                      Report a problem
                                    </button>
                                  </div>
                                </motion.div>
                              </td>
                            </motion.tr>
                          )}
                        </AnimatePresence>
                      </Fragment>
                    ))}
                </tbody>
              </table>

              {/* Pagination */}
              <div className="flex items-center justify-between border-t border-slate-100 px-5 py-3 text-xs text-subtle">
                <span className="tabular-nums">
                  Showing {total === 0 ? 0 : (page - 1) * pageSize + 1}–{Math.min(page * pageSize, total)} of {total}
                </span>
                <div className="flex items-center gap-2">
                  <select
                    value={pageSize}
                    onChange={(e) => {
                      setPageSize(Number(e.target.value));
                      setPage(1);
                    }}
                    className="h-8 rounded-lg border border-slate-200 px-2 outline-none"
                  >
                    {[10, 25, 50].map((n) => (
                      <option key={n} value={n}>
                        {n} / page
                      </option>
                    ))}
                  </select>
                  <button
                    disabled={page <= 1}
                    onClick={() => setPage((p) => p - 1)}
                    className="rounded-lg border border-slate-200 p-1.5 transition hover:border-navy disabled:opacity-40"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                  <span className="tabular-nums">
                    {page} / {pages}
                  </span>
                  <button
                    disabled={page >= pages}
                    onClick={() => setPage((p) => p + 1)}
                    className="rounded-lg border border-slate-200 p-1.5 transition hover:border-navy disabled:opacity-40"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {tab === "Details" && acct && (
            <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
              <dl className="grid grid-cols-1 gap-x-12 gap-y-4 text-sm md:grid-cols-2">
                {[
                  ["Account type", capitalize(acct.type)],
                  ["Routing number", "021000089"],
                  ["Opened", fmtDate(acct.openedAt)],
                  [
                    "Interest rate",
                    acct.apy ? `${num(acct.apy).toFixed(2)}% APY` : "—",
                  ],
                  ["Overdraft protection", acct.type === "checking" ? "On" : "N/A"],
                  ["Linked overdraft account", acct.type === "checking" ? "High-Yield Savings •••• 9034" : "—"],
                  ["Paperless statements", "On"],
                  ["Currency", acct.currency],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between border-b border-slate-50 pb-3">
                    <dt className="text-subtle">{k}</dt>
                    <dd className="font-medium text-body">{v}</dd>
                  </div>
                ))}
                <div className="flex justify-between border-b border-slate-50 pb-3">
                  <dt className="text-subtle">Account number</dt>
                  <dd className="font-medium text-body">
                    <AccountNumber last4={acct.last4} full={acct.accountNumber} />
                  </dd>
                </div>
              </dl>
            </div>
          )}

          {tab === "Statements" && (
            <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
              <ul className="divide-y divide-slate-100">
                {[
                  ["February 2025 — Feb 01–Feb 14 (partial)", "PDF · 182 KB"],
                  ["January 2025", "PDF · 248 KB"],
                  ["December 2024", "PDF · 261 KB"],
                  ["November 2024", "PDF · 233 KB"],
                  ["October 2024", "PDF · 240 KB"],
                ].map(([label, size], i) => (
                  <motion.li
                    key={label}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-3 px-5 py-3.5"
                  >
                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-50">
                      <FileText className="h-4.5 w-4.5 text-[#B42318]" />
                    </span>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-body">{label}</p>
                      <p className="text-xs text-subtle">{size}</p>
                    </div>
                    <button
                      onClick={() => toast.success("Statement download started")}
                      className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-navy transition hover:border-navy"
                    >
                      <Download className="h-3.5 w-3.5" /> Download
                    </button>
                  </motion.li>
                ))}
              </ul>
              <p className="border-t border-amber-100 bg-amber-50 px-5 py-3 text-xs text-amber-800">
                Statements are available for the past 7 years.
              </p>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </BankingLayout>
  );
}
