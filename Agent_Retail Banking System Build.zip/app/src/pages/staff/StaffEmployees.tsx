import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { toast, Toaster } from "sonner";
import { Building2, UserPlus, Search, Phone, MapPin } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useSession } from "@/hooks/useSession";
import DataTable, { type Column } from "@/components/shared/DataTable";
import StatusBadge from "@/components/shared/StatusBadge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

type EmployeeRow = {
  id: number;
  employeeNo: string;
  name: string;
  email: string;
  role: "teller" | "manager" | "admin";
  status: "active" | "on_leave" | "terminated";
  hiredAt: string;
  branch: { id: number; code: string; name: string } | null;
};

type BranchRow = { id: number; code: string; name: string; address: string; phone: string };

const ROLE_STYLE: Record<string, string> = {
  admin: "bg-[#2DD4A8]/15 text-[#2DD4A8]",
  manager: "bg-blue-500/15 text-blue-300",
  teller: "bg-slate-500/20 text-slate-300",
};
const ROLE_LABEL: Record<string, string> = { admin: "Admin", manager: "Relationship Manager", teller: "Teller" };
const EMP_STATUS_LABEL: Record<string, string> = { active: "Active", on_leave: "On leave", terminated: "Deactivated" };

const AVATARS: Record<string, string> = {
  "Marcus Chen": "/avatar-marcus.png",
  "Priya Sharma": "/avatar-priya.png",
  "Jordan Ellis": "/avatar-jordan.png",
};

function Avatar({ name }: { name: string }) {
  const src = AVATARS[name];
  if (src) return <img src={src} alt={name} className="h-8 w-8 rounded-full object-cover" />;
  const initials = name.split(" ").map((p) => p[0]).slice(0, 2).join("");
  return (
    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-staff-raised text-[11px] font-semibold text-[#2DD4A8]">
      {initials}
    </span>
  );
}

export default function StaffEmployees() {
  const { role } = useSession();
  const [tab, setTab] = useState<"employees" | "branches">("employees");
  const employeesQuery = trpc.staff.listEmployees.useQuery();
  const branchesQuery = trpc.staff.listBranches.useQuery();
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [branchFilter, setBranchFilter] = useState("all");
  const [addOpen, setAddOpen] = useState(false);
  const [viewBranch, setViewBranch] = useState<number | null>(null);

  const employees = (employeesQuery.data ?? []) as EmployeeRow[];
  const branches = (branchesQuery.data ?? []) as BranchRow[];

  const filtered = useMemo(() => {
    let list = employees;
    if (roleFilter !== "all") list = list.filter((e) => e.role === roleFilter);
    if (branchFilter !== "all") list = list.filter((e) => e.branch?.code === branchFilter);
    if (viewBranch != null) list = list.filter((e) => e.branch?.id === viewBranch);
    if (search) {
      const q = search.toLowerCase();
      list = list.filter((e) => e.name.toLowerCase().includes(q) || e.email.toLowerCase().includes(q) || e.employeeNo.toLowerCase().includes(q));
    }
    return list;
  }, [employees, search, roleFilter, branchFilter, viewBranch]);

  const onLeave = employees.filter((e) => e.status === "on_leave").length;

  const columns: Column<EmployeeRow>[] = [
    {
      key: "employee", header: "Employee",
      render: (r) => (
        <div className="flex items-center gap-2.5">
          <Avatar name={r.name} />
          <div>
            <div className="font-medium text-staff-text">{r.name}</div>
            <div className="text-[11px] text-staff-subtle">{r.email}</div>
          </div>
        </div>
      ),
      sortValue: (r) => r.name,
    },
    { key: "id", header: "ID", render: (r) => <span className="font-mono text-[12px] text-[#2DD4A8]">{r.employeeNo}</span> },
    {
      key: "role", header: "Role",
      render: (r) => <span className={cn("rounded-full px-2.5 py-0.5 text-[11.5px] font-medium", ROLE_STYLE[r.role])}>{ROLE_LABEL[r.role]}</span>,
      sortValue: (r) => r.role,
    },
    { key: "branch", header: "Branch", render: (r) => <span className="text-staff-subtle">{r.branch?.name ?? "—"}</span> },
    { key: "status", header: "Status", render: (r) => (
      <span className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11.5px] font-medium",
        r.status === "active" && "bg-emerald-500/15 text-emerald-300",
        r.status === "on_leave" && "bg-amber-500/15 text-amber-300",
        r.status === "terminated" && "bg-slate-500/20 text-slate-300",
      )}>
        <span className={cn("h-1.5 w-1.5 rounded-full", r.status === "active" ? "bg-emerald-400" : r.status === "on_leave" ? "bg-amber-400" : "bg-slate-400")} />
        {EMP_STATUS_LABEL[r.status]}
      </span>
    ) },
    { key: "since", header: "Since", render: (r) => <span className="tabular-nums text-staff-subtle">{r.hiredAt.slice(0, 4)}</span>, sortValue: (r) => r.hiredAt },
    {
      key: "actions", header: "",
      render: (r) => (
        <div className="flex gap-2 text-[11.5px]">
          <button onClick={() => toast.info(`Edit ${r.name} — demo build is read-only for employee administration`)} className="text-[#2DD4A8] hover:underline">Edit</button>
          <button onClick={() => toast.info(`Password reset link sent to ${r.email} (demo)`)} className="text-staff-subtle hover:text-staff-text">Reset password</button>
          {r.status !== "terminated" && (
            <button
              onClick={() => role === "admin" ? toast.success(`${r.name} deactivated (demo)`) : toast.error("Only Admin can deactivate employees")}
              className="text-red-400 hover:underline"
            >
              Deactivate
            </button>
          )}
        </div>
      ),
    },
  ];

  const staffCount = (b: BranchRow) => employees.filter((e) => e.branch?.id === b.id).length;

  return (
    <div className="space-y-5">
      <Toaster position="top-right" theme="dark" richColors />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-semibold text-staff-text">Employees & Branches</h1>
          <p className="text-xs text-staff-subtle">Directory, roles and branch network</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex gap-2 text-xs text-staff-subtle">
            <span className="rounded-lg border border-staff-border bg-staff-panel px-3 py-1.5"><span className="font-mono text-[#2DD4A8]">{employees.length}</span> employees</span>
            <span className="rounded-lg border border-staff-border bg-staff-panel px-3 py-1.5"><span className="font-mono text-[#2DD4A8]">{branches.length}</span> branches</span>
            <span className="rounded-lg border border-staff-border bg-staff-panel px-3 py-1.5"><span className="font-mono text-amber-300">{onLeave}</span> on leave</span>
          </div>
          <button
            onClick={() => setAddOpen(true)}
            className="flex items-center gap-1.5 rounded-lg bg-[#2DD4A8] px-3.5 py-2 text-xs font-semibold text-[#0B1118] hover:bg-[#2DD4A8]/90"
          >
            <UserPlus className="h-3.5 w-3.5" /> Add employee
          </button>
        </div>
      </div>

      <Tabs value={tab} onValueChange={(v) => { setTab(v as typeof tab); setViewBranch(null); }}>
        <TabsList className="border border-staff-border bg-staff-panel">
          <TabsTrigger value="employees">Employees</TabsTrigger>
          <TabsTrigger value="branches">Branches</TabsTrigger>
        </TabsList>
      </Tabs>

      {tab === "employees" && (
        <>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-staff-subtle" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search name, email, ID…"
                className="w-64 rounded-lg border border-staff-border bg-staff-panel py-2 pl-8 pr-3 text-[12.5px] text-staff-text placeholder:text-staff-subtle focus:outline-none focus:ring-1 focus:ring-[#2DD4A8]"
              />
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="h-9 w-44 border-staff-border bg-staff-panel text-xs text-staff-text"><SelectValue /></SelectTrigger>
              <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
                <SelectItem value="all">All roles</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="manager">Relationship Manager</SelectItem>
                <SelectItem value="teller">Teller</SelectItem>
              </SelectContent>
            </Select>
            <Select value={branchFilter} onValueChange={setBranchFilter}>
              <SelectTrigger className="h-9 w-44 border-staff-border bg-staff-panel text-xs text-staff-text"><SelectValue /></SelectTrigger>
              <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
                <SelectItem value="all">All branches</SelectItem>
                {branches.map((b) => <SelectItem key={b.id} value={b.code}>{b.name}</SelectItem>)}
              </SelectContent>
            </Select>
            {viewBranch != null && (
              <button onClick={() => setViewBranch(null)} className="rounded-lg border border-[#2DD4A8]/40 px-3 py-1.5 text-xs text-[#2DD4A8]">
                Clear branch filter
              </button>
            )}
          </div>
          {employeesQuery.isLoading ? (
            <div className="space-y-2 rounded-xl border border-staff-border bg-staff-panel p-4">
              {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-11 w-full bg-staff-raised" />)}
            </div>
          ) : (
            <DataTable dark columns={columns} data={filtered} pageSize={12} rowKey={(r) => r.employeeNo} emptyMessage="No employees match the filters." />
          )}
        </>
      )}

      {tab === "branches" && (
        branchesQuery.isLoading ? (
          <div className="grid gap-4 md:grid-cols-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-48 w-full bg-staff-panel" />)}</div>
        ) : (
          <div className="grid gap-4 md:grid-cols-3">
            {branches.map((b, i) => (
              <motion.div
                key={b.code}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="rounded-xl border border-staff-border bg-staff-panel p-5"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-5 w-5 text-[#2DD4A8]" />
                    <h3 className="font-semibold text-staff-text">{b.name}</h3>
                  </div>
                  <StatusBadge dark status="Active" />
                </div>
                <div className="mt-1 font-mono text-[12px] text-staff-subtle">{b.code}</div>
                <div className="mt-3 space-y-1.5 text-[12.5px] text-staff-subtle">
                  <div className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> {b.address}</div>
                  <div className="flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" /> {b.phone}</div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2 border-t border-staff-border pt-3 text-[12px]">
                  <div><div className="text-staff-subtle">Staff</div><div className="font-mono tabular-nums text-staff-text">{staffCount(b)}</div></div>
                  <div><div className="text-staff-subtle">Hours</div><div className="text-staff-text">Mon–Fri 9–5</div></div>
                </div>
                <div className="mt-4 flex gap-2">
                  <button
                    onClick={() => { setTab("employees"); setViewBranch(b.id); }}
                    className="flex-1 rounded-lg border border-[#2DD4A8]/40 px-3 py-1.5 text-xs font-medium text-[#2DD4A8] hover:bg-[#2DD4A8]/10"
                  >
                    View staff
                  </button>
                  <button onClick={() => toast.info("Branch editing is Admin-only in this demo build")} className="rounded-lg border border-staff-border px-3 py-1.5 text-xs text-staff-subtle hover:text-staff-text">Edit</button>
                </div>
              </motion.div>
            ))}
          </div>
        )
      )}

      {/* Add employee modal (demo read-only backend) */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="border-staff-border bg-staff-panel text-staff-text">
          <DialogHeader>
            <DialogTitle className="text-base">Add employee</DialogTitle>
            <DialogDescription className="text-staff-subtle">
              Employee provisioning is restricted to HR systems in this demo build; submission is simulated and logged.
            </DialogDescription>
          </DialogHeader>
          <AddEmployeeForm branches={branches} onDone={() => { setAddOpen(false); toast.success("Employee provisioning request submitted (demo)"); }} />
        </DialogContent>
      </Dialog>
    </div>
  );
}

function AddEmployeeForm({ branches, onDone }: { branches: BranchRow[]; onDone: () => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("teller");
  const [branch, setBranch] = useState("");
  const valid = name && email.includes("@") && branch;
  return (
    <div className="space-y-3">
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" className="w-full rounded-lg border border-staff-border bg-staff-raised px-3 py-2 text-sm text-staff-text placeholder:text-staff-subtle focus:outline-none focus:ring-1 focus:ring-[#2DD4A8]" />
      <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Work email" className="w-full rounded-lg border border-staff-border bg-staff-raised px-3 py-2 text-sm text-staff-text placeholder:text-staff-subtle focus:outline-none focus:ring-1 focus:ring-[#2DD4A8]" />
      <div className="grid grid-cols-2 gap-3">
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger className="border-staff-border bg-staff-raised text-staff-text"><SelectValue /></SelectTrigger>
          <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
            <SelectItem value="teller">Teller</SelectItem>
            <SelectItem value="manager">Relationship Manager</SelectItem>
            <SelectItem value="admin">Admin</SelectItem>
          </SelectContent>
        </Select>
        <Select value={branch} onValueChange={setBranch}>
          <SelectTrigger className="border-staff-border bg-staff-raised text-staff-text"><SelectValue placeholder="Branch" /></SelectTrigger>
          <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
            {branches.map((b) => <SelectItem key={b.id} value={b.code}>{b.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="rounded-lg border border-staff-border bg-staff-raised p-3 text-[11.5px] text-staff-subtle">
        {role === "admin" && "Admin: full console access, maker-checker final approval, rule edits, employee administration."}
        {role === "manager" && "Relationship Manager: approve KYC/loans/card requests, manage assigned customers."}
        {role === "teller" && "Teller: view queues, standard KYC review, transaction lookups. Cannot approve EDD or loans."}
      </div>
      <DialogFooter className="gap-2">
        <button onClick={onDone} className="rounded-lg border border-staff-border px-4 py-2 text-sm text-staff-subtle hover:text-staff-text">Cancel</button>
        <button disabled={!valid} onClick={onDone} className="rounded-lg bg-[#2DD4A8] px-4 py-2 text-sm font-semibold text-[#0B1118] disabled:opacity-40">
          Submit request
        </button>
      </DialogFooter>
    </div>
  );
}
