import { useState } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, X } from "lucide-react";
import { toast } from "sonner";
import BankingLayout from "@/components/banking/BankingLayout";
import AccountNumber from "@/components/shared/AccountNumber";
import StatusBadge from "@/components/shared/StatusBadge";
import { trpc } from "@/providers/trpc";
import { fmtMoney, num, statusLabel } from "@/components/banking/format";

const cardAnim = (i: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.08, duration: 0.4, ease: "easeOut" as const },
});

export default function Accounts() {
  const q = trpc.customer.listAccounts.useQuery();
  const [modal, setModal] = useState(false);

  const accounts = q.data ?? [];
  const bank = accounts.filter((a) => a.type === "checking" || a.type === "savings");
  const creditCards = accounts.filter((a) => a.type === "credit");
  const loans = accounts.filter((a) => a.type === "mortgage");
  const totalDeposits = bank.reduce((s, a) => s + num(a.balance), 0);
  const totalCredit = creditCards.reduce((s, a) => s + num(a.balance), 0);
  const totalLoans = loans.reduce((s, a) => s + num(a.balance), 0);

  return (
    <BankingLayout>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h1 className="font-display text-[28px] font-bold text-navy">Accounts</h1>
        <div className="flex flex-wrap gap-2 text-xs">
          <span className="rounded-full border border-slate-200 bg-white px-3 py-1.5 tabular-nums text-body">
            Total deposits: <b className="text-navy">{fmtMoney(totalDeposits)}</b>
          </span>
          <span className="rounded-full border border-slate-200 bg-white px-3 py-1.5 tabular-nums text-body">
            Total credit used: <b className="text-navy">{fmtMoney(totalCredit)}</b>
          </span>
          <span className="rounded-full border border-slate-200 bg-white px-3 py-1.5 tabular-nums text-body">
            Total loan balance: <b className="text-navy">{fmtMoney(totalLoans)}</b>
          </span>
        </div>
      </div>

      {q.isLoading ? (
        <div className="mt-6 grid grid-cols-2 gap-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="h-32 animate-pulse rounded-xl border border-slate-200 bg-white" />
          ))}
        </div>
      ) : q.isError ? (
        <div className="mt-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-[#B42318]">
          Couldn't load accounts. Please refresh.
        </div>
      ) : (
        <>
          {/* Bank Accounts */}
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-8 text-[11px] font-semibold uppercase tracking-[0.06em] text-slate-500"
          >
            Bank Accounts
          </motion.h2>
          <div className="mt-3 grid grid-cols-1 gap-4 md:grid-cols-2">
            {bank.map((a, i) => (
              <motion.div key={a.id} {...cardAnim(i)}>
                <Link
                  to={`/banking/accounts/${a.id}`}
                  className="block rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-navy/40 hover:shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-navy">{a.nickname}</p>
                    <StatusBadge status={statusLabel(a.status)} />
                  </div>
                  <AccountNumber last4={a.last4} className="mt-1 text-xs text-subtle" />
                  <div className="mt-4 flex items-end justify-between">
                    <div>
                      <p className="text-[11px] uppercase tracking-[0.06em] text-slate-500">Available</p>
                      <p className="font-display text-2xl font-bold tabular-nums text-navy">{fmtMoney(a.balance)}</p>
                    </div>
                    <div className="text-right text-xs text-subtle">
                      {a.type === "savings" && a.apy && <p>{num(a.apy).toFixed(2)}% APY</p>}
                      <p>Routing 021000089</p>
                    </div>
                  </div>
                  <p className="mt-3 text-xs font-semibold text-navy">View details →</p>
                </Link>
              </motion.div>
            ))}
            {/* Open a new account */}
            <motion.button
              {...cardAnim(bank.length)}
              onClick={() => setModal(true)}
              className="flex min-h-36 flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-300 bg-white/50 text-slate-500 transition hover:border-gold hover:text-navy"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100">
                <Plus className="h-5 w-5" />
              </span>
              <span className="text-sm font-medium">Open a new account</span>
            </motion.button>
          </div>

          {/* Credit Cards */}
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.15 }}
            className="mt-8 text-[11px] font-semibold uppercase tracking-[0.06em] text-slate-500"
          >
            Credit Cards
          </motion.h2>
          <div className="mt-3 grid grid-cols-1 gap-4 md:grid-cols-2">
            {creditCards.map((a, i) => {
              const pct = Math.round((num(a.balance) / num(a.creditLimit)) * 100);
              return (
                <motion.div key={a.id} {...cardAnim(i + 2)}>
                  <Link
                    to={`/banking/accounts/${a.id}`}
                    className="flex gap-4 rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-navy/40 hover:shadow-md"
                  >
                    <img src="/card-platinum.png" alt="" className="h-[72px] w-[114px] rounded-md object-cover" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-navy">{a.nickname}</p>
                        <StatusBadge status={statusLabel(a.status)} />
                      </div>
                      <AccountNumber last4={a.last4} className="mt-0.5 text-xs text-subtle" />
                      <div className="mt-2 flex items-baseline gap-2">
                        <p className="font-display text-xl font-bold tabular-nums text-navy">{fmtMoney(a.balance)}</p>
                        <p className="text-xs text-subtle">of {fmtMoney(a.creditLimit)} limit</p>
                      </div>
                      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100">
                        <motion.div
                          className="h-full rounded-full bg-money"
                          initial={{ width: 0 }}
                          whileInView={{ width: `${pct}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.9, ease: "easeOut" }}
                        />
                      </div>
                      <p className="mt-1.5 text-xs text-subtle">{pct}% utilized · Due Mar 1</p>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
            {creditCards.length === 0 && (
              <p className="rounded-xl border border-slate-200 bg-white p-5 text-sm text-subtle">
                No credit cards.
              </p>
            )}
          </div>

          {/* Loans */}
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.25 }}
            className="mt-8 text-[11px] font-semibold uppercase tracking-[0.06em] text-slate-500"
          >
            Loans
          </motion.h2>
          <div className="mt-3 grid grid-cols-1 gap-4 md:grid-cols-2">
            {loans.map((a, i) => (
              <motion.div key={a.id} {...cardAnim(i + 3)}>
                <Link
                  to={`/banking/accounts/${a.id}`}
                  className="block rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-navy/40 hover:shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-navy">{a.nickname}</p>
                    <StatusBadge status={statusLabel(a.status)} />
                  </div>
                  <p className="mt-0.5 font-mono text-xs text-subtle">LN-2019-0442 · •••• {a.last4}</p>
                  <div className="mt-3 flex items-baseline gap-2">
                    <p className="font-display text-xl font-bold tabular-nums text-navy">{fmtMoney(a.balance)}</p>
                    <p className="text-xs text-subtle">remaining of $410,000</p>
                  </div>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100">
                    <motion.div
                      className="h-full rounded-full bg-navy"
                      initial={{ width: 0 }}
                      whileInView={{ width: "24%" }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.9, ease: "easeOut" }}
                    />
                  </div>
                  <p className="mt-1.5 text-xs text-subtle">
                    24% paid · Rate 5.85% · Next payment $2,412.19 on Mar 1
                  </p>
                </Link>
              </motion.div>
            ))}
            {loans.length === 0 && (
              <p className="rounded-xl border border-slate-200 bg-white p-5 text-sm text-subtle">
                No loans.{" "}
                <Link to="/banking/loans?apply=1" className="font-medium text-navy hover:underline">
                  Apply for one →
                </Link>
              </p>
            )}
          </div>
        </>
      )}

      {/* New account modal */}
      <AnimatePresence>
        {modal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-navy-deep/50 p-4"
            onClick={() => setModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, y: 24, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 12, scale: 0.98 }}
              className="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between">
                <h3 className="font-display text-lg font-semibold text-navy">Open a new account</h3>
                <button onClick={() => setModal(false)} className="text-slate-400 hover:text-navy">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="mt-4 space-y-3">
                {[
                  { name: "Everyday Checking", desc: "No monthly fee with direct deposit · $25 min opening" },
                  { name: "High-Yield Savings", desc: "4.35% APY · No minimum balance" },
                  { name: "Certificate of Deposit", desc: "Up to 4.80% APY · 6–60 month terms" },
                ].map((p) => (
                  <button
                    key={p.name}
                    onClick={() => {
                      setModal(false);
                      toast.success("Application submitted", {
                        description: `${p.name} application received. We'll email you within 1 business day.`,
                      });
                    }}
                    className="w-full rounded-xl border border-slate-200 p-4 text-left transition hover:border-gold hover:bg-amber-50/40"
                  >
                    <p className="font-medium text-navy">{p.name}</p>
                    <p className="mt-0.5 text-xs text-subtle">{p.desc}</p>
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </BankingLayout>
  );
}
