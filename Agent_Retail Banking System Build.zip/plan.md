# Retail Banking System (Front + Back Office) — Plan

## Goal
Build a realistic-looking retail banking system (customer-facing front office + staff back office) to be used for developing demo agents.

## Stage 0 — Research & Scoping
- Explore referenced repos (madhavappaneni/Retail-Banking-Application, github topics/bank-management-system) + search for best-in-class reference repos.
- Extract: typical modules, schema entities, workflows (onboarding, accounts, transactions, loans, KYC, admin).

## Stage 1 — Requirements lock (ask_user)
- Scope: modules, tech stack, persistence, auth, seed data scale.

## Stage 2 — Architecture & Schema
- Design DB schema (customers, accounts, transactions, loans, cards, branches, employees, audit log).
- API surface for both front and back office.

## Stage 3 — Build (swarm)
- Load vibecoding-webapp-swarm + webapp-building-swarm + backend-building-swarm.
- Frontend: customer portal (dashboard, transfers, statements, cards, loans).
- Back office: admin console (customer mgmt, KYC review, transaction monitoring, loan approvals, employee mgmt).
- Backend: tRPC + Drizzle + MySQL, auth, seed data with realistic transactions.

## Stage 4 — Validation & Delivery
- Build, test flows, save website version via website_version_manager.
