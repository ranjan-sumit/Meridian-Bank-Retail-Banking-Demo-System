import { useRef } from "react";
import { Link } from "react-router";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { SplitText } from "gsap/SplitText";
import { useGSAP } from "@gsap/react";
import Lenis from "lenis";
import {
  ShieldCheck,
  Zap,
  Headphones,
  Wallet,
  PiggyBank,
  CreditCard,
  Home as HomeIcon,
  ChevronDown,
  Star,
  Lock,
  Radar,
  Fingerprint,
  BadgeCheck,
} from "lucide-react";

gsap.registerPlugin(ScrollTrigger, SplitText);

const PRODUCTS = [
  {
    icon: Wallet,
    name: "Everyday Checking",
    rate: "No monthly fee",
    rateSub: "with $1,500 balance",
    bullets: ["Fee-free at 40,000+ ATMs", "Instant card freeze in-app", "Early direct deposit — paid 2 days sooner"],
    anchor: "personal",
  },
  {
    icon: PiggyBank,
    name: "High-Yield Savings",
    rate: "4.35% APY",
    rateSub: "on every dollar, no tiers",
    bullets: ["No minimums, no monthly fees", "Automatic savings round-ups", "FDIC insured to $250,000"],
    anchor: "personal",
  },
  {
    icon: CreditCard,
    name: "Platinum Rewards Card",
    rate: "3x points",
    rateSub: "on travel & dining",
    bullets: ["$0 annual fee first year", "No foreign transaction fees", "Real-time fraud alerts"],
    anchor: "cards",
  },
  {
    icon: HomeIcon,
    name: "Home Mortgage",
    rate: "6.1% APR",
    rateSub: "30-year fixed, from",
    bullets: ["Pre-approval in 15 minutes", "Dedicated loan officer", "Rate lock up to 90 days"],
    anchor: "mortgages",
  },
];

const RATES = [
  ["Savings APY", "4.35%"],
  ["12-mo CD", "4.80%"],
  ["30-yr Fixed", "6.12%"],
  ["15-yr Fixed", "5.48%"],
  ["Auto Loan", "5.9%"],
  ["Personal Loan", "9.9%"],
] as const;

const SECURITY_STATS = [
  { value: 12418, label: "suspicious logins blocked this month" },
  { value: 99.98, label: "fraud attempts intercepted", suffix: "%", decimals: 2 },
  { value: 41, label: "seconds — median fraud alert delivery", suffix: "s" },
  { value: 0, label: "customer liability for unauthorized charges", prefix: "$" },
];

const TESTIMONIALS = [
  {
    quote: "Switched from a big-4 bank and never looked back. The savings rate alone pays for my coffee habit.",
    name: "Daniel R.",
    city: "Chicago",
  },
  {
    quote: "A real person answered in under a minute at 11pm. I didn't think banks did that anymore.",
    name: "Maria L.",
    city: "Austin",
  },
  {
    quote: "The app flagged a fraudulent charge before I even noticed it. That's when I became a customer for life.",
    name: "James T.",
    city: "Seattle",
  },
];

export default function Home() {
  const root = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

      // Lenis smooth scroll (landing only), synced with ScrollTrigger
      let lenis: Lenis | undefined;
      if (!reduced) {
        lenis = new Lenis({ lerp: 0.1 });
        lenis.on("scroll", ScrollTrigger.update);
        const raf = (time: number) => lenis!.raf(time * 1000);
        gsap.ticker.add(raf);
        gsap.ticker.lagSmoothing(0);
      }

      // --- Hero: SplitText headline reveal ---
      const split = new SplitText(".hero-headline", { type: "chars" });
      gsap.from(split.chars, {
        y: 40,
        opacity: 0,
        stagger: 0.02,
        duration: 0.8,
        ease: "power3.out",
      });
      gsap.from(".hero-fade", {
        y: 24,
        opacity: 0,
        stagger: 0.1,
        duration: 0.7,
        delay: 0.3,
        ease: "power2.out",
      });

      // Ken Burns background zoom 1.0 -> 1.08, 12s yoyo loop
      if (!reduced) {
        gsap.to(".hero-bg", {
          scale: 1.08,
          duration: 12,
          ease: "sine.inOut",
          repeat: -1,
          yoyo: true,
        });
        gsap.to(".hero-chevron", { y: 8, duration: 0.9, repeat: -1, yoyo: true, ease: "sine.inOut" });
      }

      if (!reduced) {
        // --- Pinned horizontal product carousel (150vh) ---
        const track = document.querySelector<HTMLElement>(".products-track");
        if (track) {
          const distance = track.scrollWidth - window.innerWidth;
          const tl = gsap.timeline({
            scrollTrigger: {
              trigger: ".products-pin",
              start: "top top",
              end: "+=150%",
              pin: true,
              scrub: 1,
            },
          });
          tl.to(track, { x: -Math.max(0, distance), ease: "none" });
          // Active card emphasis
          const cards = gsap.utils.toArray<HTMLElement>(".product-card");
          cards.forEach((card, i) => {
            gsap.fromTo(
              card,
              { scale: 0.92, opacity: 0.6 },
              {
                scale: 1,
                opacity: 1,
                scrollTrigger: {
                  trigger: ".products-pin",
                  start: `top+=${(i / cards.length) * 120}% top`,
                  end: `top+=${((i + 1) / cards.length) * 120}% top`,
                  scrub: true,
                },
              }
            );
          });
        }

        // --- Why Meridian: clip-path reveal + feature rows stagger ---
        gsap.fromTo(
          ".why-image",
          { clipPath: "inset(20% 20% 20% 20% round 16px)" },
          {
            clipPath: "inset(0% 0% 0% 0% round 16px)",
            duration: 1,
            ease: "power2.out",
            scrollTrigger: { trigger: ".why-section", start: "top 75%" },
          }
        );
        gsap.from(".why-feature", {
          x: 24,
          opacity: 0,
          stagger: 0.12,
          duration: 0.6,
          ease: "power2.out",
          scrollTrigger: { trigger: ".why-section", start: "top 70%" },
        });
      }

      // --- Security counters ---
      document.querySelectorAll<HTMLElement>(".sec-counter").forEach((el) => {
        const target = parseFloat(el.dataset.value || "0");
        const decimals = parseInt(el.dataset.decimals || "0", 10);
        const obj = { v: 0 };
        gsap.to(obj, {
          v: target,
          duration: reduced ? 0 : 1.5,
          ease: "power1.out",
          scrollTrigger: { trigger: el, start: "top 85%" },
          onUpdate() {
            el.textContent = obj.v.toLocaleString("en-US", {
              minimumFractionDigits: decimals,
              maximumFractionDigits: decimals,
            });
          },
        });
      });

      // --- Testimonials stagger ---
      gsap.from(".testimonial-card", {
        y: 32,
        opacity: 0,
        stagger: 0.15,
        duration: 0.6,
        ease: "power2.out",
        scrollTrigger: { trigger: ".testimonials", start: "top 75%" },
      });

      // --- CTA banner word split reveal ---
      const ctaSplit = new SplitText(".cta-heading", { type: "words" });
      gsap.from(ctaSplit.words, {
        y: 24,
        opacity: 0,
        stagger: 0.06,
        duration: 0.6,
        ease: "power2.out",
        scrollTrigger: { trigger: ".cta-banner", start: "top 80%" },
      });

      return () => {
        split.revert();
        ctaSplit.revert();
        lenis?.destroy();
      };
    },
    { scope: root }
  );

  return (
    <div ref={root} className="bg-white">
      {/* ============ HERO ============ */}
      <section className="relative -mt-[72px] flex min-h-[100dvh] items-center overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <img
            src="/hero-skyline.jpg"
            alt=""
            className="hero-bg h-full w-full object-cover"
            style={{ transformOrigin: "center center" }}
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(to bottom, rgba(8,28,54,0.7) 0%, rgba(8,28,54,0.45) 55%, rgba(8,28,54,0.6) 100%)",
            }}
          />
        </div>

        <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-24 pt-36 sm:px-6 lg:px-8">
          <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-gold">
            Member FDIC · Est. 1924
          </p>
          <h1 className="hero-headline mt-5 max-w-3xl font-display text-4xl font-bold leading-[1.08] text-white sm:text-5xl lg:text-[56px]">
            Banking that moves at the speed of your life.
          </h1>
          <p className="hero-fade mt-6 max-w-xl text-lg leading-relaxed text-slate-200">
            Checking, savings, cards, and loans — with rates that respect your money and security that never sleeps.
          </p>
          <div className="hero-fade mt-9 flex flex-wrap items-center gap-4">
            <Link
              to="/login"
              className="rounded-lg bg-gold px-7 py-3.5 font-display text-[15px] font-semibold text-navy-deep shadow-lg transition hover:bg-gold-hover"
            >
              Open an Account
            </Link>
            <a
              href="#rates"
              className="rounded-lg border border-white/60 px-7 py-3.5 font-display text-[15px] font-semibold text-white transition hover:bg-white/10"
            >
              Explore Rates ↓
            </a>
          </div>
          <p className="hero-fade mt-10 flex flex-wrap items-center gap-x-2 gap-y-1 text-[13px] text-slate-300">
            <span className="inline-flex items-center gap-1">
              <Star className="h-3.5 w-3.5 fill-gold text-gold" /> 4.8 App Store
            </span>
            <span className="text-slate-500">·</span>1.2M customers
            <span className="text-slate-500">·</span>$38B in deposits
            <span className="text-slate-500">·</span>256-bit encryption
          </p>
        </div>

        <a
          href="#rates"
          aria-label="Scroll down"
          className="hero-chevron absolute bottom-8 left-1/2 z-10 -translate-x-1/2 text-white/70"
        >
          <ChevronDown className="h-7 w-7" />
        </a>
      </section>

      {/* ============ PRODUCT CARDS (pinned horizontal scroll) ============ */}
      <section className="products-pin overflow-hidden bg-canvas py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-gold">Products</p>
          <h2 className="mt-3 font-display text-3xl font-bold text-navy sm:text-4xl">
            Everything you need, nothing you don't.
          </h2>
        </div>
        <div className="products-track mt-12 flex gap-6 pl-4 pr-[20vw] sm:pl-6 lg:pl-[max(2rem,calc((100vw-80rem)/2+2rem))]">
          {PRODUCTS.map((p) => (
            <article
              key={p.name}
              id={p.anchor}
              className="product-card w-[320px] shrink-0 rounded-2xl border border-slate-200 bg-white p-7 shadow-sm sm:w-[360px]"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-navy/5 text-navy">
                <p.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-5 font-display text-lg font-semibold text-navy">{p.name}</h3>
              <p className="mt-2 font-display text-3xl font-bold text-gold">{p.rate}</p>
              <p className="text-[12.5px] text-subtle">{p.rateSub}</p>
              <ul className="mt-5 space-y-2.5 border-t border-slate-100 pt-5">
                {p.bullets.map((b) => (
                  <li key={b} className="flex items-start gap-2 text-[13.5px] text-body">
                    <BadgeCheck className="mt-0.5 h-4 w-4 shrink-0 text-money" />
                    {b}
                  </li>
                ))}
              </ul>
              <Link
                to="/login"
                className="mt-6 inline-block text-sm font-semibold text-navy transition hover:text-gold"
              >
                Learn more →
              </Link>
            </article>
          ))}
        </div>
      </section>

      {/* ============ RATES TICKER ============ */}
      <section id="rates" className="overflow-hidden bg-navy py-4">
        <div className="flex w-max animate-marquee hover:[animation-play-state:paused]">
          {[0, 1].map((dup) => (
            <div key={dup} className="flex shrink-0 items-center" aria-hidden={dup === 1}>
              {RATES.map(([label, value]) => (
                <span key={`${dup}-${label}`} className="flex items-center whitespace-nowrap px-6 text-sm">
                  <span className="text-slate-400">{label}</span>
                  <span className="ml-2 font-display font-semibold tabular-nums text-gold">{value}</span>
                  <span className="ml-6 text-slate-600">·</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </section>

      {/* ============ WHY MERIDIAN ============ */}
      <section className="why-section bg-white py-24" id="about">
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <div className="why-image overflow-hidden rounded-2xl shadow-lg">
            <img
              src="/landing-family.jpg"
              alt="A couple reviewing their finances together at the kitchen table"
              className="h-full w-full object-cover"
            />
          </div>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-gold">Why Meridian</p>
            <h2 className="mt-3 font-display text-3xl font-bold text-navy sm:text-4xl">
              A bank that answers on the first ring.
            </h2>
            <div className="mt-10 space-y-8">
              {[
                { icon: ShieldCheck, title: "FDIC insured to $250,000", body: "Every deposit protected, every account covered — per depositor, per ownership category." },
                { icon: Zap, title: "Instant transfers, zero fees", body: "Move money between Meridian accounts in seconds. External transfers settle same-day." },
                { icon: Headphones, title: "24/7 human support", body: "Real bankers, not bots. Median wait time under 60 seconds, any hour of any day." },
              ].map((f) => (
                <div key={f.title} className="why-feature flex gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-navy text-gold">
                    <f.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-display text-[17px] font-semibold text-navy">{f.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-subtle">{f.body}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ============ SECURITY ============ */}
      <section className="bg-navy-deep py-24 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-gold">Security</p>
          <h2 className="mt-3 max-w-2xl font-display text-3xl font-bold sm:text-4xl">
            Security isn't a feature. It's the foundation.
          </h2>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Lock, title: "256-bit AES encryption", body: "Bank-grade encryption on every connection and every stored record." },
              { icon: Radar, title: "Real-time fraud monitoring", body: "Machine-learning models score every transaction in under 40ms." },
              { icon: Fingerprint, title: "Biometric login", body: "Face ID, Touch ID, and hardware keys. Passwords optional." },
              { icon: ShieldCheck, title: "Zero-liability protection", body: "You're never responsible for unauthorized charges. Period." },
            ].map((s) => (
              <div key={s.title} className="rounded-xl border border-white/10 bg-white/5 p-6">
                <s.icon className="h-6 w-6 text-gold" />
                <h3 className="mt-4 font-display text-[15px] font-semibold">{s.title}</h3>
                <p className="mt-2 text-[13px] leading-relaxed text-slate-400">{s.body}</p>
              </div>
            ))}
          </div>
          <div className="mt-12 grid gap-6 border-t border-white/10 pt-10 font-mono text-sm sm:grid-cols-2 lg:grid-cols-4">
            {SECURITY_STATS.map((s) => (
              <div key={s.label}>
                <p className="text-2xl font-medium tabular-nums text-gold">
                  {s.prefix}
                  <span
                    className="sec-counter"
                    data-value={s.value}
                    data-decimals={s.decimals ?? 0}
                  >
                    0
                  </span>
                  {s.suffix}
                </p>
                <p className="mt-1 font-sans text-[12px] text-slate-400">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ TESTIMONIALS ============ */}
      <section className="testimonials bg-canvas py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-gold">Testimonials</p>
          <h2 className="mt-3 font-display text-3xl font-bold text-navy sm:text-4xl">
            Trusted by 1.2 million customers.
          </h2>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {TESTIMONIALS.map((t) => (
              <figure key={t.name} className="testimonial-card rounded-2xl border border-slate-200 bg-white p-7 shadow-sm">
                <div className="flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-gold text-gold" />
                  ))}
                </div>
                <blockquote className="mt-4 text-[15px] leading-relaxed text-body">“{t.quote}”</blockquote>
                <figcaption className="mt-5 text-[13px] font-semibold text-navy">
                  {t.name} <span className="font-normal text-subtle">— {t.city}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* ============ CTA BANNER ============ */}
      <section
        className="cta-banner py-20"
        style={{ background: "linear-gradient(115deg, #C9A227 0%, #DDB940 50%, #B08D1F 100%)" }}
      >
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 px-4 sm:px-6 lg:flex-row lg:items-center lg:px-8">
          <h2 className="cta-heading max-w-xl font-display text-3xl font-bold text-navy-deep sm:text-4xl">
            Ready when you are. Open an account in 5 minutes.
          </h2>
          <Link
            to="/login"
            className="shrink-0 rounded-lg bg-navy-deep px-8 py-4 font-display text-[15px] font-semibold text-white shadow-lg transition hover:bg-navy"
          >
            Open an Account
          </Link>
        </div>
      </section>
    </div>
  );
}
