import { useEffect, useMemo, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router";
import { motion } from "framer-motion";
import { format } from "date-fns";
import {
  ArrowLeft,
  Mail,
  Phone,
  MapPin,
  Snowflake,
  Ban,
  ShieldAlert,
  ShieldCheck,
  Lock,
  Unlock,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/providers/trpc";
import { useSession } from "@/hooks/useSession";
import StatusBadge from "@/components/shared/StatusBadge";
import AccountNumber from "@/components/shared/AccountNumber";
import MoneyText, { formatMoney } from "@/components/shared/MoneyText";
import StaffLayout from "@/components/staff/StaffLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

const num = (v: string | number | null | undefined) => (v == null ? 0 : Number(v));

const KYC_BADGE: Record<string, string> = {
  verified: "Verified",
  pending: "Pending",
  under_review: "Under Review",
  rejected: "Rejected",
};

const ACCOUNT_STATUS_BADGE: Record<string, string> = {
  active: "Active",
  frozen: "Frozen",
  closed: "Closed",
};

const CARD_STATUS_BADGE: Record<string, string> = {
  active: "Active",
  frozen: "Frozen",
  blocked: "Blocked",
  pending: "Pending",
};

const LOAN_STATUS_BADGE: Record<string, string> = {
  pending: "Pending",
  approved: "Approved",
  rejected: "Rejected",
  active: "Active",
  delinquent: "Delinquent",
  paid_off: "Paid Off",
};

const TXN_STATUS_BADGE: Record<string, string> = {
  posted: "Active",
  pending: "Pending",
  flagged: "Flagged",
};

const TAB_KEYS = ["overview", "accounts", "cards", "loans", "kyc", "transactions", "notes"] as const;

function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-xl border border-staff-border bg-staff-panel">
      <h3 className="border-b border-staff-border px-4 py-2.5 text-[12px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">
        {title}
      </h3>
      {children}
    </section>
  );
}

function EmptyRow({ cols, message }: { cols: number; message: string }) {
  return (
    <tr className="border-t border-staff-border">
      <td colSpan={cols} className="px-4 py-10 text-center text-[12.5px] text-staff-subtle">
        {message}
      </td>
    </tr>
  );
}

function Th({ children, right }: { children?: React.ReactNode; right?: boolean }) {
  return (
    <th className={cn("px-4 py-2.5 text-[11px] font-semibold uppercase tracking-[0.06em]", right && "text-right")}>
      {children}
    </th>
  );
}

function CustomerDetailBody() {
  const { id } = useParams();
  const customerId = Number(id);
  const { role } = useSession();
  const [params, setParams] = useSearchParams();
  const tabParam = params.get("tab");
  const tab = (TAB_KEYS as readonly string[]).includes(tabParam ?? "") ? tabParam! : "overview";

  const query = trpc.staff.customer360.useQuery(
    { id: customerId },
    { enabled: Number.isFinite(customerId) }
  );
  const utils = trpc.useUtils();
  const setCardStatus = trpc.staff.setCardStatus.useMutation({
    onSuccess: (_d, vars) => {
      toast.success(`Card ${vars.status === "active" ? "unblocked" : vars.status}.`);
      void utils.staff.customer360.invalidate({ id: customerId });
    },
    onError: (e) => toast.error(e.message),
  });

  useEffect(() => {
    if (query.error) toast.error("Failed to load customer profile.");
  }, [query.error]);

  const [note, setNote] = useState("");

  const data = query.data;
  const c = data?.customer;

  const kpis = useMemo(() => {
    if (!data) return null;
    const deposits = data.accounts
      .filter((a) => a.type === "checking" || a.type === "savings")
      .reduce((s, a) => s + num(a.balance), 0);
    const creditExposure = data.cards
      .filter((card) => card.type === "credit")
      .reduce((s, card) => s + Math.max(0, num(card.creditLimit) - num(card.availableCredit)), 0);
    const loanBalance = data.loans
      .filter((l) => l.status === "active" || l.status === "delinquent")
      .reduce((s, l) => s + num(l.remainingBalance), 0);
    const fees = data.recentTransactions
      .filter((t) => t.type === "fee")
      .reduce((s, t) => s + num(t.amount), 0);
    return { deposits, creditExposure, loanBalance, fees };
  }, [data]);

  if (query.isLoading) {
    return (
      <div className="mx-auto flex max-w-[1400px] gap-5">
        <div className="h-[560px] w-[320px] shrink-0 animate-pulse rounded-xl border border-staff-border bg-staff-panel" />
        <div className="h-[560px] flex-1 animate-pulse rounded-xl border border-staff-border bg-staff-panel" />
      </div>
    );
  }

  if (query.isError || !data || !c) {
    return (
      <div className="mx-auto max-w-[720px] rounded-xl border border-red-500/30 bg-red-500/10 px-6 py-8 text-center">
        <ShieldAlert className="mx-auto h-8 w-8 text-red-400" />
        <h1 className="mt-3 text-[15px] font-semibold text-staff-text">Customer not found</h1>
        <p className="mt-1 text-[12.5px] text-staff-subtle">
          The requested customer record could not be loaded.
        </p>
        <Link to="/staff/customers" className="mt-4 inline-flex items-center gap-1 text-[12.5px] text-staff-accent hover:underline">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to directory
        </Link>
      </div>
    );
  }

  const latestKyc = data.kycCases[0];
  const initials = `${c.firstName[0] ?? ""}${c.lastName[0] ?? ""}`.toUpperCase();
  const isElena = c.firstName.includes("Elena");

  return (
    <div className="mx-auto max-w-[1400px]">
      <Link
        to="/staff/customers"
        className="mb-4 inline-flex items-center gap-1 text-[12px] text-staff-subtle transition hover:text-staff-accent"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Customer Directory
      </Link>

      <div className="flex flex-col gap-5 lg:flex-row">
        {/* Left rail */}
        <aside className="w-full shrink-0 lg:sticky lg:top-[76px] lg:w-[320px] lg:self-start">
          <div className="rounded-xl border border-staff-border bg-staff-panel p-5">
            <div className="flex items-center gap-3">
              {isElena ? (
                <img src="/avatar-elena.png" alt={c.firstName} className="h-12 w-12 rounded-full object-cover ring-1 ring-staff-border" />
              ) : (
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-staff-accent/15 text-sm font-semibold text-staff-accent">
                  {initials}
                </span>
              )}
              <div>
                <h1 className="text-[15px] font-semibold text-staff-text">
                  {c.firstName} {c.lastName}
                </h1>
                <p className="font-mono text-[11px] text-staff-subtle">{c.customerNo}</p>
              </div>
            </div>

            <div className="mt-3 flex flex-wrap gap-1.5">
              <motion.span initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.05 }}>
                <StatusBadge dark status={KYC_BADGE[c.kycStatus] ?? c.kycStatus} />
              </motion.span>
              <motion.span initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.12 }}>
                <StatusBadge dark status="Active" />
              </motion.span>
              {latestKyc && (
                <motion.span initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.19 }}
                  className={cn(
                    "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11.5px] font-medium",
                    latestKyc.riskRating === "low" && "bg-emerald-500/15 text-emerald-300",
                    latestKyc.riskRating === "medium" && "bg-amber-500/15 text-amber-300",
                    latestKyc.riskRating === "high" && "bg-red-500/15 text-red-300"
                  )}
                >
                  Risk: {latestKyc.riskRating}
                </motion.span>
              )}
            </div>

            <div className="mt-5 space-y-2.5 border-t border-staff-border pt-4 text-[12.5px]">
              <p className="flex items-center gap-2 text-staff-subtle">
                <Mail className="h-3.5 w-3.5 shrink-0" /> <span className="truncate">{c.email}</span>
              </p>
              <p className="flex items-center gap-2 text-staff-subtle">
                <Phone className="h-3.5 w-3.5 shrink-0" /> <span className="font-mono">{c.phone}</span>
              </p>
              <p className="flex items-start gap-2 text-staff-subtle">
                <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {c.address}
              </p>
            </div>

            <dl className="mt-5 space-y-2 border-t border-staff-border pt-4 text-[12px]">
              {[
                ["Customer since", format(new Date(c.createdAt), "MMM d, yyyy")],
                ["Branch", c.branch?.name ?? "—"],
                ["Date of birth", format(new Date(c.dob + "T00:00:00"), "MMM d, yyyy")],
                ["SSN", `•••-••-${c.ssnLast4}`],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-3">
                  <dt className="text-staff-subtle">{k}</dt>
                  <dd className="font-mono text-[11.5px] text-staff-text">{v}</dd>
                </div>
              ))}
            </dl>

            {/* Danger zone — admin only */}
            {role === "admin" && (
              <div className="mt-5 space-y-2 border-t border-red-500/20 pt-4">
                <p className="text-[10.5px] font-semibold uppercase tracking-[0.08em] text-red-400/80">
                  Danger zone
                </p>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <button
                      type="button"
                      className="flex w-full items-center gap-2 rounded-md border border-staff-border px-3 py-2 text-[12px] text-staff-text transition hover:border-amber-400/40 hover:bg-amber-400/5"
                    >
                      <Snowflake className="h-3.5 w-3.5 text-amber-300" /> Freeze all accounts
                    </button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="border-staff-border bg-staff-raised text-staff-text">
                    <AlertDialogHeader>
                      <AlertDialogTitle>Freeze all accounts?</AlertDialogTitle>
                      <AlertDialogDescription className="text-staff-subtle">
                        All accounts for {c.firstName} {c.lastName} will be frozen immediately. This
                        action is logged to the audit trail.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="border-staff-border bg-transparent text-staff-text hover:bg-staff-hover">
                        Cancel
                      </AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-red-600 text-white hover:bg-red-700"
                        onClick={() => toast.error("Bulk freeze is disabled in the DEMO environment.")}
                      >
                        Freeze accounts
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <button
                      type="button"
                      className="flex w-full items-center gap-2 rounded-md border border-staff-border px-3 py-2 text-[12px] text-staff-text transition hover:border-red-400/40 hover:bg-red-400/5"
                    >
                      <Ban className="h-3.5 w-3.5 text-red-400" /> Close customer
                    </button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="border-staff-border bg-staff-raised text-staff-text">
                    <AlertDialogHeader>
                      <AlertDialogTitle>Close customer relationship?</AlertDialogTitle>
                      <AlertDialogDescription className="text-staff-subtle">
                        This is a terminal maker-checker action requiring a second admin approval.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="border-staff-border bg-transparent text-staff-text hover:bg-staff-hover">
                        Cancel
                      </AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-red-600 text-white hover:bg-red-700"
                        onClick={() => toast.error("Customer closure is disabled in the DEMO environment.")}
                      >
                        Close customer
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            )}
          </div>
        </aside>

        {/* Main tabs */}
        <div className="min-w-0 flex-1">
          <Tabs value={tab} onValueChange={(v) => setParams({ tab: v }, { replace: true })}>
            <TabsList className="h-auto w-full justify-start gap-1 overflow-x-auto rounded-lg border border-staff-border bg-staff-panel p-1">
              {[
                ["overview", "Overview"],
                ["accounts", `Accounts (${data.accounts.length})`],
                ["cards", `Cards (${data.cards.length})`],
                ["loans", `Loans (${data.loans.length})`],
                ["kyc", "KYC"],
                ["transactions", "Transactions"],
                ["notes", "Notes & Audit"],
              ].map(([k, label]) => (
                <TabsTrigger
                  key={k}
                  value={k}
                  className="rounded-md px-3 py-1.5 text-[12px] text-staff-subtle data-[state=active]:bg-staff-accent data-[state=active]:text-staff-sidebar"
                >
                  {label}
                </TabsTrigger>
              ))}
            </TabsList>

            {/* Overview */}
            <TabsContent value="overview" className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
                {kpis &&
                  [
                    ["Total deposits", formatMoney(kpis.deposits)],
                    ["Credit exposure", formatMoney(kpis.creditExposure)],
                    ["Loan balance", formatMoney(kpis.loanBalance)],
                    ["Recent fees", formatMoney(kpis.fees)],
                  ].map(([label, value], i) => (
                    <motion.div
                      key={label}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.2, delay: i * 0.05 }}
                      className="rounded-xl border border-staff-border bg-staff-panel p-4"
                    >
                      <p className="text-[10.5px] font-medium uppercase tracking-[0.06em] text-staff-subtle">{label}</p>
                      <p className="mt-1 font-mono text-lg font-semibold tabular-nums text-staff-text">{value}</p>
                    </motion.div>
                  ))}
              </div>

              <SectionCard title="Products">
                <div className="grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 xl:grid-cols-3">
                  {data.accounts.map((a) => (
                    <div key={a.id} className="rounded-lg border border-staff-border bg-staff-raised p-3.5">
                      <div className="flex items-center justify-between">
                        <p className="text-[12.5px] font-medium text-staff-text">{a.nickname}</p>
                        <StatusBadge dark status={ACCOUNT_STATUS_BADGE[a.status] ?? a.status} />
                      </div>
                      <p className="mt-0.5 font-mono text-[11px] text-staff-subtle">•••• {a.last4} · {a.type}</p>
                      <p className="mt-2 font-mono text-[15px] font-semibold tabular-nums text-staff-text">
                        {formatMoney(num(a.balance))}
                      </p>
                    </div>
                  ))}
                  {data.cards.map((card) => (
                    <div key={`card-${card.id}`} className="rounded-lg border border-staff-border bg-staff-raised p-3.5">
                      <div className="flex items-center justify-between">
                        <p className="text-[12.5px] font-medium text-staff-text">
                          {card.type === "credit" ? "Credit Card" : "Debit Card"}
                        </p>
                        <StatusBadge dark status={CARD_STATUS_BADGE[card.status] ?? card.status} />
                      </div>
                      <p className="mt-0.5 font-mono text-[11px] text-staff-subtle">
                        •••• {card.last4} · {card.network}
                      </p>
                      {card.creditLimit && (
                        <p className="mt-2 font-mono text-[15px] font-semibold tabular-nums text-staff-text">
                          {formatMoney(num(card.creditLimit))} <span className="text-[11px] font-normal text-staff-subtle">limit</span>
                        </p>
                      )}
                    </div>
                  ))}
                  {data.accounts.length === 0 && data.cards.length === 0 && (
                    <p className="col-span-full py-6 text-center text-[12.5px] text-staff-subtle">
                      No products on file.
                    </p>
                  )}
                </div>
              </SectionCard>

              <SectionCard title="Recent activity">
                <ul className="divide-y divide-staff-border">
                  {data.recentTransactions.slice(0, 5).map((t) => (
                    <li key={t.id} className="flex items-center gap-3 px-4 py-2.5">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[12.5px] text-staff-text">{t.merchant ?? t.description}</p>
                        <p className="font-mono text-[10.5px] text-staff-subtle">
                          {t.accountNickname} ••••{t.accountLast4} · {format(new Date(t.occurredAt), "MMM d, HH:mm")}
                        </p>
                      </div>
                      <MoneyText
                        amount={t.direction === "cr" ? num(t.amount) : -num(t.amount)}
                        className={cn(
                          "font-mono text-[12.5px]",
                          t.direction === "cr" ? "!text-emerald-400" : "!text-red-300"
                        )}
                      />
                    </li>
                  ))}
                  {data.recentTransactions.length === 0 && (
                    <li className="px-4 py-8 text-center text-[12.5px] text-staff-subtle">No recent activity.</li>
                  )}
                </ul>
              </SectionCard>

              {data.alerts.length === 0 ? (
                <div className="flex items-center gap-2 rounded-xl border border-emerald-500/25 bg-emerald-500/10 px-4 py-3 text-[12.5px] text-emerald-300">
                  <ShieldCheck className="h-4 w-4" /> Risk indicators: none. No open AML alerts for this customer.
                </div>
              ) : (
                <div className="rounded-xl border border-red-500/25 bg-red-500/10 px-4 py-3">
                  <p className="flex items-center gap-2 text-[12.5px] font-medium text-red-300">
                    <ShieldAlert className="h-4 w-4" /> {data.alerts.length} alert(s) on file
                  </p>
                  <ul className="mt-2 space-y-1">
                    {data.alerts.slice(0, 3).map((a) => (
                      <li key={a.id} className="font-mono text-[11px] text-red-200/80">
                        {a.alertNo} · {a.severity} · {a.description}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </TabsContent>

            {/* Accounts */}
            <TabsContent value="accounts" className="mt-4">
              <SectionCard title="Deposit & credit accounts">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-[13px]">
                    <thead className="bg-staff-raised text-staff-subtle">
                      <tr>
                        <Th>Account</Th><Th>Type</Th><Th>Number</Th><Th right>Balance</Th><Th>Status</Th><Th>Opened</Th><Th />
                      </tr>
                    </thead>
                    <tbody>
                      {data.accounts.length === 0 && <EmptyRow cols={7} message="No accounts on file." />}
                      {data.accounts.map((a, i) => (
                        <tr key={a.id} className={cn("h-11 border-t border-staff-border hover:bg-staff-hover", i % 2 === 1 && "bg-staff-zebra")}>
                          <td className="px-4 py-2.5 font-medium text-staff-text">{a.nickname}</td>
                          <td className="px-4 py-2.5 capitalize text-staff-subtle">{a.type}</td>
                          <td className="px-4 py-2.5 text-staff-subtle">
                            <AccountNumber last4={a.last4} full={a.accountNumber} className="text-[11.5px]" />
                          </td>
                          <td className="px-4 py-2.5 text-right font-mono tabular-nums text-staff-text">
                            {formatMoney(num(a.balance))}
                          </td>
                          <td className="px-4 py-2.5">
                            <StatusBadge dark status={ACCOUNT_STATUS_BADGE[a.status] ?? a.status} />
                          </td>
                          <td className="px-4 py-2.5 font-mono text-[11.5px] text-staff-subtle">
                            {format(new Date(a.openedAt + "T00:00:00"), "MMM yyyy")}
                          </td>
                          <td className="px-4 py-2.5 text-right">
                            <button
                              type="button"
                              onClick={() => toast.info("Balance adjustments require maker-checker approval — disabled in DEMO.")}
                              className="rounded border border-staff-border px-2 py-1 text-[11px] text-staff-subtle transition hover:border-staff-accent/40 hover:text-staff-accent"
                            >
                              Adjust
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </SectionCard>
            </TabsContent>

            {/* Cards */}
            <TabsContent value="cards" className="mt-4 space-y-3">
              {data.cards.length === 0 && (
                <div className="rounded-xl border border-staff-border bg-staff-panel px-4 py-10 text-center text-[12.5px] text-staff-subtle">
                  No cards issued to this customer.
                </div>
              )}
              {data.cards.map((card) => {
                const util =
                  card.type === "credit" && num(card.creditLimit) > 0
                    ? Math.round(((num(card.creditLimit) - num(card.availableCredit)) / num(card.creditLimit)) * 100)
                    : null;
                return (
                  <div key={card.id} className="flex flex-wrap items-center gap-4 rounded-xl border border-staff-border bg-staff-panel p-4">
                    <div className="min-w-0 flex-1">
                      <p className="text-[13px] font-medium text-staff-text">
                        {card.type === "credit" ? "Platinum Rewards Credit" : "Debit"} ·{" "}
                        <span className="font-mono text-[12px] text-staff-subtle">•••• {card.last4}</span>
                      </p>
                      <p className="mt-0.5 font-mono text-[11px] text-staff-subtle">
                        {card.network} · holder {card.holder} · exp {card.expiresAt}
                      </p>
                      {util != null && (
                        <div className="mt-2 max-w-[260px]">
                          <div className="flex justify-between text-[10.5px] text-staff-subtle">
                            <span>Utilization</span>
                            <span className="font-mono">{util}% of {formatMoney(num(card.creditLimit))}</span>
                          </div>
                          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-staff-raised">
                            <div
                              className={cn("h-full rounded-full", util > 80 ? "bg-red-400" : util > 50 ? "bg-amber-400" : "bg-staff-accent")}
                              style={{ width: `${Math.min(100, util)}%` }}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                    <StatusBadge dark status={CARD_STATUS_BADGE[card.status] ?? card.status} />
                    <div className="flex items-center gap-2">
                      {card.status === "active" ? (
                        <button
                          type="button"
                          disabled={setCardStatus.isPending}
                          onClick={() => setCardStatus.mutate({ cardId: card.id, status: "frozen" })}
                          className="flex items-center gap-1.5 rounded-md border border-staff-border px-3 py-1.5 text-[12px] text-staff-text transition hover:border-amber-400/40 hover:bg-amber-400/5"
                        >
                          <Lock className="h-3.5 w-3.5 text-amber-300" /> Freeze
                        </button>
                      ) : card.status === "frozen" ? (
                        <button
                          type="button"
                          disabled={setCardStatus.isPending}
                          onClick={() => setCardStatus.mutate({ cardId: card.id, status: "active" })}
                          className="flex items-center gap-1.5 rounded-md border border-staff-border px-3 py-1.5 text-[12px] text-staff-text transition hover:border-staff-accent/40 hover:bg-staff-accent/5"
                        >
                          <Unlock className="h-3.5 w-3.5 text-staff-accent" /> Unblock
                        </button>
                      ) : null}
                      {card.status !== "blocked" && (
                        <button
                          type="button"
                          disabled={setCardStatus.isPending}
                          onClick={() => setCardStatus.mutate({ cardId: card.id, status: "blocked" })}
                          className="flex items-center gap-1.5 rounded-md border border-red-500/30 px-3 py-1.5 text-[12px] text-red-300 transition hover:bg-red-500/10"
                        >
                          <Ban className="h-3.5 w-3.5" /> Block
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </TabsContent>

            {/* Loans */}
            <TabsContent value="loans" className="mt-4">
              <SectionCard title="Loan accounts">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-[13px]">
                    <thead className="bg-staff-raised text-staff-subtle">
                      <tr>
                        <Th>Loan</Th><Th>Product</Th><Th right>Principal</Th><Th right>Remaining</Th><Th right>Rate</Th><Th>Status</Th><Th>Applied</Th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.loans.length === 0 && <EmptyRow cols={7} message="No loan history." />}
                      {data.loans.map((l, i) => (
                        <tr key={l.id} className={cn("h-11 border-t border-staff-border hover:bg-staff-hover", i % 2 === 1 && "bg-staff-zebra")}>
                          <td className="px-4 py-2.5 font-mono text-[12px] text-staff-accent">{l.loanNo}</td>
                          <td className="px-4 py-2.5 text-staff-text">{l.product.name}</td>
                          <td className="px-4 py-2.5 text-right font-mono tabular-nums text-staff-text">{formatMoney(num(l.principal))}</td>
                          <td className="px-4 py-2.5 text-right font-mono tabular-nums text-staff-text">{formatMoney(num(l.remainingBalance))}</td>
                          <td className="px-4 py-2.5 text-right font-mono tabular-nums text-staff-subtle">{num(l.rateApr).toFixed(2)}%</td>
                          <td className="px-4 py-2.5"><StatusBadge dark status={LOAN_STATUS_BADGE[l.status] ?? l.status} /></td>
                          <td className="px-4 py-2.5 font-mono text-[11.5px] text-staff-subtle">{format(new Date(l.appliedAt), "MMM d, yyyy")}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </SectionCard>
            </TabsContent>

            {/* KYC */}
            <TabsContent value="kyc" className="mt-4 space-y-4">
              {data.kycCases.length === 0 && (
                <div className="rounded-xl border border-staff-border bg-staff-panel px-4 py-10 text-center text-[12.5px] text-staff-subtle">
                  No KYC cases on file.
                </div>
              )}
              {data.kycCases.map((k) => (
                <SectionCard key={k.id} title={`Case ${k.caseNo} · ${k.level === "enhanced" ? "Enhanced Due Diligence" : "Standard"}`}>
                  <div className="p-4">
                    {/* timeline */}
                    <ol className="relative ml-2 space-y-4 border-l border-staff-border pl-5">
                      {[
                        { label: "Application submitted", at: k.submittedAt, done: true },
                        { label: "Documents verified", at: k.reviewedAt, done: k.status === "approved" || k.status === "rejected" },
                        {
                          label:
                            k.status === "approved"
                              ? `Approved by ${k.reviewedBy ?? "staff"}`
                              : k.status === "rejected"
                                ? `Rejected by ${k.reviewedBy ?? "staff"}`
                                : "Awaiting review",
                          at: k.reviewedAt,
                          done: k.status === "approved",
                          failed: k.status === "rejected",
                        },
                      ].map((step, i) => (
                        <li key={i} className="relative">
                          <span
                            className={cn(
                              "absolute -left-[26px] top-1 h-2.5 w-2.5 rounded-full border-2 border-staff-panel",
                              step.done ? "bg-emerald-400" : step.failed ? "bg-red-400" : "bg-amber-400"
                            )}
                          />
                          <p className="text-[12.5px] font-medium text-staff-text">{step.label}</p>
                          {step.at && (
                            <p className="font-mono text-[10.5px] text-staff-subtle">
                              {format(new Date(step.at), "MMM d, yyyy HH:mm")}
                            </p>
                          )}
                        </li>
                      ))}
                    </ol>

                    <dl className="mt-4 grid grid-cols-2 gap-3 border-t border-staff-border pt-4 text-[12px] sm:grid-cols-3">
                      <div>
                        <dt className="text-staff-subtle">ID document</dt>
                        <dd className="mt-0.5 text-staff-text">{k.idDocType}</dd>
                      </div>
                      <div>
                        <dt className="text-staff-subtle">Risk rating</dt>
                        <dd className="mt-0.5 capitalize text-staff-text">{k.riskRating}</dd>
                      </div>
                      <div>
                        <dt className="text-staff-subtle">Status</dt>
                        <dd className="mt-0.5"><StatusBadge dark status={KYC_BADGE[k.status] ?? k.status} /></dd>
                      </div>
                    </dl>
                    {k.rejectionReason && (
                      <p className="mt-3 rounded-md border border-red-500/25 bg-red-500/10 px-3 py-2 text-[12px] text-red-300">
                        Rejection reason: {k.rejectionReason}
                      </p>
                    )}
                    {k.notes && <p className="mt-3 text-[12px] text-staff-subtle">{k.notes}</p>}

                    <div className="mt-4 border-t border-staff-border pt-4">
                      <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">
                        Submitted documents
                      </p>
                      <div className="flex gap-3">
                        {["/doc-id-sample.jpg", "/doc-proof-address.jpg"].map((src) => (
                          <a key={src} href={src} target="_blank" rel="noreferrer" className="group">
                            <img
                              src={src}
                              alt="KYC document"
                              className="h-20 w-28 rounded-md border border-staff-border object-cover transition group-hover:border-staff-accent/50"
                            />
                          </a>
                        ))}
                      </div>
                    </div>
                  </div>
                </SectionCard>
              ))}
            </TabsContent>

            {/* Transactions */}
            <TabsContent value="transactions" className="mt-4">
              <SectionCard title="Latest 15 transactions (all accounts)">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-[13px]">
                    <thead className="bg-staff-raised text-staff-subtle">
                      <tr>
                        <Th>Txn ID</Th><Th>Description</Th><Th>Account</Th><Th>Type</Th><Th>Status</Th><Th right>Amount</Th><Th>Date</Th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.recentTransactions.length === 0 && <EmptyRow cols={7} message="No transactions found." />}
                      {data.recentTransactions.map((t, i) => (
                        <tr
                          key={t.id}
                          className={cn(
                            "h-11 border-t border-staff-border hover:bg-staff-hover",
                            i % 2 === 1 && "bg-staff-zebra",
                            t.status === "flagged" && "border-l-[3px] border-l-red-500"
                          )}
                        >
                          <td className="px-4 py-2.5 font-mono text-[11px] text-staff-subtle">{t.txnId}</td>
                          <td className="max-w-[240px] truncate px-4 py-2.5 text-staff-text">
                            {t.merchant ?? t.description}
                            {t.flagReason && (
                              <span className="ml-2 rounded bg-red-400/10 px-1.5 py-0.5 text-[10px] text-red-300">{t.flagReason}</span>
                            )}
                          </td>
                          <td className="px-4 py-2.5 font-mono text-[11px] text-staff-subtle">
                            {t.accountNickname} ••••{t.accountLast4}
                          </td>
                          <td className="px-4 py-2.5 capitalize text-staff-subtle">{t.type}</td>
                          <td className="px-4 py-2.5"><StatusBadge dark status={TXN_STATUS_BADGE[t.status] ?? t.status} /></td>
                          <td className="px-4 py-2.5 text-right">
                            <MoneyText
                              amount={t.direction === "cr" ? num(t.amount) : -num(t.amount)}
                              className={cn("font-mono text-[12.5px]", t.direction === "cr" ? "!text-emerald-400" : "!text-red-300")}
                            />
                          </td>
                          <td className="px-4 py-2.5 font-mono text-[11.5px] text-staff-subtle">
                            {format(new Date(t.occurredAt), "MMM d, HH:mm")}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </SectionCard>
            </TabsContent>

            {/* Notes & Audit */}
            <TabsContent value="notes" className="mt-4 space-y-4">
              <SectionCard title="Add note">
                <div className="p-4">
                  <textarea
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    rows={3}
                    placeholder="Log an RM note for this customer…"
                    className="w-full rounded-md border border-staff-border bg-staff-sidebar px-3 py-2 text-[12.5px] text-staff-text placeholder:text-staff-subtle/50 focus:border-staff-accent focus:outline-none"
                  />
                  <div className="mt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={() => {
                        if (!note.trim()) return;
                        setNote("");
                        toast.info("Note posting is not available in this DEMO build — staff actions are captured in the audit trail below.");
                      }}
                      className="rounded-md bg-staff-accent px-4 py-1.5 text-[12px] font-semibold text-staff-sidebar transition hover:bg-staff-accent/90"
                    >
                      Post note
                    </button>
                  </div>
                </div>
              </SectionCard>

              <SectionCard title="Audit trail">
                <ol className="relative ml-5 space-y-0 p-4 pl-6">
                  {data.auditTrail.length === 0 && (
                    <li className="py-6 text-center text-[12.5px] text-staff-subtle">
                      No staff actions recorded for this customer.
                    </li>
                  )}
                  {data.auditTrail.map((e, i) => (
                    <motion.li
                      key={e.id}
                      initial={{ opacity: 0, x: -6 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.15, delay: Math.min(i, 10) * 0.04 }}
                      className="relative border-l border-staff-border pb-5 pl-5 last:pb-0"
                    >
                      <span className="absolute -left-[5px] top-1.5 h-2.5 w-2.5 rounded-full border-2 border-staff-panel bg-staff-accent" />
                      <p className="text-[12.5px] text-staff-text">
                        <span className="font-medium">{e.actorName}</span>{" "}
                        <span className="text-staff-subtle">·</span>{" "}
                        <span className="font-mono text-[11.5px] text-staff-accent">{e.action}</span>
                      </p>
                      {e.detail && <p className="mt-0.5 text-[12px] text-staff-subtle">{e.detail}</p>}
                      <p className="mt-0.5 font-mono text-[10.5px] text-staff-subtle/70">
                        EVT-{String(e.id).padStart(5, "0")} · {format(new Date(e.createdAt), "MMM d, yyyy HH:mm")}
                      </p>
                    </motion.li>
                  ))}
                </ol>
              </SectionCard>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

export default function StaffCustomerDetail() {
  return (
    <StaffLayout>
      <CustomerDetailBody />
    </StaffLayout>
  );
}
