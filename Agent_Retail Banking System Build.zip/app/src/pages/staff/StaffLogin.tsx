import { useState } from "react";
import type { FormEvent } from "react";
import { Link, useNavigate } from "react-router";
import { motion } from "framer-motion";
import { Lock, User, ShieldCheck, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import { useSession } from "@/hooks/useSession";
import { STAFF_ROLES, type Role } from "@contracts/types";
import { cn } from "@/lib/utils";

type StaffRole = "teller" | "manager" | "admin";

const ROLE_OPTIONS: { value: StaffRole; label: string; caption: string }[] = [
  { value: "teller", label: "Teller", caption: "Transactions & servicing" },
  { value: "manager", label: "Relationship Manager", caption: "Customers, KYC, loans" },
  { value: "admin", label: "Admin", caption: "Full access" },
];

const DEMO_USERS: { name: string; role: StaffRole; username: string; password: string }[] = [
  { name: "Marcus Chen", role: "admin", username: "marcus.chen@meridian.bank", password: "admin1234" },
  { name: "Priya Sharma", role: "manager", username: "priya.sharma@meridian.bank", password: "manager1234" },
  { name: "Jordan Ellis", role: "teller", username: "jordan.ellis@meridian.bank", password: "teller1234" },
];

export default function StaffLogin() {
  const { login } = useSession();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<StaffRole>("admin");
  const [submitting, setSubmitting] = useState(false);
  const [shakeKey, setShakeKey] = useState(0);
  const [success, setSuccess] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    try {
      const user = await login(username, password);
      if (!STAFF_ROLES.includes(user.role as Role)) {
        toast.error("This account does not have staff console access.");
        setShakeKey((k) => k + 1);
        return;
      }
      setSuccess(true);
      toast.success(`Welcome back, ${user.name}.`);
      setTimeout(() => navigate("/staff"), 450);
    } catch {
      setShakeKey((k) => k + 1);
      toast.error("Invalid credentials. This attempt has been logged.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="theme-staff flex min-h-[100dvh] items-center justify-center bg-staff-sidebar px-4 font-sans"
      style={{
        backgroundImage:
          "linear-gradient(rgba(45,212,168,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(45,212,168,0.035) 1px, transparent 1px)",
        backgroundSize: "32px 32px",
      }}
    >
      <motion.div
        key={shakeKey}
        initial={{ opacity: 0, y: 16 }}
        animate={
          shakeKey > 0
            ? { opacity: 1, y: 0, x: [0, -10, 10, -6, 6, 0] }
            : { opacity: 1, y: 0, x: 0 }
        }
        transition={{ duration: 0.4, ease: "easeOut" }}
        className={cn(
          "w-full max-w-[420px] rounded-2xl border bg-staff-panel p-8 shadow-2xl transition-colors",
          success ? "border-staff-accent/60 ring-2 ring-staff-accent/40" : "border-staff-border"
        )}
      >
        <div className="mb-6 text-center">
          <img
            src="/logo-mark.svg"
            alt="Meridian"
            className="mx-auto h-10 w-10 [filter:hue-rotate(120deg)_saturate(1.4)]"
          />
          <h1 className="mt-3 text-lg font-semibold text-staff-text">Meridian Staff Console</h1>
          <p className="mt-1 flex items-center justify-center gap-1.5 text-[11.5px] text-staff-subtle">
            <ShieldCheck className="h-3.5 w-3.5 text-staff-accent" /> Authorized personnel only
          </p>
        </div>

        {/* Role selector */}
        <div className="mb-5">
          <div className="grid grid-cols-3 gap-1 rounded-lg border border-staff-border bg-staff-sidebar p-1">
            {ROLE_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setRole(opt.value)}
                className={cn(
                  "relative rounded-md px-2 py-1.5 text-[11.5px] font-medium transition-colors",
                  role === opt.value ? "text-staff-sidebar" : "text-staff-subtle hover:text-staff-text"
                )}
              >
                {role === opt.value && (
                  <motion.span
                    layoutId="role-pill"
                    className="absolute inset-0 rounded-md bg-staff-accent"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.4 }}
                  />
                )}
                <span className="relative">{opt.label}</span>
              </button>
            ))}
          </div>
          <p className="mt-1.5 text-center text-[11px] text-staff-subtle">
            {ROLE_OPTIONS.find((o) => o.value === role)?.caption}
          </p>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <div>
            <label htmlFor="staff-user" className="mb-1.5 flex items-center justify-between text-[11px] font-medium uppercase tracking-[0.06em] text-staff-subtle">
              Employee ID / Email
              <span className="rounded bg-staff-raised px-1.5 py-0.5 font-mono text-[10px] normal-case tracking-normal text-staff-accent">
                Demo: marcus.chen@meridian.bank
              </span>
            </label>
            <div className="relative">
              <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-staff-subtle" />
              <input
                id="staff-user"
                type="text"
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="name@meridian.bank"
                required
                className="h-10 w-full rounded-md border border-staff-border bg-staff-sidebar pl-9 pr-3 font-mono text-[13px] text-staff-text placeholder:text-staff-subtle/50 focus:border-staff-accent focus:outline-none focus:ring-1 focus:ring-staff-accent/50"
              />
            </div>
          </div>
          <div>
            <label htmlFor="staff-pass" className="mb-1.5 block text-[11px] font-medium uppercase tracking-[0.06em] text-staff-subtle">
              Password
            </label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-staff-subtle" />
              <input
                id="staff-pass"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="h-10 w-full rounded-md border border-staff-border bg-staff-sidebar pl-9 pr-3 font-mono text-[13px] text-staff-text placeholder:text-staff-subtle/50 focus:border-staff-accent focus:outline-none focus:ring-1 focus:ring-staff-accent/50"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="h-10 w-full rounded-md bg-staff-accent text-[13.5px] font-semibold text-staff-sidebar transition hover:bg-staff-accent/90 active:scale-[0.99] disabled:opacity-60"
          >
            {submitting ? "Verifying…" : success ? "Access granted" : "Sign in to console"}
          </button>
        </form>

        {/* Demo quick-fill */}
        <div className="mt-5 border-t border-staff-border pt-4">
          <p className="mb-2 text-[10.5px] font-medium uppercase tracking-[0.08em] text-staff-subtle">
            Demo quick sign-in
          </p>
          <div className="space-y-1.5">
            {DEMO_USERS.map((d) => (
              <button
                key={d.username}
                type="button"
                onClick={() => {
                  setUsername(d.username);
                  setPassword(d.password);
                  setRole(d.role);
                }}
                className="flex w-full items-center justify-between rounded-md border border-staff-border bg-staff-raised px-3 py-2 text-left text-[12px] text-staff-text transition hover:border-staff-accent/40 hover:bg-staff-hover"
              >
                <span>
                  Sign in as <span className="font-medium">{d.name}</span>
                </span>
                <span className="rounded-full bg-staff-accent/10 px-2 py-0.5 text-[10.5px] font-medium text-staff-accent">
                  {ROLE_OPTIONS.find((o) => o.value === d.role)?.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        <p className="mt-5 text-center text-[10.5px] leading-relaxed text-staff-subtle">
          All activity is logged and monitored. DEMO environment.
        </p>
        <p className="mt-2 text-center">
          <Link
            to="/login"
            className="inline-flex items-center gap-1 text-[12px] text-staff-subtle transition hover:text-staff-accent"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Customer banking
          </Link>
        </p>
      </motion.div>
      <Toaster theme="dark" position="top-right" richColors />
    </div>
  );
}
