/** Sanity check: exercise routers via direct tRPC caller (no HTTP server needed). */
import "dotenv/config";
import { appRouter } from "../api/router";

async function main() {
  const caller = appRouter.createCaller({ req: new Request("http://x"), resHeaders: new Headers(), session: null });

  const login = await caller.auth.login({ username: "elena.vasquez@demo.meridian", password: "demo1234" });
  console.log("login ok:", login.user.name, login.user.role);

  const elenaCtx = { req: new Request("http://x", { headers: { "x-session-token": login.token } }), resHeaders: new Headers(), session: { ...login.user } };
  const c = appRouter.createCaller(elenaCtx);

  const dash = await c.customer.dashboardSummary();
  console.log("accounts:", dash.accounts.map((a) => `${a.nickname} ${a.balance}`).join(" | "));
  console.log("recent txns:", dash.recentTransactions.length, "unread:", dash.unreadCount);

  const checking = dash.accounts.find((a) => a.last4 === "4821")!;
  const detail = await c.customer.accountDetail({ id: checking.id, page: 1, pageSize: 10, search: "whole" });
  console.log("checking search 'whole':", detail.total, "first running bal:", detail.transactions[0]?.runningBalance);

  const loans = await c.customer.listLoans();
  console.log("loans:", loans.map((l) => `${l.loanNo} ${l.status} rem=${l.remainingBalance} sched=${l.schedule.length}`).join(" | "));

  const transfer = await c.customer.transfer({ fromAccountId: checking.id, payeeId: 3, amount: 25 });
  console.log("transfer ok:", transfer.transactionId);

  const cardRows = await c.customer.listCards();
  console.log("cards:", cardRows.map((r) => `${r.card.last4}:${r.card.status}`).join(" | "));

  // staff
  const staffLogin = await caller.auth.login({ username: "marcus.chen@meridian.bank", password: "admin1234" });
  const s = appRouter.createCaller({ req: new Request("http://x"), resHeaders: new Headers(), session: { ...staffLogin.user } });
  const kpis = await s.staff.dashboardKpis();
  console.log("KPIs:", JSON.stringify({ ...kpis, depositSeries: kpis.depositSeries.length + " days" }));
  const custList = await s.staff.listCustomers({ search: "vasquez", page: 1 });
  console.log("listCustomers search:", custList.total);
  const c360 = await s.staff.customer360({ id: login.user.customerId! });
  console.log("customer360:", c360.customer.firstName, c360.accounts.length, "accounts,", c360.alerts.length, "alerts");
  const kyc = await s.staff.kycQueue({});
  console.log("kycQueue:", kyc.length);
  const alerts = await s.staff.listAlerts({});
  console.log("alerts:", alerts.length, alerts.map((a) => `${a.alertNo}:${a.severity}/${a.status}`).join(" "));
  const loansQ = await s.staff.loanQueue({ status: "pending" });
  console.log("pending loans:", loansQ.length);
  const flagged = await s.staff.flaggedQueue();
  console.log("flagged:", flagged.length);
  const audit = await s.staff.auditLog({ page: 1 });
  console.log("audit entries:", audit.total);

  process.exit(0);
}
main().catch((e) => { console.error(e); process.exit(1); });
