import { useState } from "react";
import { Copy, Check, Eye, EyeOff } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Masked account number (•••• 4821) with copy-to-clipboard and
 * eye toggle to reveal the full IBAN.
 */
export default function AccountNumber({
  last4,
  full = "US33 MERI 0001 2345 6789 01",
  className,
  mono = true,
}: {
  last4: string;
  /** Full IBAN revealed by the eye toggle. */
  full?: string;
  className?: string;
  /** Use JetBrains Mono (staff console). Default true. */
  mono?: boolean;
}) {
  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(revealed ? full : `•••• ${last4}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard unavailable */
    }
  };

  return (
    <span className={cn("inline-flex items-center gap-1.5", mono && "font-mono tabular-nums", className)}>
      <span>{revealed ? full : `•••• ${last4}`}</span>
      <button
        type="button"
        onClick={() => setRevealed(!revealed)}
        aria-label={revealed ? "Hide account number" : "Reveal account number"}
        className="rounded p-0.5 text-current opacity-60 transition hover:opacity-100"
      >
        {revealed ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
      </button>
      <button
        type="button"
        onClick={copy}
        aria-label="Copy account number"
        className="rounded p-0.5 text-current opacity-60 transition hover:opacity-100"
      >
        {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
      </button>
    </span>
  );
}
