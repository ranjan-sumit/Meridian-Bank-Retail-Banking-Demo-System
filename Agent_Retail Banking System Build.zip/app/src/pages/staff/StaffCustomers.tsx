import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { Search, Download, ChevronLeft, ChevronRight, Eye, StickyNote, MoreHorizontal } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/providers/trpc";
import StatusBadge from "@/components/shared/StatusBadge";
import StaffLayout from "@/components/staff/StaffLayout";
import { cn } from "@/lib/utils";

type KycFilter = "" | "verified" | "pending" | "under_review" | "rejected";

const KYC_OPTIONS: { value: KycFilter; label: string }[] = [
  { value: "", label: "All KYC statuses" },
  { value: "verified", label: "Verified" },
  { value: "pending", label: "Pending" },
  { value: "under_review", label: "Under Review" },
  { value: "rejected", label: "Rejected" },
];

const KYC_BADGE: Record<string, string> = {
  verified: "Verified",
  pending: "Pending",
  under_review: "Under Review",
  rejected: "Rejected",
};

function initials(first: string, last: string) {
  return `${first[0] ?? ""}${last[0] ?? ""}`.toUpperCase();
}

function DirectoryBody() {
  const navigate = useNavigate();
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [kyc, setKyc] = useState<KycFilter>("");
  const [page, setPage] = useState(1);

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => {
      setSearch(searchInput.trim());
      setPage(1);
    }, 350);
    return () => clearTimeout(t);
  }, [searchInput]);

  const query = trpc.staff.listCustomers.useQuery({
    search: search || undefined,
    status: kyc || undefined,
    page,
  });

  useEffect(() => {
    if (query.error) toast.error("Failed to load customers. Please retry.");
  }, [query.error]);

  const data = query.data;
  const pageCount = useMemo(
    () => Math.max(1, Math.ceil((data?.total ?? 0) / (data?.pageSize ?? 20))),
    [data]
  );

  const exportCsv = () => {
    if (!data) return;
    const header = "customerNo,firstName,lastName,email,phone,kycStatus,branch,openedAt";
    const rows = data.customers.map((c) =>
      [
        c.customerNo,
        c.firstName,
        c.lastName,
        c.email,
        c.phone,
        c.kycStatus,
        c.branch?.name ?? "",
        format(new Date(c.createdAt), "yyyy-MM-dd"),
      ].join(",")
    );
    const blob = new Blob([[header, ...rows].join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `meridian-customers-page${page}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${rows.length} customers to CSV.`);
  };

  return (
    <div className="mx-auto max-w-[1400px] space-y-4">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-lg font-semibold text-staff-text">Customer Directory</h1>
          <p className="text-[12px] text-staff-subtle">
            {data ? `${data.total.toLocaleString()} customers` : "Loading…"}
          </p>
        </div>
        <button
          type="button"
          onClick={exportCsv}
          disabled={!data || data.customers.length === 0}
          className="flex h-8 items-center gap-1.5 rounded-md border border-staff-border bg-staff-panel px-3 text-[12px] font-medium text-staff-text transition hover:border-staff-accent/40 hover:bg-staff-hover disabled:opacity-50"
        >
          <Download className="h-3.5 w-3.5" /> Export CSV
        </button>
      </div>

      {/* Filter bar */}
      <div className="flex flex-wrap items-center gap-2 rounded-xl border border-staff-border bg-staff-panel p-3">
        <div className="relative min-w-[260px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-staff-subtle" />
          <input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Name, email, account #, customer ID…"
            className="h-9 w-full rounded-md border border-staff-border bg-staff-sidebar pl-9 pr-3 text-[12.5px] text-staff-text placeholder:text-staff-subtle/50 focus:border-staff-accent focus:outline-none focus:ring-1 focus:ring-staff-accent/50"
          />
        </div>
        <select
          value={kyc}
          onChange={(e) => {
            setKyc(e.target.value as KycFilter);
            setPage(1);
          }}
          className="h-9 rounded-md border border-staff-border bg-staff-sidebar px-2.5 text-[12.5px] text-staff-text focus:border-staff-accent focus:outline-none"
        >
          {KYC_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-xl border border-staff-border bg-staff-panel">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[13px]">
            <thead className="sticky top-0 bg-staff-raised text-staff-subtle">
              <tr>
                {["Customer", "Contact", "Branch", "KYC", "Opened", ""].map((h, i) => (
                  <th key={i} className="px-4 py-3 text-[11px] font-semibold uppercase tracking-[0.06em]">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {query.isLoading &&
                Array.from({ length: 10 }).map((_, i) => (
                  <tr key={i} className="h-11 border-t border-staff-border">
                    <td colSpan={6} className="px-4 py-2.5">
                      <div className="h-6 animate-pulse rounded bg-staff-raised" />
                    </td>
                  </tr>
                ))}
              {!query.isLoading && data?.customers.length === 0 && (
                <tr className="border-t border-staff-border">
                  <td colSpan={6} className="px-4 py-12 text-center text-staff-subtle">
                    No customers match your filters.
                  </td>
                </tr>
              )}
              {data?.customers.map((c, i) => (
                <motion.tr
                  key={c.id}
                  initial={page === 1 && i < 12 ? { opacity: 0, y: 4 } : false}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15, delay: Math.min(i, 12) * 0.02 }}
                  onClick={() => navigate(`/staff/customers/${c.id}`)}
                  className={cn(
                    "group h-11 cursor-pointer border-t border-staff-border transition-colors hover:bg-staff-hover",
                    i % 2 === 1 && "bg-staff-zebra"
                  )}
                >
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2.5">
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-staff-accent/15 text-[10.5px] font-semibold text-staff-accent">
                        {initials(c.firstName, c.lastName)}
                      </span>
                      <div className="leading-tight">
                        <p className="font-medium text-staff-text">
                          {c.firstName} {c.lastName}
                        </p>
                        <p className="font-mono text-[10.5px] text-staff-subtle">{c.customerNo}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-2.5">
                    <p className="text-[12px] text-staff-text">{c.email}</p>
                    <p className="font-mono text-[10.5px] text-staff-subtle">{c.phone}</p>
                  </td>
                  <td className="px-4 py-2.5 text-staff-subtle">{c.branch?.name ?? "—"}</td>
                  <td className="px-4 py-2.5">
                    <StatusBadge dark status={KYC_BADGE[c.kycStatus] ?? c.kycStatus} />
                  </td>
                  <td className="px-4 py-2.5 font-mono text-[11.5px] tabular-nums text-staff-subtle">
                    {format(new Date(c.createdAt), "MMM yyyy")}
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center justify-end gap-1 opacity-0 transition group-hover:opacity-100">
                      <button
                        type="button"
                        aria-label="View profile"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/staff/customers/${c.id}`);
                        }}
                        className="rounded p-1.5 text-staff-subtle transition hover:bg-staff-raised hover:text-staff-accent"
                      >
                        <Eye className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label="Notes"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/staff/customers/${c.id}?tab=notes`);
                        }}
                        className="rounded p-1.5 text-staff-subtle transition hover:bg-staff-raised hover:text-staff-accent"
                      >
                        <StickyNote className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label="More actions"
                        onClick={(e) => e.stopPropagation()}
                        className="rounded p-1.5 text-staff-subtle transition hover:bg-staff-raised"
                      >
                        <MoreHorizontal className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Server-side pagination footer */}
        <div className="flex items-center justify-between border-t border-staff-border px-4 py-2.5 text-xs text-staff-subtle">
          <span className="tabular-nums">
            {data && data.total > 0
              ? `Showing ${(page - 1) * data.pageSize + 1}–${Math.min(page * data.pageSize, data.total)} of ${data.total.toLocaleString()}`
              : "Showing 0"}
          </span>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1 || query.isFetching}
              aria-label="Previous page"
              className="rounded p-1 transition hover:bg-white/5 disabled:opacity-30"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="tabular-nums">
              {page} / {pageCount}
            </span>
            <button
              type="button"
              onClick={() => setPage((p) => Math.min(pageCount, p + 1))}
              disabled={page >= pageCount || query.isFetching}
              aria-label="Next page"
              className="rounded p-1 transition hover:bg-white/5 disabled:opacity-30"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function StaffCustomers() {
  return (
    <StaffLayout>
      <DirectoryBody />
    </StaffLayout>
  );
}
