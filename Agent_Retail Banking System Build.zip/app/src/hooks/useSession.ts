import { useCallback, useEffect, useState } from "react";
import { SESSION_STORAGE_KEY, type SessionUser } from "@contracts/types";
import { trpc } from "@/providers/trpc";

type StoredSession = { token: string; user: SessionUser };

export function getSessionToken(): string | null {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as StoredSession).token : null;
  } catch {
    return null;
  }
}

export function getStoredSession(): StoredSession | null {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as StoredSession) : null;
  } catch {
    return null;
  }
}

export function useSession() {
  const [session, setSession] = useState<StoredSession | null>(() => getStoredSession());
  const loginMutation = trpc.auth.login.useMutation();
  const logoutMutation = trpc.auth.logout.useMutation();

  useEffect(() => {
    const onStorage = () => setSession(getStoredSession());
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const login = useCallback(
    async (username: string, password: string) => {
      const res = await loginMutation.mutateAsync({ username, password });
      const next: StoredSession = { token: res.token, user: res.user };
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(next));
      setSession(next);
      return res.user;
    },
    [loginMutation],
  );

  const logout = useCallback(async () => {
    try {
      await logoutMutation.mutateAsync();
    } catch {
      // token may already be invalid — clear locally regardless
    }
    localStorage.removeItem(SESSION_STORAGE_KEY);
    setSession(null);
  }, [logoutMutation]);

  return {
    token: session?.token ?? null,
    user: session?.user ?? null,
    role: session?.user.role ?? null,
    isAuthenticated: session != null,
    login,
    logout,
  };
}
