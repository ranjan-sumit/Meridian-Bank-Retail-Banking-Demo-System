import { useState } from "react";
import { motion, AnimatePresence, useMotionValue, useTransform } from "framer-motion";
import { Eye, EyeOff, X } from "lucide-react";
import { toast } from "sonner";
import BankingLayout from "@/components/banking/BankingLayout";
import StatusBadge from "@/components/shared/StatusBadge";
import { trpc } from "@/providers/trpc";
import { fmtMoney, statusLabel } from "@/components/banking/format";
import { cn } from "@/lib/utils";

function TiltCard({
  art,
  last4,
  fullNumber,
  holder,
  exp,
  frozen,
}: {
  art: string;
  last4: string;
  fullNumber: string;
  holder: string;
  exp: string;
  frozen: boolean;
}) {
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const rotateX = useTransform(my, [-0.5, 0.5], [6, -6]);
  const rotateY = useTransform(mx, [-0.5, 0.5], [-6, 6]);
  const [reveal, setReveal] = useState(false);

  return (
    <motion.div
      style={{ rotateX, rotateY, transformStyle: "preserve-3d", perspective: 800 }}
      onMouseMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        mx.set((e.clientX - r.left) / r.width - 0.5);
        my.set((e.clientY - r.top) / r.height - 0.5);
      }}
      onMouseLeave={() => {
        mx.set(0);
        my.set(0);
      }}
      className={cn(
        "relative aspect-[856/540] w-full overflow-hidden rounded-2xl shadow-lg transition-[filter] duration-500",
        frozen && "grayscale-[60%]"
      )}
    >
      <img src={art} alt="" className="absolute inset-0 h-full w-full object-cover" />
      {frozen && <div className="absolute inset-0 bg-sky-200/20" />}
      <div className="absolute inset-0 flex flex-col justify-end p-[6%] text-white">
        <button
          onClick={() => setReveal((v) => !v)}
          className="mb-[2%] flex items-center gap-2 font-mono text-[clamp(12px,1.4vw,18px)] tracking-[0.12em] drop-shadow"
        >
          {reveal ? fullNumber : `•••• •••• •••• ${last4}`}
          {reveal ? <EyeOff className="h-4 w-4 opacity-70" /> : <Eye className="h-4 w-4 opacity-70" />}
        </button>
        <div className="flex items-end justify-between">
          <div>
            <p className="text-[9px] uppercase tracking-widest opacity-70">Card holder</p>
            <p className="text-[clamp(10px,1.1vw,14px)] font-medium uppercase tracking-wide">{holder}</p>
          </div>
          <div className="text-right">
            <p className="text-[9px] uppercase tracking-widest opacity-70">Expires</p>
            <p className="font-mono text-[clamp(10px,1.1vw,14px)]">{exp}</p>
          </div>
          <img src="/logo-mark.svg" alt="" className="h-[clamp(20px,3vw,36px)] w-auto" />
        </div>
      </div>
    </motion.div>
  );
}

export default function Cards() {
  const utils = trpc.useUtils();
  const q = trpc.customer.listCards.useQuery();
  const setStatus = trpc.customer.setCardStatus.useMutation({
    onSuccess: (res) => {
      toast.success(res.status === "frozen" ? "Card frozen" : "Card unfrozen", {
        description:
          res.status === "frozen"
            ? "New purchases will be declined until you unfreeze."
            : "Your card is ready to use.",
      });
      utils.customer.listCards.invalidate();
    },
    onError: (e) => toast.error("Couldn't update card", { description: e.message }),
  });

  const [onlinePurchases, setOnlinePurchases] = useState(true);
  const [intl, setIntl] = useState(false);
  const [payOpen, setPayOpen] = useState(false);
  const [payAmount, setPayAmount] = useState("45.00");
  const [lostOpen, setLostOpen] = useState<number | null>(null);

  const cards = q.data ?? [];
  const activeCount = cards.filter((c) => c.card.status === "active").length;
  const frozenCount = cards.filter((c) => c.card.status === "frozen").length;

  return (
    <BankingLayout>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h1 className="font-display text-[28px] font-bold text-navy">Cards</h1>
        <span className="rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs text-body">
          {activeCount} active card{activeCount === 1 ? "" : "s"}
          {frozenCount > 0 && ` · ${frozenCount} frozen`}
        </span>
      </div>

      <div className="mt-4 rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800">
        Traveling? Set a travel notice to avoid declines.
      </div>
      {frozenCount > 0 && (
        <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          A card is frozen. New purchases will be declined.
        </div>
      )}

      {q.isLoading ? (
        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
          {[0, 1].map((i) => (
            <div key={i} className="h-72 animate-pulse rounded-xl border border-slate-200 bg-white" />
          ))}
        </div>
      ) : (
        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
          {cards.map(({ card, accountNickname }, i) => {
            const isCredit = card.type === "credit";
            const frozen = card.status === "frozen";
            return (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
              >
                <TiltCard
                  art={isCredit ? "/card-platinum.png" : "/card-debit.png"}
                  last4={card.last4}
                  fullNumber={card.fullNumber}
                  holder={card.holder}
                  exp={card.expiresAt.slice(5, 7) + "/" + card.expiresAt.slice(2, 4)}
                  frozen={frozen}
                />
                <div className="mt-4 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-navy">
                      {isCredit ? "Platinum Rewards Credit" : `Debit · linked to ${accountNickname}`}
                    </p>
                    <p className="text-xs text-subtle">•••• {card.last4} · {card.network.toUpperCase()}</p>
                  </div>
                  <StatusBadge status={statusLabel(card.status)} />
                </div>

                {isCredit ? (
                  <div className="mt-4">
                    <div className="flex justify-between text-xs text-subtle">
                      <span>
                        Balance <b className="tabular-nums text-body">{fmtMoney("2340.18")}</b> · Limit{" "}
                        {fmtMoney(card.creditLimit)}
                      </span>
                      <span>16% utilized</span>
                    </div>
                    <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full w-[16%] rounded-full bg-gradient-to-r from-money to-amber-500" />
                    </div>
                    <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                      <p className="rounded-lg bg-slate-50 p-2.5">
                        <span className="text-subtle">Payment due</span>
                        <br />
                        <b className="text-body">Mar 1, 2025 — Min $45.00</b>
                      </p>
                      <p className="rounded-lg bg-slate-50 p-2.5">
                        <span className="text-subtle">Rewards</span>
                        <br />
                        <b className="text-body">24,830 pts ≈ $248.30</b>
                      </p>
                      <p className="rounded-lg bg-slate-50 p-2.5">
                        <span className="text-subtle">APR</span>
                        <br />
                        <b className="text-body">21.49% variable</b>
                      </p>
                      <p className="rounded-lg bg-slate-50 p-2.5">
                        <span className="text-subtle">Monthly spend cap</span>
                        <br />
                        <b className="tabular-nums text-body">$3,000</b>
                      </p>
                    </div>
                    <div className="mt-3 flex gap-5 text-sm">
                      <label className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={onlinePurchases}
                          onChange={(e) => setOnlinePurchases(e.target.checked)}
                          className="accent-[#0B2545]"
                        />
                        Online purchases
                      </label>
                      <label className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={intl}
                          onChange={(e) => setIntl(e.target.checked)}
                          className="accent-[#0B2545]"
                        />
                        International
                      </label>
                    </div>
                    <button
                      onClick={() => setPayOpen(true)}
                      className="mt-4 rounded-lg bg-navy px-4 py-2 text-sm font-semibold text-white transition hover:bg-navy-deep"
                    >
                      Make a payment
                    </button>
                  </div>
                ) : (
                  <div className="mt-4">
                    <p className="text-xs text-subtle">ATM daily limit $500 · PIN change available at any branch</p>
                  </div>
                )}

                <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-slate-100 pt-4">
                  <button
                    onClick={() => setStatus.mutate({ id: card.id, status: frozen ? "active" : "frozen" })}
                    disabled={setStatus.isPending || card.status === "blocked"}
                    className={cn(
                      "rounded-lg px-4 py-2 text-sm font-semibold transition disabled:opacity-50",
                      frozen
                        ? "bg-gold text-navy hover:bg-gold-hover"
                        : "border border-slate-300 text-navy hover:border-navy"
                    )}
                  >
                    {frozen ? "Unfreeze card" : "Freeze card"}
                  </button>
                  <button
                    onClick={() => toast.success("Travel notice saved", { description: "We'll keep your card working while you travel." })}
                    className="text-sm font-medium text-navy hover:underline"
                  >
                    Set travel notice
                  </button>
                  <button
                    onClick={() => toast.success("Replacement card ordered", { description: "Arrives in 5–7 business days." })}
                    className="text-sm font-medium text-navy hover:underline"
                  >
                    Replace card
                  </button>
                  <button
                    onClick={() => setLostOpen(card.id)}
                    className="text-sm font-medium text-[#B42318] hover:underline"
                  >
                    Report lost or stolen
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Recent card transactions */}
      <div className="mt-8 rounded-xl border border-slate-200 bg-white shadow-sm">
        <h2 className="border-b border-slate-100 px-5 py-4 font-display text-[17px] font-semibold text-navy">
          Recent card transactions
        </h2>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase tracking-[0.06em] text-slate-500">
              <th className="px-5 py-2.5 font-medium">Date</th>
              <th className="px-3 py-2.5 font-medium">Card</th>
              <th className="px-3 py-2.5 font-medium">Merchant</th>
              <th className="px-3 py-2.5 text-right font-medium">Amount</th>
              <th className="px-5 py-2.5 text-right font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {[
              ["Feb 12", "••••7712", "Netflix.com", "$15.49", "Posted"],
              ["Feb 11", "••••7712", "Shell Oil #8842", "$52.10", "Posted"],
              ["Feb 09", "••••3305", "ATM — 400 Meridian Ave", "$200.00", "Declined"],
              ["Feb 08", "••••7712", "Amazon.com", "$63.99", "Posted"],
              ["Feb 05", "••••3305", "Starbucks #2291", "$6.45", "Posted"],
            ].map(([d, c, m, a, s], i) => (
              <motion.tr
                key={d + m}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                className="border-t border-slate-50 transition hover:bg-slate-50"
              >
                <td className="px-5 py-3 text-subtle">{d}</td>
                <td className="px-3 py-3 font-mono text-xs text-subtle">{c}</td>
                <td className="px-3 py-3 font-medium text-body">{m}</td>
                <td className="px-3 py-3 text-right tabular-nums text-body">{a}</td>
                <td className="px-5 py-3 text-right">
                  <StatusBadge status={s === "Declined" ? "Rejected" : s} />
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Payment modal */}
      <AnimatePresence>
        {payOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end justify-center bg-navy-deep/50 p-4 sm:items-center"
            onClick={() => setPayOpen(false)}
          >
            <motion.div
              initial={{ y: 48, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 32, opacity: 0 }}
              transition={{ type: "spring", damping: 26, stiffness: 300 }}
              className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between">
                <h3 className="font-display text-lg font-semibold text-navy">Make a payment</h3>
                <button onClick={() => setPayOpen(false)} className="text-slate-400 hover:text-navy">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <label className="mt-4 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">
                Amount
              </label>
              <input
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value.replace(/[^0-9.]/g, ""))}
                className="mt-1.5 h-11 w-full rounded-lg border border-slate-300 px-3 text-lg tabular-nums outline-none focus:border-navy"
              />
              <div className="mt-2 flex gap-2 text-xs">
                <button onClick={() => setPayAmount("45.00")} className="rounded-full border border-slate-200 px-3 py-1 hover:border-gold">
                  Minimum $45.00
                </button>
                <button onClick={() => setPayAmount("2340.18")} className="rounded-full border border-slate-200 px-3 py-1 hover:border-gold">
                  Full balance
                </button>
              </div>
              <label className="mt-4 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">
                From account
              </label>
              <select className="mt-1.5 h-11 w-full rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-navy">
                <option>Everyday Checking •••• 4821 — $12,450.33</option>
                <option>High-Yield Savings •••• 9034 — $48,920.15</option>
              </select>
              <button
                onClick={() => {
                  setPayOpen(false);
                  toast.success("Payment scheduled", { description: `${fmtMoney(payAmount)} toward Platinum Rewards •••• 7712.` });
                }}
                className="mt-5 h-11 w-full rounded-lg bg-gold font-semibold text-navy transition hover:bg-gold-hover"
              >
                Confirm payment
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Lost/stolen confirm */}
      <AnimatePresence>
        {lostOpen != null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-navy-deep/50 p-4"
            onClick={() => setLostOpen(null)}
          >
            <motion.div
              initial={{ scale: 0.96 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.97 }}
              className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="font-display text-lg font-semibold text-[#B42318]">Report card lost or stolen?</h3>
              <p className="mt-1.5 text-sm text-subtle">
                The card will be permanently blocked and a replacement issued. This cannot be undone.
              </p>
              <div className="mt-5 flex gap-3">
                <button
                  onClick={() => setLostOpen(null)}
                  className="h-10 flex-1 rounded-lg border border-slate-300 text-sm font-medium text-navy"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    setLostOpen(null);
                    toast.success("Card reported", { description: "Card blocked. Replacement on the way." });
                  }}
                  className="h-10 flex-1 rounded-lg bg-[#B42318] text-sm font-semibold text-white hover:bg-red-800"
                >
                  Block card
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </BankingLayout>
  );
}
