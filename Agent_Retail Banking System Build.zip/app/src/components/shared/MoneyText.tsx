import { cn } from "@/lib/utils";

export function formatMoney(
  amount: number,
  currency = "USD",
  opts?: { sign?: boolean }
): string {
  const abs = Math.abs(amount);
  const str = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(abs);
  if (opts?.sign) {
    return amount < 0 ? `−${str}` : `+${str}`;
  }
  return amount < 0 ? `−${str}` : str;
}

/**
 * Tabular-nums currency text.
 * variant="flow": negative red with −$, positive emerald with +$ (activity feeds).
 * variant="neutral": sign shown but no color (ledgers with Dr/Cr columns).
 */
export default function MoneyText({
  amount,
  currency = "USD",
  variant = "flow",
  className,
}: {
  amount: number;
  currency?: string;
  variant?: "flow" | "neutral";
  className?: string;
}) {
  const signed = formatMoney(amount, currency, { sign: variant === "flow" });
  const color =
    variant === "neutral"
      ? undefined
      : amount < 0
        ? "text-[#B42318]"
        : "text-[#0E7C5B]";
  return (
    <span className={cn("tabular-nums", color, className)}>{signed}</span>
  );
}
