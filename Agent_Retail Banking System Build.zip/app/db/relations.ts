import { relations } from "drizzle-orm";
import {
  branches,
  customers,
  users,
  sessions,
  employees,
  accounts,
  transactions,
  payees,
  cards,
  loanProducts,
  loans,
  loanPayments,
  kycCases,
  alerts,
  notifications,
} from "./schema";

export const branchesRelations = relations(branches, ({ many }) => ({
  customers: many(customers),
  employees: many(employees),
  accounts: many(accounts),
  loans: many(loans),
}));

export const customersRelations = relations(customers, ({ one, many }) => ({
  branch: one(branches, { fields: [customers.branchId], references: [branches.id] }),
  accounts: many(accounts),
  cards: many(cards),
  loans: many(loans),
  payees: many(payees),
  notifications: many(notifications),
  kycCases: many(kycCases),
  alerts: many(alerts),
  users: many(users),
}));

export const usersRelations = relations(users, ({ one }) => ({
  customer: one(customers, { fields: [users.customerId], references: [customers.id] }),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, { fields: [sessions.userId], references: [users.id] }),
}));

export const employeesRelations = relations(employees, ({ one }) => ({
  branch: one(branches, { fields: [employees.branchId], references: [branches.id] }),
}));

export const accountsRelations = relations(accounts, ({ one, many }) => ({
  customer: one(customers, { fields: [accounts.customerId], references: [customers.id] }),
  branch: one(branches, { fields: [accounts.branchId], references: [branches.id] }),
  transactions: many(transactions),
  cards: many(cards),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  account: one(accounts, { fields: [transactions.accountId], references: [accounts.id] }),
  counterAccount: one(accounts, {
    fields: [transactions.counterAccountId],
    references: [accounts.id],
    relationName: "counter",
  }),
}));

export const payeesRelations = relations(payees, ({ one }) => ({
  customer: one(customers, { fields: [payees.customerId], references: [customers.id] }),
}));

export const cardsRelations = relations(cards, ({ one }) => ({
  customer: one(customers, { fields: [cards.customerId], references: [customers.id] }),
  account: one(accounts, { fields: [cards.accountId], references: [accounts.id] }),
}));

export const loanProductsRelations = relations(loanProducts, ({ many }) => ({
  loans: many(loans),
}));

export const loansRelations = relations(loans, ({ one, many }) => ({
  customer: one(customers, { fields: [loans.customerId], references: [customers.id] }),
  product: one(loanProducts, { fields: [loans.productId], references: [loanProducts.id] }),
  branch: one(branches, { fields: [loans.branchId], references: [branches.id] }),
  payments: many(loanPayments),
}));

export const loanPaymentsRelations = relations(loanPayments, ({ one }) => ({
  loan: one(loans, { fields: [loanPayments.loanId], references: [loans.id] }),
}));

export const kycCasesRelations = relations(kycCases, ({ one }) => ({
  customer: one(customers, { fields: [kycCases.customerId], references: [customers.id] }),
}));

export const alertsRelations = relations(alerts, ({ one }) => ({
  customer: one(customers, { fields: [alerts.customerId], references: [customers.id] }),
  transaction: one(transactions, {
    fields: [alerts.transactionId],
    references: [transactions.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  customer: one(customers, { fields: [notifications.customerId], references: [customers.id] }),
}));
