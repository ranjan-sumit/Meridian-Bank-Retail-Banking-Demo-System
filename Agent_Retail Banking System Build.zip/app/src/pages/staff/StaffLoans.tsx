import { useMemo, useState } from "react";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { toast, Toaster } from "sonner";
import { Gauge, AlertTriangle, Landmark } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useSession } from "@/hooks/useSession";
import DataTable, { type Column } from "@/components/shared/DataTable";
import StatusBadge from "@/components/shared/StatusBadge";
import MoneyText from "@/components/shared/MoneyText";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from "@/components/ui/sheet";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

type LoanRow = {
  id: number;
  loanNo: string;
  principal: string;
  remainingBalance: string;
  rateApr: string;
  termMonths: number;
  monthlyPayment: string;
  purpose: string;
  status: "pending" | "approved" | "rejected" | "active" | "delinquent" | "paid_off";
  appliedAt: Date;
  decidedAt: Date | null;
  decidedBy: string | null;
  product: { code: string; name: string; rateApr: string };
  customerName: string;
  customerNo: string;
};

const STATUS_LABEL: Record<string, string> = {
  pending: "Pending", approved: "Approved", rejected: "Rejected",
  active: "Active", delinquent: "Delinquent", paid_off: "Paid Off",
};
const REJECT_REASONS = ["DTI above threshold", "Credit history", "Insufficient income", "Other"];

/** Deterministic per-loan demo credit attributes (not exposed by API). */
function creditAttrs(loanNo: string) {
  let h = 0;
  for (const c of loanNo) h = (h * 31 + c.charCodeAt(0)) % 997;
  return { credit: 640 + (h % 200), dti: 18 + (h % 40), income: 52000 + (h % 60) * 1800 };
}

function DtiGauge({ dti }: { dti: number }) {
  const pct = Math.min(dti, 60) / 60;
  const angle = -90 + pct * 180;
  const color = dti < 36 ? "#34D399" : dti < 43 ? "#FBBF24" : "#F87171";
  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 120 70" className="w-40">
        <path d="M10 60 A50 50 0 0 1 110 60" fill="none" stroke="#263343" strokeWidth="10" strokeLinecap="round" />
        <motion.path
          d="M10 60 A50 50 0 0 1 110 60"
          fill="none" stroke={color} strokeWidth="10" strokeLinecap="round"
          strokeDasharray="157" initial={{ strokeDashoffset: 157 }}
          animate={{ strokeDashoffset: 157 - pct * 157 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
        <motion.line
          x1="60" y1="60" x2="60" y2="20" stroke="#E6EDF5" strokeWidth="2"
          initial={{ rotate: -90 }} animate={{ rotate: angle }}
          style={{ transformOrigin: "60px 60px" }} transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </svg>
      <span className="font-mono text-xl tabular-nums" style={{ color }}>{dti}%</span>
      <span className="text-[11px] text-staff-subtle">Debt-to-income</span>
    </div>
  );
}

function CreditBar({ score }: { score: number }) {
  const pct = ((score - 300) / 550) * 100;
  return (
    <div>
      <div className="flex justify-between text-[11px] text-staff-subtle"><span>300</span><span>Credit score</span><span>850</span></div>
      <div className="relative mt-1 h-2 rounded-full bg-gradient-to-r from-red-500 via-amber-400 to-emerald-400">
        <motion.div
          className="absolute -top-1 h-4 w-1 rounded bg-white shadow"
          initial={{ left: 0 }} animate={{ left: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>
      <div className="mt-1 text-right font-mono text-sm tabular-nums text-staff-text">{score}</div>
    </div>
  );
}

type ScheduleRow = { n: number; due: string; amount: number; principal: number; interest: number; balance: number };

function buildSchedule(loan: LoanRow): ScheduleRow[] {
  const r = Number(loan.rateApr) / 1200;
  const pmt = Number(loan.monthlyPayment);
  let bal = Number(loan.principal);
  const rows: ScheduleRow[] = [];
  const start = new Date(Date.UTC(2025, 1, 1));
  for (let i = 1; i <= loan.termMonths && i <= 360; i++) {
    const interest = +(bal * r).toFixed(2);
    const principalPart = +(pmt - interest).toFixed(2);
    bal = +(bal - principalPart).toFixed(2);
    const due = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + i, 1));
    rows.push({ n: i, due: due.toISOString().slice(0, 10), amount: pmt, principal: principalPart, interest, balance: Math.max(bal, 0) });
  }
  return rows;
}

export default function StaffLoans() {
  const { role } = useSession();
  const utils = trpc.useUtils();
  const [tab, setTab] = useState<"queue" | "active" | "all">("queue");
  const loansQuery = trpc.staff.loanQueue.useQuery({});
  const [selected, setSelected] = useState<LoanRow | null>(null);
  const [decision, setDecision] = useState<"approve" | "reject" | null>(null);
  const [reason, setReason] = useState("");
  const [note, setNote] = useState("");
  const [showFullSchedule, setShowFullSchedule] = useState(false);

  const decide = trpc.staff.decideLoan.useMutation({
    onSuccess: (_d, vars) => {
      toast.success(vars.approve
        ? `${selected?.loanNo} approved. Disbursement scheduled.`
        : `${selected?.loanNo} rejected`);
      void utils.staff.loanQueue.invalidate();
      setDecision(null);
      setSelected(null);
      setReason(""); setNote("");
    },
    onError: (e) => toast.error(e.message),
  });

  const all = (loansQuery.data ?? []) as LoanRow[];
  const rows = useMemo(() => {
    if (tab === "queue") return all.filter((l) => l.status === "pending" || l.status === "approved");
    if (tab === "active") return all.filter((l) => l.status === "active" || l.status === "delinquent" || l.status === "paid_off");
    return all;
  }, [all, tab]);
  const queueCount = all.filter((l) => l.status === "pending").length;

  const columns: Column<LoanRow>[] = useMemo(() => {
    const base: Column<LoanRow>[] = [
      { key: "id", header: "App / Loan ID", render: (r) => <span className="font-mono text-[12.5px] text-[#2DD4A8]">{r.loanNo}</span>, sortValue: (r) => r.loanNo },
      { key: "applicant", header: tab === "active" ? "Borrower" : "Applicant", render: (r) => <span className="text-staff-text">{r.customerName}</span>, sortValue: (r) => r.customerName },
      { key: "product", header: "Product", render: (r) => <span className="text-staff-subtle">{r.product.name}</span> },
      {
        key: "amount", header: tab === "active" ? "Remaining" : "Amount", headerClassName: "text-right", className: "text-right",
        render: (r) => <MoneyText variant="neutral" amount={Number(tab === "active" ? r.remainingBalance : r.principal)} className="font-mono text-[12.5px] text-staff-text" />,
        sortValue: (r) => Number(r.principal),
      },
      { key: "rate", header: "Rate", render: (r) => <span className="font-mono text-[12.5px] tabular-nums text-staff-subtle">{Number(r.rateApr).toFixed(1)}%</span>, sortValue: (r) => Number(r.rateApr) },
      { key: "term", header: "Term", render: (r) => <span className="font-mono text-[12.5px] tabular-nums text-staff-subtle">{r.termMonths}mo</span> },
      {
        key: "dti", header: "DTI",
        render: (r) => {
          const { dti } = creditAttrs(r.loanNo);
          return <span className={cn("font-mono text-[12.5px] tabular-nums", dti < 36 ? "text-emerald-300" : dti < 43 ? "text-amber-300" : "text-red-400")}>{dti}%</span>;
        },
        sortValue: (r) => creditAttrs(r.loanNo).dti,
      },
      { key: "status", header: "Status", render: (r) => <StatusBadge dark status={STATUS_LABEL[r.status]} /> },
      {
        key: "actions", header: "",
        render: (r) => (
          <button
            onClick={(e) => { e.stopPropagation(); setSelected(r); setShowFullSchedule(false); }}
            className="rounded-md border border-[#2DD4A8]/40 px-3 py-1 text-xs font-medium text-[#2DD4A8] transition hover:bg-[#2DD4A8]/10"
          >
            {r.status === "pending" ? "Review" : "Open"}
          </button>
        ),
      },
    ];
    return base;
  }, [tab]);

  const attrs = selected ? creditAttrs(selected.loanNo) : null;
  const over50k = selected ? Number(selected.principal) > 50000 : false;
  const schedule = selected ? buildSchedule(selected) : [];
  const canDecideRole = role === "manager" || role === "admin";

  return (
    <div className="space-y-5">
      <Toaster position="top-right" theme="dark" richColors />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-semibold text-staff-text">Loan Management</h1>
          <p className="text-xs text-staff-subtle">Underwriting queue, active book and application history</p>
        </div>
        <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
          <TabsList className="border border-staff-border bg-staff-panel">
            <TabsTrigger value="queue">Approval Queue ({queueCount})</TabsTrigger>
            <TabsTrigger value="active">Active Loans</TabsTrigger>
            <TabsTrigger value="all">All Applications</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {loansQuery.isLoading ? (
        <div className="space-y-2 rounded-xl border border-staff-border bg-staff-panel p-4">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-11 w-full bg-staff-raised" />)}
        </div>
      ) : loansQuery.isError ? (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-6 text-sm text-red-300">Failed to load loans: {loansQuery.error.message}</div>
      ) : (
        <DataTable
          dark columns={columns} data={rows} pageSize={10} rowKey={(r) => r.loanNo}
          onRowClick={(r) => { setSelected(r); setShowFullSchedule(false); }}
          flagged={(r) => r.status === "delinquent"}
          emptyMessage={tab === "queue" ? "Approval queue is clear." : "No loans in this view."}
        />
      )}

      {/* Review / detail drawer */}
      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <SheetContent side="right" className="w-full overflow-y-auto border-l border-staff-border bg-staff-panel p-0 text-staff-text sm:max-w-[560px]">
          {selected && attrs && (
            <div className="flex min-h-full flex-col">
              <SheetHeader className="border-b border-staff-border px-5 py-4">
                <div className="flex items-center gap-3">
                  <SheetTitle className="font-mono text-base text-[#2DD4A8]">{selected.loanNo}</SheetTitle>
                  <StatusBadge dark status={STATUS_LABEL[selected.status]} />
                </div>
                <SheetDescription className="text-staff-subtle">
                  {selected.customerName} · {selected.product.name} · applied {format(new Date(selected.appliedAt), "MMM d, yyyy")}
                </SheetDescription>
              </SheetHeader>

              <div className="space-y-4 p-5">
                {over50k && selected.status === "pending" && (
                  <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-[12px] text-amber-200">
                    <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                    Amount exceeds $50,000 — maker-checker applies: requires Admin counter-approval.
                  </div>
                )}
                <div className="grid grid-cols-2 gap-4 rounded-lg border border-staff-border bg-staff-raised p-4">
                  <DtiGauge dti={attrs.dti} />
                  <div className="flex flex-col justify-center gap-3">
                    <CreditBar score={attrs.credit} />
                    <div className="space-y-1 text-[12px]">
                      <div className="flex justify-between"><span className="text-staff-subtle">Annual income</span><span className="font-mono tabular-nums text-staff-text">${attrs.income.toLocaleString()}</span></div>
                      <div className="flex justify-between"><span className="text-staff-subtle">Existing obligations</span><span className="font-mono tabular-nums text-staff-text">${Math.round(attrs.income * attrs.dti / 1200).toLocaleString()}/mo</span></div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border border-staff-border bg-staff-raised p-4 text-[12.5px]">
                  <div className="mb-2 text-[11px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">Requested terms</div>
                  <div className="grid grid-cols-2 gap-y-1.5">
                    <span className="text-staff-subtle">Amount</span><span className="text-right font-mono tabular-nums text-staff-text">${Number(selected.principal).toLocaleString()}</span>
                    <span className="text-staff-subtle">Rate APR</span><span className="text-right font-mono tabular-nums text-staff-text">{Number(selected.rateApr).toFixed(2)}%</span>
                    <span className="text-staff-subtle">Term</span><span className="text-right font-mono tabular-nums text-staff-text">{selected.termMonths} months</span>
                    <span className="text-staff-subtle">Monthly payment</span><span className="text-right font-mono tabular-nums text-staff-text">${Number(selected.monthlyPayment).toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
                    <span className="text-staff-subtle">Purpose</span><span className="text-right text-staff-text">{selected.purpose}</span>
                  </div>
                  <div className={cn(
                    "mt-3 rounded-md px-3 py-1.5 text-[12px] font-medium",
                    attrs.dti < 43 ? "bg-emerald-500/15 text-emerald-300" : "bg-amber-500/15 text-amber-300"
                  )}>
                    {attrs.dti < 43 ? "System recommendation: approve — within policy" : "Manual review — DTI above threshold"}
                  </div>
                </div>

                {/* Repayment schedule */}
                <div className="rounded-lg border border-staff-border bg-staff-raised p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-[11px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">Repayment schedule ({schedule.length} installments)</span>
                    {schedule.length > 12 && (
                      <button onClick={() => setShowFullSchedule((s) => !s)} className="text-[11.5px] text-[#2DD4A8] hover:underline">
                        {showFullSchedule ? "Show first 12" : "Show all"}
                      </button>
                    )}
                  </div>
                  <div className="max-h-64 overflow-y-auto">
                    <table className="w-full font-mono text-[11.5px] tabular-nums">
                      <thead className="sticky top-0 bg-staff-raised text-staff-subtle">
                        <tr><th className="py-1 text-left">#</th><th className="text-left">Due</th><th className="text-right">Payment</th><th className="text-right">Principal</th><th className="text-right">Interest</th><th className="text-right">Balance</th></tr>
                      </thead>
                      <tbody>
                        {(showFullSchedule ? schedule : schedule.slice(0, 12)).map((s) => (
                          <tr key={s.n} className="border-t border-staff-border/60">
                            <td className="py-1 text-staff-subtle">{s.n}</td>
                            <td className="text-staff-subtle">{s.due}</td>
                            <td className="text-right text-staff-text">${s.amount.toFixed(2)}</td>
                            <td className="text-right text-staff-text">${s.principal.toFixed(2)}</td>
                            <td className="text-right text-staff-subtle">${s.interest.toFixed(2)}</td>
                            <td className="text-right text-staff-subtle">${s.balance.toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {selected.status === "pending" && (
                <div className="sticky bottom-0 mt-auto border-t border-staff-border bg-staff-panel/95 px-5 py-3 backdrop-blur">
                  {!canDecideRole && (
                    <p className="mb-2 text-[11.5px] text-amber-300">Loan decisions require manager or admin role.</p>
                  )}
                  <div className="flex gap-2">
                    <button
                      disabled={!canDecideRole || decide.isPending}
                      onClick={() => setDecision("approve")}
                      className="flex-1 rounded-lg bg-[#2DD4A8] px-4 py-2 text-sm font-semibold text-[#0B1118] hover:bg-[#2DD4A8]/90 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      Approve
                    </button>
                    <button
                      disabled={decide.isPending}
                      onClick={() => toast.info(`Document request sent to ${selected.customerName}`)}
                      className="rounded-lg border border-blue-400/40 px-4 py-2 text-sm font-medium text-blue-300 hover:bg-blue-400/10"
                    >
                      Request documents
                    </button>
                    <button
                      disabled={!canDecideRole || decide.isPending}
                      onClick={() => setDecision("reject")}
                      className="rounded-lg border border-red-500/40 px-4 py-2 text-sm font-medium text-red-300 hover:bg-red-500/10 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              )}
              {selected.decidedBy && (
                <div className="border-t border-staff-border px-5 py-3 text-[12px] text-staff-subtle">
                  Decided by {selected.decidedBy}{selected.decidedAt ? ` · ${format(new Date(selected.decidedAt), "MMM d, yyyy")}` : ""}
                </div>
              )}
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* Decision dialog */}
      <Dialog open={!!decision} onOpenChange={(o) => !o && setDecision(null)}>
        <DialogContent className="border-staff-border bg-staff-panel text-staff-text">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              {decision === "approve" ? <Landmark className="h-5 w-5 text-[#2DD4A8]" /> : <AlertTriangle className="h-5 w-5 text-red-400" />}
              {decision === "approve" ? `Approve ${selected?.loanNo}` : `Reject ${selected?.loanNo}`}
            </DialogTitle>
            <DialogDescription className="text-staff-subtle">
              {decision === "approve"
                ? `$${selected ? Number(selected.principal).toLocaleString() : ""} at ${selected?.rateApr}% — disbursement will be scheduled and the amortization schedule generated.`
                : "A rejection reason is required and written to the audit log."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {decision === "reject" && (
              <Select value={reason} onValueChange={setReason}>
                <SelectTrigger className="border-staff-border bg-staff-raised text-staff-text"><SelectValue placeholder="Select reason" /></SelectTrigger>
                <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
                  {REJECT_REASONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={decision === "approve" ? "Optional note / rate adjustment rationale…" : "Optional note…"}
              rows={2}
              className="w-full rounded-lg border border-staff-border bg-staff-raised px-3 py-2 text-sm text-staff-text placeholder:text-staff-subtle focus:outline-none focus:ring-1 focus:ring-[#2DD4A8]"
            />
          </div>
          <DialogFooter className="gap-2">
            <button onClick={() => setDecision(null)} className="rounded-lg border border-staff-border px-4 py-2 text-sm text-staff-subtle hover:text-staff-text">Cancel</button>
            <button
              disabled={decide.isPending || (decision === "reject" && !reason)}
              onClick={() => selected && decide.mutate({
                loanId: selected.id,
                approve: decision === "approve",
                reason: decision === "reject" ? (note ? `${reason}: ${note}` : reason) : undefined,
              })}
              className={cn(
                "rounded-lg px-4 py-2 text-sm font-semibold disabled:opacity-40",
                decision === "approve" ? "bg-[#2DD4A8] text-[#0B1118]" : "bg-red-500 text-white"
              )}
            >
              {decide.isPending ? "Submitting…" : decision === "approve" ? "Confirm approval" : "Confirm rejection"}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="flex items-center gap-2 text-[11px] text-staff-subtle">
        <Gauge className="h-3.5 w-3.5" /> Policy: DTI &lt; 43% · credit ≥ 660 · amounts &gt; $50k need Admin counter-approval
      </div>
    </div>
  );
}
