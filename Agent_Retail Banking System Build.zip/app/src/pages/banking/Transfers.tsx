import { useMemo, useState } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, ArrowLeft, CheckCircle2, Copy, Check, Plus, X } from "lucide-react";
import { toast } from "sonner";
import BankingLayout from "@/components/banking/BankingLayout";
import { trpc } from "@/providers/trpc";
import { fmtMoney, num } from "@/components/banking/format";
import { cn } from "@/lib/utils";

type Mode = "own" | "payee";

export default function Transfers() {
  const utils = trpc.useUtils();
  const accountsQ = trpc.customer.listAccounts.useQuery();
  const payeesQ = trpc.customer.listPayees.useQuery();
  const transfer = trpc.customer.transfer.useMutation({
    onError: (e) => toast.error("Transfer failed", { description: e.message }),
  });

  const sources = (accountsQ.data ?? []).filter(
    (a) => (a.type === "checking" || a.type === "savings") && a.status === "active"
  );

  const [step, setStep] = useState(0);
  const [mode, setMode] = useState<Mode>("own");
  const [fromId, setFromId] = useState<number | null>(null);
  const [toId, setToId] = useState<number | null>(null);
  const [payeeId, setPayeeId] = useState<number | null>(null);
  const [amount, setAmount] = useState("");
  const [memo, setMemo] = useState("");
  const [timing, setTiming] = useState<"now" | "later" | "recurring">("now");
  const [schedDate, setSchedDate] = useState("");
  const [freq, setFreq] = useState("monthly");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [receipt, setReceipt] = useState<{ txnId: number; amount: number; fromBal: number } | null>(null);
  const [copied, setCopied] = useState(false);
  const [addPayee, setAddPayee] = useState(false);

  const from = sources.find((a) => a.id === fromId) ?? null;
  const amt = Number(amount) || 0;
  const overBalance = from != null && amt > num(from.balance);
  const valid =
    fromId != null && amt > 0 && !overBalance && (mode === "own" ? toId != null && toId !== fromId : payeeId != null);

  const toLabel = useMemo(() => {
    if (mode === "own") {
      const t = sources.find((a) => a.id === toId);
      return t ? `${t.nickname} •••• ${t.last4}` : "—";
    }
    const p = (payeesQ.data ?? []).find((x) => x.id === payeeId);
    return p ? `${p.name} · ${p.bank}` : "—";
  }, [mode, toId, payeeId, sources, payeesQ.data]);

  const confNo = receipt ? `TRF-2025-0214-${String(receipt.txnId).padStart(5, "0")}` : "";

  const submit = () => {
    if (fromId == null) return;
    transfer.mutate(
      {
        fromAccountId: fromId,
        toAccountId: mode === "own" ? toId ?? undefined : undefined,
        payeeId: mode === "payee" ? payeeId ?? undefined : undefined,
        amount: amt,
        description: memo || undefined,
      },
      {
        onSuccess: (res) => {
          setConfirmOpen(false);
          setReceipt({ txnId: res.transactionId, amount: amt, fromBal: num(from?.balance) - amt });
          setStep(2);
          utils.customer.listAccounts.invalidate();
          utils.customer.dashboardSummary.invalidate();
          toast.success("Transfer complete", { description: `${fmtMoney(amt)} sent to ${toLabel}` });
        },
      }
    );
  };

  return (
    <BankingLayout>
      <h1 className="font-display text-[28px] font-bold text-navy">Transfers</h1>
      <div className="mt-6 flex flex-col gap-6 lg:flex-row">
        {/* Wizard */}
        <div className="w-full max-w-[720px] rounded-xl border border-slate-200 bg-white shadow-sm">
          {step < 2 && (
            <div className="flex border-b border-slate-100">
              {(
                [
                  ["own", "Between my accounts"],
                  ["payee", "To another person/payee"],
                ] as const
              ).map(([m, label]) => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  className={cn(
                    "relative flex-1 px-4 py-3.5 text-sm font-medium transition",
                    mode === m ? "text-navy" : "text-subtle hover:text-navy"
                  )}
                >
                  {label}
                  {mode === m && (
                    <motion.span layoutId="transfer-mode" className="absolute inset-x-4 bottom-0 h-0.5 bg-gold" />
                  )}
                </button>
              ))}
            </div>
          )}

          <AnimatePresence mode="wait">
            {/* STEP 1 — details */}
            {step === 0 && (
              <motion.div
                key="s1"
                initial={{ opacity: 0, x: 24 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -24 }}
                transition={{ duration: 0.25 }}
                className="space-y-5 p-6"
              >
                <div>
                  <label className="mb-1.5 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">
                    From account
                  </label>
                  <select
                    value={fromId ?? ""}
                    onChange={(e) => setFromId(e.target.value ? Number(e.target.value) : null)}
                    className="h-11 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-navy"
                  >
                    <option value="">Select source account…</option>
                    {sources.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.nickname} •••• {a.last4} — {fmtMoney(a.balance)}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">
                    To
                  </label>
                  {mode === "own" ? (
                    <select
                      value={toId ?? ""}
                      onChange={(e) => setToId(e.target.value ? Number(e.target.value) : null)}
                      className="h-11 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-navy"
                    >
                      <option value="">Select destination account…</option>
                      {sources
                        .filter((a) => a.id !== fromId)
                        .map((a) => (
                          <option key={a.id} value={a.id}>
                            {a.nickname} •••• {a.last4} — {fmtMoney(a.balance)}
                          </option>
                        ))}
                    </select>
                  ) : (
                    <div className="space-y-2">
                      {(payeesQ.data ?? []).map((p) => (
                        <button
                          key={p.id}
                          onClick={() => setPayeeId(p.id)}
                          className={cn(
                            "flex w-full items-center justify-between rounded-lg border p-3 text-left text-sm transition",
                            payeeId === p.id
                              ? "border-gold bg-amber-50/50"
                              : "border-slate-200 hover:border-navy/40"
                          )}
                        >
                          <span>
                            <span className="font-medium text-navy">{p.name}</span>
                            <span className="ml-2 text-xs text-subtle">
                              ••••{p.accountNumber.slice(-4)} · {p.bank}
                            </span>
                          </span>
                          {payeeId === p.id && <CheckCircle2 className="h-4 w-4 text-gold" />}
                        </button>
                      ))}
                      {payeesQ.isLoading && <div className="h-12 animate-pulse rounded-lg bg-slate-50" />}
                      {!addPayee ? (
                        <button
                          onClick={() => setAddPayee(true)}
                          className="flex items-center gap-1.5 text-sm font-medium text-navy hover:underline"
                        >
                          <Plus className="h-4 w-4" /> Add new payee
                        </button>
                      ) : (
                        <div className="space-y-2 rounded-lg border border-dashed border-slate-300 p-3">
                          <div className="flex justify-between">
                            <p className="text-xs font-semibold text-navy">New payee</p>
                            <button onClick={() => setAddPayee(false)} className="text-slate-400">
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                          <input placeholder="Full name" className="h-9 w-full rounded-lg border border-slate-200 px-3 text-sm outline-none focus:border-navy" />
                          <input placeholder="Email or phone (Zelle) or account number" className="h-9 w-full rounded-lg border border-slate-200 px-3 text-sm outline-none focus:border-navy" />
                          <input placeholder="Nickname (optional)" className="h-9 w-full rounded-lg border border-slate-200 px-3 text-sm outline-none focus:border-navy" />
                          <button
                            onClick={() => {
                              setAddPayee(false);
                              toast.success("Payee added", { description: "Verification may take up to 1 business day." });
                            }}
                            className="rounded-lg bg-navy px-3 py-1.5 text-xs font-semibold text-white"
                          >
                            Save payee
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <label className="text-xs font-medium uppercase tracking-[0.06em] text-slate-500">Amount</label>
                    {from && (
                      <button
                        onClick={() => setAmount(num(from.balance).toFixed(2))}
                        className="text-xs font-medium text-navy hover:underline"
                      >
                        Send max
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl text-slate-400">$</span>
                    <input
                      value={amount}
                      onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
                      placeholder="0.00"
                      inputMode="decimal"
                      className={cn(
                        "h-16 w-full rounded-lg border bg-white pl-10 pr-4 text-4xl font-semibold tabular-nums text-navy outline-none transition",
                        overBalance
                          ? "animate-pulse border-[#B42318]"
                          : "border-slate-300 focus:border-navy"
                      )}
                    />
                  </div>
                  {overBalance && (
                    <p className="mt-1.5 text-xs font-medium text-[#B42318]">Amount exceeds available balance</p>
                  )}
                  <div className="mt-2 flex gap-2">
                    {[50, 100, 500].map((v) => (
                      <button
                        key={v}
                        onClick={() => setAmount(String(v))}
                        className="rounded-full border border-slate-200 px-3 py-1 text-xs font-medium text-navy transition hover:border-gold hover:bg-amber-50"
                      >
                        ${v}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">
                    When
                  </label>
                  <div className="flex flex-wrap gap-4 text-sm">
                    {(
                      [
                        ["now", "Now"],
                        ["later", "Schedule for later"],
                        ["recurring", "Make it recurring"],
                      ] as const
                    ).map(([v, label]) => (
                      <label key={v} className="flex items-center gap-2 text-body">
                        <input
                          type="radio"
                          name="timing"
                          checked={timing === v}
                          onChange={() => setTiming(v)}
                          className="accent-[#0B2545]"
                        />
                        {label}
                      </label>
                    ))}
                  </div>
                  {timing === "later" && (
                    <input
                      type="date"
                      value={schedDate}
                      min="2025-02-14"
                      onChange={(e) => setSchedDate(e.target.value)}
                      className="mt-2 h-10 rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-navy"
                    />
                  )}
                  {timing === "recurring" && (
                    <select
                      value={freq}
                      onChange={(e) => setFreq(e.target.value)}
                      className="mt-2 h-10 rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-navy"
                    >
                      <option value="weekly">Weekly</option>
                      <option value="monthly">Monthly</option>
                    </select>
                  )}
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">
                    Memo <span className="normal-case text-slate-400">(optional, {80 - memo.length} left)</span>
                  </label>
                  <input
                    value={memo}
                    maxLength={80}
                    onChange={(e) => setMemo(e.target.value)}
                    placeholder="What's this for?"
                    className="h-11 w-full rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-navy"
                  />
                </div>

                <button
                  disabled={!valid}
                  onClick={() => setStep(1)}
                  className="flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-gold font-semibold text-navy transition hover:bg-gold-hover disabled:cursor-not-allowed disabled:opacity-40"
                >
                  Continue <ArrowRight className="h-4 w-4" />
                </button>
              </motion.div>
            )}

            {/* STEP 2 — review */}
            {step === 1 && (
              <motion.div
                key="s2"
                initial={{ opacity: 0, x: 24 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -24 }}
                transition={{ duration: 0.25 }}
                className="p-6"
              >
                <h2 className="font-display text-lg font-semibold text-navy">Review your transfer</h2>
                <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50/60 p-5">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-[11px] uppercase tracking-[0.06em] text-slate-500">From</p>
                      <p className="mt-0.5 font-medium text-navy">
                        {from?.nickname} •••• {from?.last4}
                      </p>
                    </div>
                    <ArrowRight className="h-5 w-5 text-gold" />
                    <div className="text-right">
                      <p className="text-[11px] uppercase tracking-[0.06em] text-slate-500">To</p>
                      <p className="mt-0.5 font-medium text-navy">{toLabel}</p>
                    </div>
                  </div>
                  <p className="mt-5 text-center font-display text-4xl font-bold tabular-nums text-navy">
                    {fmtMoney(amt)}
                  </p>
                  <dl className="mt-5 space-y-2 border-t border-slate-200 pt-4 text-sm">
                    <div className="flex justify-between">
                      <dt className="text-subtle">Date</dt>
                      <dd className="text-body">
                        {timing === "now"
                          ? "Immediately (Feb 14, 2025)"
                          : timing === "later"
                            ? `Scheduled: ${schedDate || "Feb 14, 2025"}`
                            : `Recurring ${freq}, starting Feb 14, 2025`}
                      </dd>
                    </div>
                    {memo && (
                      <div className="flex justify-between">
                        <dt className="text-subtle">Memo</dt>
                        <dd className="text-body">{memo}</dd>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <dt className="text-subtle">Fee</dt>
                      <dd className="tabular-nums text-body">$0.00</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-subtle">Estimated arrival</dt>
                      <dd className="text-body">Within minutes</dd>
                    </div>
                  </dl>
                </div>
                <p className="mt-4 text-[11px] leading-relaxed text-slate-400">
                  By confirming, you authorize Meridian Bank to debit the source account for the amount shown.
                  Transfers to external payees are final once processed and may not be reversible. This is a
                  fictional demo — no real money moves.
                </p>
                <div className="mt-5 flex gap-3">
                  <button
                    onClick={() => setStep(0)}
                    className="flex h-11 flex-1 items-center justify-center gap-2 rounded-lg border border-slate-300 font-medium text-navy transition hover:border-navy"
                  >
                    <ArrowLeft className="h-4 w-4" /> Edit
                  </button>
                  <button
                    onClick={() => setConfirmOpen(true)}
                    className="h-11 flex-1 rounded-lg bg-gold font-semibold text-navy transition hover:bg-gold-hover"
                  >
                    Confirm transfer
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 3 — confirmation */}
            {step === 2 && receipt && (
              <motion.div key="s3" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-8 text-center">
                <motion.div
                  initial={{ scale: 0.5 }}
                  animate={{ scale: [0.5, 1.1, 1] }}
                  transition={{ duration: 0.5 }}
                  className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50"
                >
                  <CheckCircle2 className="h-9 w-9 text-money" />
                </motion.div>
                <h2 className="mt-4 font-display text-2xl font-bold text-navy">Transfer complete</h2>
                <p className="mt-1 text-sm text-subtle">
                  {fmtMoney(receipt.amount)} sent to {toLabel}
                </p>
                <div className="mx-auto mt-5 max-w-sm rounded-xl border border-slate-200 bg-slate-50/60 p-4 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-subtle">Confirmation #</span>
                    <span className="flex items-center gap-1.5 font-mono text-body">
                      {confNo}
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(confNo).catch(() => {});
                          setCopied(true);
                          setTimeout(() => setCopied(false), 1500);
                        }}
                        className="text-slate-400 hover:text-navy"
                      >
                        {copied ? <Check className="h-3.5 w-3.5 text-money" /> : <Copy className="h-3.5 w-3.5" />}
                      </button>
                    </span>
                  </div>
                  <div className="mt-2 flex justify-between">
                    <span className="text-subtle">New {from?.nickname} balance</span>
                    <span className="font-medium tabular-nums text-navy">{fmtMoney(receipt.fromBal)}</span>
                  </div>
                </div>
                <div className="mt-6 flex flex-wrap justify-center gap-3">
                  <button
                    onClick={() => {
                      setStep(0);
                      setReceipt(null);
                      setAmount("");
                      setMemo("");
                    }}
                    className="rounded-lg bg-navy px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-navy-deep"
                  >
                    Make another transfer
                  </button>
                  <Link
                    to="/banking"
                    className="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-semibold text-navy transition hover:border-navy"
                  >
                    View activity
                  </Link>
                  <button
                    onClick={() => toast.success("Receipt downloaded")}
                    className="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-semibold text-navy transition hover:border-navy"
                  >
                    Download receipt (PDF)
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Side rail */}
        <div className="w-full space-y-4 lg:w-[320px] lg:shrink-0">
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="font-display text-[15px] font-semibold text-navy">Transfer activity</h3>
            <ul className="mt-3 space-y-3 text-sm">
              {[
                ["Feb 12", "To Marcus Chen", "$120.00", "Completed", "text-money"],
                ["Feb 08", "To Savings ••••9034", "$500.00", "Completed", "text-money"],
                ["Jan 30", "To Con Edison", "$142.87", "Completed", "text-money"],
                ["Jan 15", "To Savings ••••9034", "$500.00", "Failed — insufficient funds", "text-[#B42318]"],
              ].map(([d, to, amt2, st, cls]) => (
                <li key={d + to} className="flex items-start justify-between gap-2 border-b border-slate-50 pb-2.5 last:border-0">
                  <div>
                    <p className="font-medium text-body">{to}</p>
                    <p className="text-xs text-subtle">{d}</p>
                  </div>
                  <div className="text-right">
                    <p className="tabular-nums text-body">{amt2}</p>
                    <p className={cn("text-xs", cls)}>{st}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="font-display text-[15px] font-semibold text-navy">Transfer limits</h3>
            <div className="mt-3 space-y-3 text-sm">
              <div>
                <div className="flex justify-between text-xs">
                  <span className="text-subtle">Daily Zelle limit</span>
                  <span className="tabular-nums text-body">$2,380 of $2,500 remaining</span>
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full w-[4.8%] rounded-full bg-gold" />
                </div>
              </div>
              <p className="text-xs text-subtle">External transfer limit $10,000/day</p>
            </div>
          </div>
        </div>
      </div>

      {/* Confirm dialog */}
      <AnimatePresence>
        {confirmOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-navy-deep/50 p-4"
            onClick={() => setConfirmOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.96, y: 12 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.97, y: 8 }}
              className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="font-display text-lg font-semibold text-navy">
                Send {fmtMoney(amt)} to {toLabel}?
              </h3>
              <p className="mt-1.5 text-sm text-subtle">
                Funds will leave {from?.nickname} •••• {from?.last4} immediately.
              </p>
              <div className="mt-5 flex gap-3">
                <button
                  onClick={() => setConfirmOpen(false)}
                  className="h-10 flex-1 rounded-lg border border-slate-300 text-sm font-medium text-navy"
                >
                  Cancel
                </button>
                <button
                  onClick={submit}
                  disabled={transfer.isPending}
                  className="h-10 flex-1 rounded-lg bg-gold text-sm font-semibold text-navy transition hover:bg-gold-hover disabled:opacity-60"
                >
                  {transfer.isPending ? "Sending…" : "Confirm"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </BankingLayout>
  );
}
