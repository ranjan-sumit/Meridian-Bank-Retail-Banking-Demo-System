import { useMemo, useState } from "react";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { toast, Toaster } from "sonner";
import {
  ShieldCheck, FileText, ZoomIn, ZoomOut, CheckCircle2, XCircle,
  AlertTriangle, Clock, UserCheck, MessageSquarePlus,
} from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useSession } from "@/hooks/useSession";
import DataTable, { type Column } from "@/components/shared/DataTable";
import StatusBadge from "@/components/shared/StatusBadge";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from "@/components/ui/sheet";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

type KycRow = {
  id: number;
  caseNo: string;
  level: "standard" | "enhanced";
  status: "pending" | "under_review" | "approved" | "rejected";
  idDocType: string;
  riskRating: "low" | "medium" | "high";
  submittedAt: Date;
  reviewedBy: string | null;
  reviewedAt: Date | null;
  rejectionReason: string | null;
  customer: {
    id: number;
    customerNo: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    dob: string;
    address: string;
    ssnLast4: string;
    kycStatus: string;
  };
};

const RISK_SCORE: Record<string, number> = { low: 18, medium: 41, high: 71 };
const REJECT_REASONS = ["Document illegible", "Address mismatch", "Sanctions concern", "Other"];

function priorityOf(r: KycRow) {
  return r.riskRating === "high" ? "HIGH" : r.riskRating === "medium" ? "MEDIUM" : "LOW";
}

function StatChip({ label, value, tone = "default" }: { label: string; value: string | number; tone?: "default" | "red" | "amber" }) {
  return (
    <div className="flex items-center gap-2 rounded-lg border border-staff-border bg-staff-panel px-3 py-1.5">
      <span className={cn(
        "font-mono text-sm font-medium tabular-nums",
        tone === "red" ? "text-red-400" : tone === "amber" ? "text-amber-300" : "text-[#2DD4A8]"
      )}>
        {value}
      </span>
      <span className="text-xs text-staff-subtle">{label}</span>
    </div>
  );
}

export default function StaffKyc() {
  const { role } = useSession();
  const utils = trpc.useUtils();
  const [tab, setTab] = useState<"queue" | "approved" | "rejected">("queue");
  const statusArg = tab === "queue" ? undefined : tab;
  const queueQuery = trpc.staff.kycQueue.useQuery(
    statusArg ? { status: statusArg } : {},
    { refetchInterval: 60_000 }
  );
  const countsQuery = trpc.staff.kycQueue.useQuery({});
  const [selected, setSelected] = useState<KycRow | null>(null);
  const [docPreview, setDocPreview] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [rejectNote, setRejectNote] = useState("");
  const [infoOpen, setInfoOpen] = useState(false);
  const [infoNote, setInfoNote] = useState("");
  const [confirmApprove, setConfirmApprove] = useState(false);

  const review = trpc.staff.reviewKyc.useMutation({
    onSuccess: (_d, vars) => {
      toast.success(vars.approve ? `KYC case ${selected?.caseNo} approved` : `KYC case ${selected?.caseNo} rejected`);
      void utils.staff.kycQueue.invalidate();
      setConfirmApprove(false);
      setRejectOpen(false);
      setSelected(null);
    },
    onError: (e) => toast.error(e.message),
  });

  const rows = (queueQuery.data ?? []) as KycRow[];
  const queueAll = (countsQuery.data ?? []) as KycRow[];
  const pendingCount = queueAll.filter((r) => r.status === "pending").length;
  const underReview = queueAll.filter((r) => r.status === "under_review").length;
  const highPriority = queueAll.filter((r) => r.riskRating === "high").length;

  const columns: Column<KycRow>[] = useMemo(() => [
    {
      key: "case", header: "Case ID",
      render: (r) => <span className="font-mono text-[12.5px] text-[#2DD4A8]">{r.caseNo}</span>,
      sortValue: (r) => r.caseNo,
    },
    {
      key: "customer", header: "Customer",
      render: (r) => (
        <div>
          <div className="font-medium text-staff-text">{r.customer.firstName} {r.customer.lastName}</div>
          <div className="font-mono text-[11px] text-staff-subtle">{r.customer.customerNo}</div>
        </div>
      ),
      sortValue: (r) => r.customer.lastName,
    },
    {
      key: "type", header: "Type",
      render: (r) => (
        <span className={cn("text-[12.5px]", r.level === "enhanced" ? "text-amber-300" : "text-staff-subtle")}>
          {r.level === "enhanced" ? "Enhanced Due Diligence" : "Standard"}
        </span>
      ),
    },
    {
      key: "submitted", header: "Submitted",
      render: (r) => <span className="tabular-nums text-staff-subtle">{format(new Date(r.submittedAt), "MMM d")}</span>,
      sortValue: (r) => new Date(r.submittedAt).getTime(),
    },
    {
      key: "docs", header: "Docs",
      render: (r) => (
        <span className={cn("font-mono text-[12px] tabular-nums", r.level === "enhanced" ? "text-staff-text" : "text-staff-subtle")}>
          {r.level === "enhanced" ? "4/4" : "2/2"}
        </span>
      ),
    },
    {
      key: "risk", header: "Risk score",
      render: (r) => {
        const score = RISK_SCORE[r.riskRating];
        return (
          <span className={cn("font-mono text-[12.5px] tabular-nums", score >= 60 ? "text-red-400" : score >= 35 ? "text-amber-300" : "text-emerald-300")}>
            {score}/100
          </span>
        );
      },
      sortValue: (r) => RISK_SCORE[r.riskRating],
    },
    {
      key: "priority", header: "Priority",
      render: (r) => (
        <span className={cn(
          "rounded-full px-2 py-0.5 text-[11px] font-semibold",
          r.riskRating === "high" && "bg-red-500/15 text-red-300",
          r.riskRating === "medium" && "bg-amber-500/15 text-amber-300",
          r.riskRating === "low" && "bg-slate-500/20 text-slate-300",
        )}>
          {priorityOf(r)}
        </span>
      ),
    },
    {
      key: "assignee", header: tab === "queue" ? "Assignee" : "Decided by",
      render: (r) => <span className="text-staff-subtle">{r.reviewedBy ?? "Unassigned"}</span>,
    },
    ...(tab !== "queue" ? [{
      key: "decision", header: "Decision",
      render: (r: KycRow) => (
        <div className="max-w-[220px]">
          <StatusBadge dark status={r.status === "approved" ? "Approved" : "Rejected"} />
          {r.rejectionReason && <div className="mt-0.5 truncate text-[11px] text-staff-subtle">{r.rejectionReason}</div>}
        </div>
      ),
    } satisfies Column<KycRow>] : []),
    {
      key: "actions", header: "",
      render: (r) => (
        <button
          onClick={(e) => { e.stopPropagation(); setSelected(r); }}
          className="rounded-md border border-[#2DD4A8]/40 px-3 py-1 text-xs font-medium text-[#2DD4A8] transition hover:bg-[#2DD4A8]/10"
        >
          Review
        </button>
      ),
    },
  ], [tab]);

  const isEdd = selected?.level === "enhanced";
  const canDecide = !isEdd || role === "manager" || role === "admin";

  return (
    <div className="space-y-5">
      <Toaster position="top-right" theme="dark" richColors />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-semibold text-staff-text">KYC Review</h1>
          <p className="text-xs text-staff-subtle">Identity verification queue · today is Feb 14, 2025</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <StatChip label="Pending" value={pendingCount} />
          <StatChip label="High priority" value={highPriority} tone="red" />
          <StatChip label="Under Review" value={underReview} tone="amber" />
          <StatChip label="Avg. review time" value="1.4 days" />
        </div>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList className="border border-staff-border bg-staff-panel">
          <TabsTrigger value="queue">Queue</TabsTrigger>
          <TabsTrigger value="approved">Approved (recent)</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
        </TabsList>
      </Tabs>

      {queueQuery.isLoading ? (
        <div className="space-y-2 rounded-xl border border-staff-border bg-staff-panel p-4">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-11 w-full bg-staff-raised" />)}
        </div>
      ) : queueQuery.isError ? (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-6 text-sm text-red-300">
          Failed to load KYC queue: {queueQuery.error.message}
        </div>
      ) : (
        <DataTable
          dark
          columns={columns}
          data={rows}
          pageSize={10}
          rowKey={(r) => r.caseNo}
          onRowClick={setSelected}
          emptyMessage={tab === "queue" ? "Queue is clear — no cases awaiting review." : "No cases found."}
        />
      )}

      {/* Review drawer */}
      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <SheetContent
          side="right"
          className="w-full overflow-y-auto border-l border-staff-border bg-staff-panel p-0 text-staff-text sm:max-w-[640px]"
        >
          {selected && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex min-h-full flex-col">
              <SheetHeader className="border-b border-staff-border px-5 py-4">
                <div className="flex items-center gap-3">
                  <SheetTitle className="font-mono text-base text-[#2DD4A8]">{selected.caseNo}</SheetTitle>
                  <StatusBadge dark status={selected.status === "under_review" ? "Under Review" : selected.status === "pending" ? "Pending" : selected.status === "approved" ? "Approved" : "Rejected"} />
                  {isEdd && <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[11px] font-semibold text-amber-300">EDD</span>}
                </div>
                <SheetDescription className="text-staff-subtle">
                  {selected.customer.firstName} {selected.customer.lastName} · submitted {format(new Date(selected.submittedAt), "MMM d, yyyy")}
                </SheetDescription>
              </SheetHeader>

              <div className="grid flex-1 gap-0 md:grid-cols-2">
                {/* Applicant data */}
                <div className="space-y-3 border-b border-staff-border p-5 md:border-b-0 md:border-r">
                  <h3 className="text-[11px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">Applicant</h3>
                  {[
                    ["Full name", `${selected.customer.firstName} ${selected.customer.lastName}`],
                    ["Customer no.", selected.customer.customerNo],
                    ["Date of birth", selected.customer.dob],
                    ["SSN", `•••-••-${selected.customer.ssnLast4}`],
                    ["Address", selected.customer.address],
                    ["Email", selected.customer.email],
                    ["Phone", selected.customer.phone],
                    ["ID document", selected.idDocType],
                    ["Expected monthly activity", "$8,000 – $15,000"],
                    ["Source of funds", "Employment income"],
                  ].map(([k, v]) => (
                    <div key={k} className="flex items-start justify-between gap-3 text-[12.5px]">
                      <span className="text-staff-subtle">{k}</span>
                      <span className="text-right font-medium text-staff-text">{v}</span>
                    </div>
                  ))}
                  {/* Checklist */}
                  <h3 className="pt-2 text-[11px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">Verification checklist</h3>
                  <div className="space-y-2">
                    {[
                      { label: "Identity document valid", ok: true, note: "auto · 94% confidence" },
                      { label: "Address match", ok: true, note: "utility bill vs. application" },
                      { label: "Sanctions screening", ok: true, note: "No matches — OFAC/EU lists" },
                      { label: "PEP check", ok: true, note: "auto: clear" },
                    ].map((c, i) => (
                      <motion.div
                        key={c.label}
                        initial={{ opacity: 0, x: -6 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.1 * i }}
                        className="flex items-center gap-2 rounded-lg border border-staff-border bg-staff-raised px-3 py-2"
                      >
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                        <div>
                          <div className="text-[12.5px] text-staff-text">{c.label}</div>
                          <div className="text-[11px] text-staff-subtle">{c.note}</div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Document viewer */}
                <div className="space-y-3 p-5">
                  <h3 className="text-[11px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">Documents</h3>
                  {[
                    { src: "/doc-id-sample.jpg", label: "Government ID", chip: "ID verified · auto, 94% confidence", chipTone: "text-emerald-300 bg-emerald-500/15" },
                    { src: "/doc-proof-address.jpg", label: "Proof of address", chip: "Manual check needed", chipTone: "text-amber-300 bg-amber-500/15" },
                  ].map((d) => (
                    <div key={d.src} className="rounded-lg border border-staff-border bg-staff-raised p-3">
                      <button
                        className="group block w-full overflow-hidden rounded-md"
                        onClick={() => { setDocPreview(d.src); setZoom(1); }}
                      >
                        <motion.img
                          src={d.src}
                          alt={d.label}
                          className="h-28 w-full object-cover"
                          whileHover={{ scale: 1.05 }}
                          transition={{ duration: 0.2 }}
                        />
                      </button>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-[12px] text-staff-text">{d.label}</span>
                        <span className={cn("rounded-full px-2 py-0.5 text-[10.5px] font-medium", d.chipTone)}>{d.chip}</span>
                      </div>
                    </div>
                  ))}
                  {isEdd && (
                    <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-[12px] text-amber-200">
                      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                      <div>
                        <div className="font-semibold">Maker-checker applies</div>
                        Enhanced due diligence cases require a second approver. Only managers and admins can finalize this case.
                        {role === "teller" && <span className="mt-1 block font-medium text-amber-300">Your role (teller) cannot decide EDD cases.</span>}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Decision bar */}
              {(selected.status === "pending" || selected.status === "under_review") && (
                <div className="sticky bottom-0 flex items-center gap-2 border-t border-staff-border bg-staff-panel/95 px-5 py-3 backdrop-blur">
                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    disabled={!canDecide || review.isPending}
                    onClick={() => setConfirmApprove(true)}
                    className="flex-1 rounded-lg bg-[#2DD4A8] px-4 py-2 text-sm font-semibold text-[#0B1118] transition hover:bg-[#2DD4A8]/90 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    Approve
                  </motion.button>
                  <button
                    onClick={() => setInfoOpen(true)}
                    className="flex items-center gap-1.5 rounded-lg border border-blue-400/40 px-4 py-2 text-sm font-medium text-blue-300 transition hover:bg-blue-400/10"
                  >
                    <MessageSquarePlus className="h-4 w-4" /> Request info
                  </button>
                  <button
                    disabled={review.isPending}
                    onClick={() => setRejectOpen(true)}
                    className="rounded-lg border border-red-500/40 px-4 py-2 text-sm font-medium text-red-300 transition hover:bg-red-500/10"
                  >
                    Reject
                  </button>
                </div>
              )}
              {selected.rejectionReason && (
                <div className="border-t border-staff-border px-5 py-3 text-[12.5px] text-red-300">
                  Rejection reason: {selected.rejectionReason}
                </div>
              )}
            </motion.div>
          )}
        </SheetContent>
      </Sheet>

      {/* Doc preview dialog */}
      <Dialog open={!!docPreview} onOpenChange={(o) => !o && setDocPreview(null)}>
        <DialogContent className="max-w-2xl border-staff-border bg-staff-panel text-staff-text">
          <DialogHeader>
            <DialogTitle className="text-sm">Document preview</DialogTitle>
            <DialogDescription className="text-staff-subtle">SPECIMEN — demo documents are deliberately redacted.</DialogDescription>
          </DialogHeader>
          <div className="flex items-center gap-2">
            <button onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))} className="rounded-md border border-staff-border p-1.5 text-staff-subtle hover:text-staff-text"><ZoomOut className="h-4 w-4" /></button>
            <span className="font-mono text-xs tabular-nums text-staff-subtle">{Math.round(zoom * 100)}%</span>
            <button onClick={() => setZoom((z) => Math.min(3, z + 0.25))} className="rounded-md border border-staff-border p-1.5 text-staff-subtle hover:text-staff-text"><ZoomIn className="h-4 w-4" /></button>
          </div>
          <div className="max-h-[60vh] overflow-auto rounded-lg border border-staff-border bg-staff-canvas">
            {docPreview && (
              <img src={docPreview} alt="Document preview" style={{ transform: `scale(${zoom})`, transformOrigin: "top left" }} className="w-full transition-transform" />
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Approve confirm */}
      <Dialog open={confirmApprove} onOpenChange={setConfirmApprove}>
        <DialogContent className="border-staff-border bg-staff-panel text-staff-text">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base"><ShieldCheck className="h-5 w-5 text-[#2DD4A8]" /> Approve {selected?.caseNo}?</DialogTitle>
            <DialogDescription className="text-staff-subtle">
              The customer will be marked KYC verified and an audit entry will be written.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <button onClick={() => setConfirmApprove(false)} className="rounded-lg border border-staff-border px-4 py-2 text-sm text-staff-subtle hover:text-staff-text">Cancel</button>
            <button
              disabled={review.isPending}
              onClick={() => selected && review.mutate({ caseId: selected.id, approve: true })}
              className="rounded-lg bg-[#2DD4A8] px-4 py-2 text-sm font-semibold text-[#0B1118] disabled:opacity-50"
            >
              {review.isPending ? "Approving…" : "Confirm approval"}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject dialog */}
      <Dialog open={rejectOpen} onOpenChange={setRejectOpen}>
        <DialogContent className="border-staff-border bg-staff-panel text-staff-text">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base"><XCircle className="h-5 w-5 text-red-400" /> Reject {selected?.caseNo}</DialogTitle>
            <DialogDescription className="text-staff-subtle">A reason is required and will be shared with the customer.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Select value={rejectReason} onValueChange={setRejectReason}>
              <SelectTrigger className="border-staff-border bg-staff-raised text-staff-text">
                <SelectValue placeholder="Select reason" />
              </SelectTrigger>
              <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
                {REJECT_REASONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
              </SelectContent>
            </Select>
            <textarea
              value={rejectNote}
              onChange={(e) => setRejectNote(e.target.value)}
              placeholder="Optional note for the audit trail…"
              rows={3}
              className="w-full rounded-lg border border-staff-border bg-staff-raised px-3 py-2 text-sm text-staff-text placeholder:text-staff-subtle focus:outline-none focus:ring-1 focus:ring-[#2DD4A8]"
            />
          </div>
          <DialogFooter className="gap-2">
            <button onClick={() => setRejectOpen(false)} className="rounded-lg border border-staff-border px-4 py-2 text-sm text-staff-subtle hover:text-staff-text">Cancel</button>
            <button
              disabled={!rejectReason || review.isPending}
              onClick={() => selected && review.mutate({ caseId: selected.id, approve: false, reason: rejectNote ? `${rejectReason}: ${rejectNote}` : rejectReason })}
              className="rounded-lg bg-red-500 px-4 py-2 text-sm font-semibold text-white disabled:opacity-40"
            >
              {review.isPending ? "Rejecting…" : "Confirm rejection"}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Request info dialog (local only — records intent) */}
      <Dialog open={infoOpen} onOpenChange={setInfoOpen}>
        <DialogContent className="border-staff-border bg-staff-panel text-staff-text">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base"><FileText className="h-5 w-5 text-blue-300" /> Request more information</DialogTitle>
            <DialogDescription className="text-staff-subtle">The customer will be notified to supply additional documents.</DialogDescription>
          </DialogHeader>
          <textarea
            value={infoNote}
            onChange={(e) => setInfoNote(e.target.value)}
            placeholder="Describe what is needed (e.g. clearer proof of address)…"
            rows={3}
            className="w-full rounded-lg border border-staff-border bg-staff-raised px-3 py-2 text-sm text-staff-text placeholder:text-staff-subtle focus:outline-none focus:ring-1 focus:ring-blue-400"
          />
          <DialogFooter className="gap-2">
            <button onClick={() => setInfoOpen(false)} className="rounded-lg border border-staff-border px-4 py-2 text-sm text-staff-subtle hover:text-staff-text">Cancel</button>
            <button
              disabled={!infoNote}
              onClick={() => { toast.info(`Information request sent for ${selected?.caseNo}`); setInfoOpen(false); setInfoNote(""); }}
              className="rounded-lg bg-blue-500 px-4 py-2 text-sm font-semibold text-white disabled:opacity-40"
            >
              Send request
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* subtle footer meta */}
      <div className="flex items-center gap-2 text-[11px] text-staff-subtle">
        <Clock className="h-3.5 w-3.5" /> SLA: standard 2 business days · EDD 5 business days
        <UserCheck className="ml-3 h-3.5 w-3.5" /> Signed in as {role ?? "staff"}
      </div>
    </div>
  );
}
