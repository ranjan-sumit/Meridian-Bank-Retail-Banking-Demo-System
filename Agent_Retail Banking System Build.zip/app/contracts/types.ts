export * from "./errors";

/** Shared domain constants for Meridian Bank (frontend + backend). */

export const ROLES = ["customer", "teller", "manager", "admin"] as const;
export type Role = (typeof ROLES)[number];
export const STAFF_ROLES: Role[] = ["teller", "manager", "admin"];

export const ACCOUNT_TYPES = ["checking", "savings", "credit", "mortgage"] as const;
export type AccountType = (typeof ACCOUNT_TYPES)[number];

export const ACCOUNT_STATUSES = ["active", "frozen", "closed"] as const;
export type AccountStatus = (typeof ACCOUNT_STATUSES)[number];

export const TXN_TYPES = ["transfer", "deposit", "withdrawal", "fee", "interest", "payment", "purchase"] as const;
export type TxnType = (typeof TXN_TYPES)[number];

export const TXN_STATUSES = ["posted", "pending", "flagged"] as const;
export type TxnStatus = (typeof TXN_STATUSES)[number];

export const CARD_STATUSES = ["active", "frozen", "blocked", "pending"] as const;
export type CardStatus = (typeof CARD_STATUSES)[number];

export const LOAN_STATUSES = ["pending", "approved", "rejected", "active", "delinquent", "paid_off"] as const;
export type LoanStatus = (typeof LOAN_STATUSES)[number];

export const KYC_STATUSES = ["pending", "under_review", "approved", "rejected"] as const;
export type KycStatus = (typeof KYC_STATUSES)[number];

export const CUSTOMER_KYC_STATUSES = ["verified", "pending", "under_review", "rejected"] as const;

export const ALERT_TYPES = ["structuring", "high_velocity", "unusual_amount", "geo_anomaly"] as const;
export type AlertType = (typeof ALERT_TYPES)[number];
export const ALERT_SEVERITIES = ["low", "medium", "high", "critical"] as const;
export type AlertSeverity = (typeof ALERT_SEVERITIES)[number];
export const ALERT_STATUSES = ["open", "investigating", "resolved", "dismissed"] as const;
export type AlertStatus = (typeof ALERT_STATUSES)[number];

export type SessionUser = {
  id: number;
  username: string;
  name: string;
  role: Role;
  customerId: number | null;
};

export const SESSION_STORAGE_KEY = "meridian_session";
