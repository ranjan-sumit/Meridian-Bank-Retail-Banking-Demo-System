import { z } from "zod";
import { and, desc, eq, gte, lte, like, or, count } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, customerProcedure } from "./middleware";
import { getDb } from "./queries/connection";
import {
  accounts,
  transactions,
  cards,
  loans,
  loanPayments,
  loanProducts,
  payees,
  notifications,
  customers,
} from "@db/schema";
import { appendAudit } from "./queries/audit";

const num = (v: string | number | null) => (v == null ? 0 : Number(v));

export const customerRouter = createRouter({
  dashboardSummary: customerProcedure.query(async ({ ctx }) => {
    const db = getDb();
    const cid = ctx.session.customerId;
    const accts = await db.select().from(accounts).where(eq(accounts.customerId, cid));
    const recent = await db
      .select()
      .from(transactions)
      .innerJoin(accounts, eq(transactions.accountId, accounts.id))
      .where(eq(accounts.customerId, cid))
      .orderBy(desc(transactions.occurredAt))
      .limit(8);
    const notifs = await db
      .select()
      .from(notifications)
      .where(eq(notifications.customerId, cid))
      .orderBy(desc(notifications.createdAt))
      .limit(10);
    const totalBalance = accts
      .filter((a) => a.type === "checking" || a.type === "savings")
      .reduce((a2, a) => a2 + num(a.balance), 0);
    return {
      accounts: accts,
      recentTransactions: recent.map((r) => ({ ...r.transactions, accountNickname: r.accounts.nickname, accountLast4: r.accounts.last4 })),
      notifications: notifs,
      unreadCount: notifs.filter((n) => !n.read).length,
      totalBalance,
    };
  }),

  listAccounts: customerProcedure.query(async ({ ctx }) => {
    return getDb().select().from(accounts).where(eq(accounts.customerId, ctx.session.customerId));
  }),

  accountDetail: customerProcedure
    .input(
      z.object({
        id: z.number(),
        page: z.number().min(1).default(1),
        pageSize: z.number().min(5).max(50).default(10),
        search: z.string().optional(),
        type: z.string().optional(),
        direction: z.enum(["dr", "cr"]).optional(),
        from: z.coerce.date().optional(),
        to: z.coerce.date().optional(),
      }),
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const [acct] = await db.select().from(accounts).where(eq(accounts.id, input.id)).limit(1);
      if (!acct || acct.customerId !== ctx.session.customerId) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Account not found" });
      }
      const conds = [eq(transactions.accountId, acct.id)];
      if (input.search) {
        const q = `%${input.search}%`;
        conds.push(or(like(transactions.description, q), like(transactions.merchant, q))!);
      }
      if (input.type) conds.push(eq(transactions.type, input.type as never));
      if (input.direction) conds.push(eq(transactions.direction, input.direction));
      if (input.from) conds.push(gte(transactions.occurredAt, input.from));
      if (input.to) conds.push(lte(transactions.occurredAt, input.to));
      const where = and(...conds);
      const [{ total }] = await db.select({ total: count() }).from(transactions).where(where);
      const rows = await db
        .select()
        .from(transactions)
        .where(where)
        .orderBy(desc(transactions.occurredAt))
        .limit(input.pageSize)
        .offset((input.page - 1) * input.pageSize);
      // running balance: compute from all txns (cheap at demo scale)
      const all = await db
        .select({ amount: transactions.amount, direction: transactions.direction, occurredAt: transactions.occurredAt, id: transactions.id })
        .from(transactions)
        .where(eq(transactions.accountId, acct.id))
        .orderBy(transactions.occurredAt, transactions.id);
      let bal = 0;
      const balAfter = new Map<number, number>();
      for (const t of all) {
        bal += t.direction === "cr" ? num(t.amount) : -num(t.amount);
        balAfter.set(t.id, Math.round(bal * 100) / 100);
      }
      return {
        account: acct,
        transactions: rows.map((t) => ({ ...t, runningBalance: balAfter.get(t.id) ?? null })),
        total,
        page: input.page,
        pageSize: input.pageSize,
      };
    }),

  listCards: customerProcedure.query(async ({ ctx }) => {
    const db = getDb();
    return db
      .select({ card: cards, accountNickname: accounts.nickname })
      .from(cards)
      .innerJoin(accounts, eq(cards.accountId, accounts.id))
      .where(eq(cards.customerId, ctx.session.customerId));
  }),

  setCardStatus: customerProcedure
    .input(z.object({ id: z.number(), status: z.enum(["active", "frozen"]) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [card] = await db.select().from(cards).where(eq(cards.id, input.id)).limit(1);
      if (!card || card.customerId !== ctx.session.customerId) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Card not found" });
      }
      if (card.status === "blocked" || card.status === "pending") {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Card is ${card.status}; contact support` });
      }
      await db.update(cards).set({ status: input.status }).where(eq(cards.id, card.id));
      await appendAudit({
        actorType: "customer", actorName: ctx.session.name,
        action: input.status === "frozen" ? "card.frozen" : "card.unfrozen",
        entityType: "card", entityId: `card-${card.last4}`,
        detail: `Card ••••${card.last4} ${input.status} via online banking.`,
      });
      return { ok: true, status: input.status };
    }),

  listLoans: customerProcedure.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db
      .select({ loan: loans, product: loanProducts })
      .from(loans)
      .innerJoin(loanProducts, eq(loans.productId, loanProducts.id))
      .where(eq(loans.customerId, ctx.session.customerId));
    const result = [];
    for (const { loan, product } of rows) {
      const schedule = await db
        .select()
        .from(loanPayments)
        .where(eq(loanPayments.loanId, loan.id))
        .orderBy(loanPayments.dueDate);
      const nextPayment = schedule.find((p) => p.status !== "paid") ?? null;
      result.push({ ...loan, product, nextPayment, schedule });
    }
    return result;
  }),

  listLoanProducts: customerProcedure.query(() => getDb().select().from(loanProducts)),

  applyForLoan: customerProcedure
    .input(
      z.object({
        productId: z.number(),
        amount: z.number().positive(),
        termMonths: z.number().int().positive(),
        purpose: z.string().min(3).max(255),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [product] = await db.select().from(loanProducts).where(eq(loanProducts.id, input.productId)).limit(1);
      if (!product) throw new TRPCError({ code: "NOT_FOUND", message: "Unknown loan product" });
      const amt = input.amount;
      if (amt < num(product.minAmount) || amt > num(product.maxAmount)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Amount must be between ${product.minAmount} and ${product.maxAmount}` });
      }
      const r = num(product.rateApr) / 1200;
      const pmt = r > 0 ? (amt * r) / (1 - Math.pow(1 + r, -input.termMonths)) : amt / input.termMonths;
      const [cust] = await db.select().from(customers).where(eq(customers.id, ctx.session.customerId)).limit(1);
      const loanNo = `LN-2025-${String(Math.floor(100 + Math.random() * 900))}`;
      const [{ id }] = await db
        .insert(loans)
        .values({
          loanNo, customerId: ctx.session.customerId, productId: product.id,
          principal: amt.toFixed(2), remainingBalance: amt.toFixed(2), rateApr: product.rateApr,
          termMonths: input.termMonths, monthlyPayment: pmt.toFixed(2), purpose: input.purpose,
          status: "pending", branchId: cust?.branchId ?? 1,
        })
        .$returningId();
      await appendAudit({
        actorType: "customer", actorName: ctx.session.name, action: "loan.applied",
        entityType: "loan", entityId: loanNo,
        detail: `Applied for ${product.name}: $${amt.toFixed(2)} over ${input.termMonths} months.`,
      });
      return { ok: true, loanId: id, loanNo };
    }),

  listPayees: customerProcedure.query(({ ctx }) =>
    getDb().select().from(payees).where(eq(payees.customerId, ctx.session.customerId)),
  ),

  transfer: customerProcedure
    .input(
      z.object({
        fromAccountId: z.number(),
        toAccountId: z.number().optional(),
        payeeId: z.number().optional(),
        amount: z.number().positive().max(1000000),
        description: z.string().max(255).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const cid = ctx.session.customerId;
      const [from] = await db.select().from(accounts).where(eq(accounts.id, input.fromAccountId)).limit(1);
      if (!from || from.customerId !== cid) throw new TRPCError({ code: "NOT_FOUND", message: "Source account not found" });
      if (from.status !== "active") throw new TRPCError({ code: "BAD_REQUEST", message: `Source account is ${from.status}` });
      if (from.type === "mortgage") throw new TRPCError({ code: "BAD_REQUEST", message: "Cannot transfer from a mortgage account" });
      if (num(from.balance) < input.amount) throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient funds" });

      let to: typeof from | undefined;
      let toLabel = "External payee";
      if (input.toAccountId != null) {
        const [row] = await db.select().from(accounts).where(eq(accounts.id, input.toAccountId)).limit(1);
        if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "Destination account not found" });
        if (row.status !== "active") throw new TRPCError({ code: "BAD_REQUEST", message: `Destination account is ${row.status}` });
        to = row;
        toLabel = `${row.nickname} ••••${row.last4}`;
      } else if (input.payeeId != null) {
        const [payee] = await db.select().from(payees).where(eq(payees.id, input.payeeId)).limit(1);
        if (!payee || payee.customerId !== cid) throw new TRPCError({ code: "NOT_FOUND", message: "Payee not found" });
        toLabel = payee.name;
      } else {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Provide toAccountId or payeeId" });
      }

      const now = new Date();
      const day = now.toISOString().slice(0, 10).replace(/-/g, "");
      const suffix = String(Math.floor(1000 + Math.random() * 9000));
      const desc = input.description ?? `TRANSFER TO ${toLabel.toUpperCase()}`;
      const [{ id: drId }] = await db.insert(transactions).values({
        txnId: `TXN-${now.getUTCFullYear()}-${day.slice(4)}-${suffix}`,
        accountId: from.id, counterAccountId: to?.id ?? null, type: "transfer",
        amount: input.amount.toFixed(2), direction: "dr",
        description: desc, category: "Transfer", status: "posted", occurredAt: now,
        createdBy: ctx.session.name,
      }).$returningId();
      await db.update(accounts).set({ balance: (num(from.balance) - input.amount).toFixed(2) }).where(eq(accounts.id, from.id));
      if (to) {
        await db.insert(transactions).values({
          txnId: `TXN-${now.getUTCFullYear()}-${day.slice(4)}-${suffix}R`,
          accountId: to.id, counterAccountId: from.id, type: "transfer",
          amount: input.amount.toFixed(2), direction: "cr",
          description: `TRANSFER FROM ${from.nickname.toUpperCase()} ••••${from.last4}`, category: "Transfer",
          status: "posted", occurredAt: now, createdBy: ctx.session.name,
        });
        await db.update(accounts).set({ balance: (num(to.balance) + input.amount).toFixed(2) }).where(eq(accounts.id, to.id));
      }
      await appendAudit({
        actorType: "customer", actorName: ctx.session.name, action: "transfer.initiated",
        entityType: "transaction", entityId: String(drId),
        detail: `Transfer $${input.amount.toFixed(2)} from ${from.nickname} ••••${from.last4} to ${toLabel}.`,
      });
      return { ok: true, transactionId: drId };
    }),

  listNotifications: customerProcedure.query(({ ctx }) =>
    getDb().select().from(notifications).where(eq(notifications.customerId, ctx.session.customerId)).orderBy(desc(notifications.createdAt)),
  ),

  markNotificationRead: customerProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await getDb()
        .update(notifications)
        .set({ read: true })
        .where(and(eq(notifications.id, input.id), eq(notifications.customerId, ctx.session.customerId)));
      return { ok: true };
    }),

  profile: customerProcedure.query(async ({ ctx }) => {
    const [cust] = await getDb().select().from(customers).where(eq(customers.id, ctx.session.customerId)).limit(1);
    return cust ?? null;
  }),

  updateProfile: customerProcedure
    .input(
      z.object({
        phone: z.string().min(7).max(32).optional(),
        address: z.string().min(5).max(255).optional(),
        email: z.string().email().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const patch: Record<string, string> = {};
      if (input.phone) patch.phone = input.phone;
      if (input.address) patch.address = input.address;
      if (input.email) patch.email = input.email;
      if (Object.keys(patch).length === 0) throw new TRPCError({ code: "BAD_REQUEST", message: "Nothing to update" });
      await db.update(customers).set(patch).where(eq(customers.id, ctx.session.customerId));
      await appendAudit({
        actorType: "customer", actorName: ctx.session.name, action: "profile.updated",
        entityType: "customer", entityId: String(ctx.session.customerId),
        detail: `Updated fields: ${Object.keys(patch).join(", ")}.`,
      });
      return { ok: true };
    }),
});
