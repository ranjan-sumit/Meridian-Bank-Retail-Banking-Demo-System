import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import { and, eq, gt } from "drizzle-orm";
import { getDb } from "./queries/connection";
import { sessions, users } from "@db/schema";
import type { SessionUser } from "@contracts/types";

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  session: SessionUser | null;
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const token = opts.req.headers.get("x-session-token");
  let session: SessionUser | null = null;
  if (token) {
    const db = getDb();
    const rows = await db
      .select({ user: users })
      .from(sessions)
      .innerJoin(users, eq(sessions.userId, users.id))
      .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
      .limit(1);
    const row = rows[0];
    if (row) {
      session = {
        id: row.user.id,
        username: row.user.username,
        name: row.user.name,
        role: row.user.role,
        customerId: row.user.customerId,
      };
    }
  }
  return { req: opts.req, resHeaders: opts.resHeaders, session };
}
