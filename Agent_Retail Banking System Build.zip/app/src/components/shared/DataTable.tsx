import { useMemo, useState } from "react";
import type { ReactNode } from "react";
import { ArrowDown, ArrowUp, ArrowUpDown, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

export interface Column<T> {
  key: string;
  header: string;
  render: (row: T) => ReactNode;
  /** Value extractor for sorting. Omit to disable sorting on this column. */
  sortValue?: (row: T) => string | number;
  className?: string;
  headerClassName?: string;
}

/**
 * Dense data table with sortable columns and pagination.
 * Works in both front-office (light) and staff console (`dark`) themes.
 */
export default function DataTable<T extends { id?: string | number }>({
  columns,
  data,
  pageSize = 10,
  dark = false,
  rowKey,
  onRowClick,
  flagged,
  className,
  emptyMessage = "No records found.",
}: {
  columns: Column<T>[];
  data: T[];
  pageSize?: number;
  dark?: boolean;
  rowKey?: (row: T, index: number) => string | number;
  onRowClick?: (row: T) => void;
  /** Mark a row with the AML flagged highlight (red left border). */
  flagged?: (row: T) => boolean;
  className?: string;
  emptyMessage?: string;
}) {
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const [page, setPage] = useState(0);

  const sorted = useMemo(() => {
    if (!sortKey) return data;
    const col = columns.find((c) => c.key === sortKey);
    if (!col?.sortValue) return data;
    return [...data].sort((a, b) => {
      const va = col.sortValue!(a);
      const vb = col.sortValue!(b);
      const cmp = va < vb ? -1 : va > vb ? 1 : 0;
      return sortDir === "asc" ? cmp : -cmp;
    });
  }, [data, sortKey, sortDir, columns]);

  const pageCount = Math.max(1, Math.ceil(sorted.length / pageSize));
  const safePage = Math.min(page, pageCount - 1);
  const rows = sorted.slice(safePage * pageSize, safePage * pageSize + pageSize);

  const toggleSort = (key: string, sortable: boolean) => {
    if (!sortable) return;
    if (sortKey === key) setSortDir(sortDir === "asc" ? "desc" : "asc");
    else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  return (
    <div
      className={cn(
        "overflow-hidden rounded-xl border",
        dark ? "border-staff-border bg-staff-panel" : "border-slate-200 bg-white",
        className
      )}
    >
      <div className="overflow-x-auto">
        <table className={cn("w-full text-left", dark ? "text-[13px]" : "text-sm")}>
          <thead
            className={cn(
              "sticky top-0",
              dark ? "bg-staff-raised text-staff-subtle" : "bg-slate-50 text-slate-500"
            )}
          >
            <tr>
              {columns.map((c) => (
                <th
                  key={c.key}
                  onClick={() => toggleSort(c.key, !!c.sortValue)}
                  className={cn(
                    "px-4 py-3 text-[11px] font-semibold uppercase tracking-[0.06em]",
                    c.sortValue && "cursor-pointer select-none",
                    c.headerClassName
                  )}
                >
                  <span className="inline-flex items-center gap-1">
                    {c.header}
                    {c.sortValue &&
                      (sortKey === c.key ? (
                        sortDir === "asc" ? (
                          <ArrowUp className="h-3 w-3" />
                        ) : (
                          <ArrowDown className="h-3 w-3" />
                        )
                      ) : (
                        <ArrowUpDown className="h-3 w-3 opacity-40" />
                      ))}
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr>
                <td
                  colSpan={columns.length}
                  className={cn("px-4 py-10 text-center", dark ? "text-staff-subtle" : "text-slate-400")}
                >
                  {emptyMessage}
                </td>
              </tr>
            )}
            {rows.map((row, i) => {
              const isFlagged = flagged?.(row);
              return (
                <tr
                  key={rowKey ? rowKey(row, i) : row.id ?? i}
                  onClick={onRowClick ? () => onRowClick(row) : undefined}
                  className={cn(
                    "h-11 border-t transition-colors",
                    dark
                      ? cn("border-staff-border", i % 2 === 1 && "bg-staff-zebra", "hover:bg-staff-hover")
                      : "border-slate-100 hover:bg-slate-50",
                    onRowClick && "cursor-pointer",
                    isFlagged && "border-l-[3px] border-l-red-500"
                  )}
                >
                  {columns.map((c) => (
                    <td
                      key={c.key}
                      className={cn("px-4 py-2.5", dark ? "text-staff-text" : "text-body", c.className)}
                    >
                      {c.render(row)}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {/* Pagination footer */}
      <div
        className={cn(
          "flex items-center justify-between border-t px-4 py-2.5 text-xs",
          dark ? "border-staff-border text-staff-subtle" : "border-slate-100 text-slate-500"
        )}
      >
        <span className="tabular-nums">
          Showing {sorted.length === 0 ? 0 : safePage * pageSize + 1}–
          {Math.min((safePage + 1) * pageSize, sorted.length)} of {sorted.length.toLocaleString()}
        </span>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setPage(Math.max(0, safePage - 1))}
            disabled={safePage === 0}
            aria-label="Previous page"
            className="rounded p-1 transition hover:bg-black/5 disabled:opacity-30 dark:hover:bg-white/5"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="tabular-nums">
            {safePage + 1} / {pageCount}
          </span>
          <button
            onClick={() => setPage(Math.min(pageCount - 1, safePage + 1))}
            disabled={safePage >= pageCount - 1}
            aria-label="Next page"
            className="rounded p-1 transition hover:bg-black/5 disabled:opacity-30"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
