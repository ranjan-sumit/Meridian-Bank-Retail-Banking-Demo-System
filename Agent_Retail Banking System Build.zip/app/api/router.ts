import { createRouter, publicQuery } from "./middleware";
import { authRouter } from "./auth";
import { customerRouter } from "./customer";
import { staffRouter } from "./staff";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  customer: customerRouter,
  staff: staffRouter,
});

export type AppRouter = typeof appRouter;
