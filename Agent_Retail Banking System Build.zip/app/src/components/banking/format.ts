import { format, parseISO } from "date-fns";

/** Money decimals arrive as strings via superjson — coerce safely. */
export const num = (v: string | number | null | undefined): number =>
  v == null ? 0 : typeof v === "number" ? v : Number(v);

export const fmtMoney = (v: string | number | null | undefined): string =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(num(v));

export const fmtSigned = (v: number): string =>
  `${v < 0 ? "−" : "+"}${fmtMoney(Math.abs(v))}`;

export const fmtDate = (d: string | Date | null | undefined, p = "MMM d, yyyy"): string => {
  if (!d) return "—";
  const dt = typeof d === "string" ? parseISO(d) : d;
  return format(dt, p);
};

/** Signed amount from a transaction row (direction dr/cr). */
export const txnAmount = (t: { amount: string | number; direction: string }): number =>
  t.direction === "cr" ? num(t.amount) : -num(t.amount);

export const statusLabel = (s: string): string =>
  s
    .split("_")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");

export const capitalize = (s: string): string => s.charAt(0).toUpperCase() + s.slice(1);
