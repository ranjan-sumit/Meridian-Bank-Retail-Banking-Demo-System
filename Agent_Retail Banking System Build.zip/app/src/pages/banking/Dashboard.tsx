import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router";
import { motion } from "framer-motion";
import { ArrowLeftRight, Receipt, Camera, X, ArrowRight, Info, AlertTriangle, CheckCircle2 } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import BankingLayout from "@/components/banking/BankingLayout";
import AccountNumber from "@/components/shared/AccountNumber";
import MoneyText from "@/components/shared/MoneyText";
import { trpc } from "@/providers/trpc";
import { useSession } from "@/hooks/useSession";
import { fmtMoney, fmtDate, num, txnAmount } from "@/components/banking/format";

function CountUp({ value, className }: { value: number; className?: string }) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    const start = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / 1000);
      setDisplay(value * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return <span className={className}>{fmtMoney(display)}</span>;
}

const SPENDING = [
  { name: "Groceries", value: 612, color: "#0B2545" },
  { name: "Dining", value: 284, color: "#C9A227" },
  { name: "Transport", value: 190, color: "#0E7C5B" },
  { name: "Utilities", value: 143, color: "#1D4ED8" },
  { name: "Shopping", value: 311, color: "#7C3AED" },
  { name: "Other", value: 240, color: "#94A3B8" },
];

const cardAnim = (i: number) => ({
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: i * 0.08, duration: 0.4, ease: "easeOut" as const },
});

export default function Dashboard() {
  const { user } = useSession();
  const navigate = useNavigate();
  const q = trpc.customer.dashboardSummary.useQuery();
  const [dismissed, setDismissed] = useState<number[]>([]);

  const firstName = user?.name.split(" ")[0] ?? "there";
  const accounts = q.data?.accounts ?? [];
  const notifs = useMemo(
    () => (q.data?.notifications ?? []).filter((n) => !dismissed.includes(n.id)).slice(0, 3),
    [q.data, dismissed]
  );

  const checking = accounts.find((a) => a.type === "checking");
  const savings = accounts.find((a) => a.type === "savings");
  const credit = accounts.find((a) => a.type === "credit");
  const creditUsedPct = credit ? Math.round((num(credit.balance) / num(credit.creditLimit)) * 100) : 0;

  return (
    <BankingLayout>
      {/* Row 1 — greeting + quick actions */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-[28px] font-bold text-navy">
            Good morning, {firstName}
          </h1>
          <p className="mt-1 text-sm text-subtle">
            Last sign-in: Feb 12, 2025 at 9:41 AM · New York, NY
          </p>
        </div>
        <div className="flex gap-2">
          {[
            { label: "Transfer", icon: ArrowLeftRight, to: "/banking/transfers" },
            { label: "Pay a Bill", icon: Receipt, to: "/banking/transfers" },
            { label: "Deposit Check", icon: Camera, to: "/banking/transfers" },
          ].map(({ label, icon: Icon, to }) => (
            <Link
              key={label}
              to={to}
              className="flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm font-medium text-navy transition hover:-translate-y-0.5 hover:border-navy hover:shadow-md"
            >
              <Icon className="h-4 w-4" /> {label}
            </Link>
          ))}
        </div>
      </div>

      {/* Row 2 — balance cards */}
      {q.isLoading ? (
        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-40 animate-pulse rounded-xl border border-slate-200 bg-white" />
          ))}
        </div>
      ) : q.isError ? (
        <div className="mt-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-[#B42318]">
          Couldn't load your accounts. Please refresh.
        </div>
      ) : (
        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
          {checking && (
            <motion.div {...cardAnim(0)} className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-navy">{checking.nickname}</p>
                <AccountNumber last4={checking.last4} className="text-xs text-subtle" />
              </div>
              <CountUp value={num(checking.balance)} className="mt-3 block font-display text-3xl font-bold tabular-nums text-navy" />
              <p className="mt-1 text-xs text-subtle">Available balance</p>
              <div className="mt-4 flex items-end justify-between">
                <svg viewBox="0 0 120 32" className="h-8 w-28 text-money">
                  <polyline fill="none" stroke="currentColor" strokeWidth="2" points="0,24 12,20 24,22 36,16 48,18 60,12 72,14 84,8 96,10 108,5 120,7" />
                </svg>
                <Link to={`/banking/accounts/${checking.id}`} className="text-xs font-semibold text-navy hover:underline">
                  View →
                </Link>
              </div>
            </motion.div>
          )}
          {savings && (
            <motion.div {...cardAnim(1)} className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-navy">{savings.nickname}</p>
                <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-money">
                  {num(savings.apy).toFixed(2)}% APY
                </span>
              </div>
              <CountUp value={num(savings.balance)} className="mt-3 block font-display text-3xl font-bold tabular-nums text-navy" />
              <p className="mt-1 text-xs text-subtle">
                <AccountNumber last4={savings.last4} /> · +$178.42 interest YTD
              </p>
              <div className="mt-4 text-right">
                <Link to={`/banking/accounts/${savings.id}`} className="text-xs font-semibold text-navy hover:underline">
                  View →
                </Link>
              </div>
            </motion.div>
          )}
          {credit && (
            <motion.div {...cardAnim(2)} className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-navy">{credit.nickname}</p>
                <AccountNumber last4={credit.last4} className="text-xs text-subtle" />
              </div>
              <CountUp value={num(credit.balance)} className="mt-3 block font-display text-3xl font-bold tabular-nums text-navy" />
              <div className="mt-2">
                <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
                  <motion.div
                    className="h-full rounded-full bg-money"
                    initial={{ width: 0 }}
                    animate={{ width: `${creditUsedPct}%` }}
                    transition={{ duration: 0.9, ease: "easeOut", delay: 0.3 }}
                  />
                </div>
                <p className="mt-1.5 text-xs text-subtle">
                  {creditUsedPct}% of {fmtMoney(credit.creditLimit)} limit · Payment due Mar 1 — $45.00 min
                </p>
              </div>
              <div className="mt-3 text-right">
                <Link to={`/banking/accounts/${credit.id}`} className="text-xs font-semibold text-navy hover:underline">
                  View →
                </Link>
              </div>
            </motion.div>
          )}
        </div>
      )}

      {/* Row 3 — activity + side column */}
      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white shadow-sm lg:col-span-8">
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <h2 className="font-display text-[17px] font-semibold text-navy">Recent Activity</h2>
            <Link to="/banking/accounts" className="text-xs font-semibold text-navy hover:underline">
              View all activity →
            </Link>
          </div>
          {q.isLoading ? (
            <div className="space-y-2 p-5">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="h-9 animate-pulse rounded bg-slate-50" />
              ))}
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[11px] uppercase tracking-[0.06em] text-slate-500">
                  <th className="px-5 py-2.5 font-medium">Date</th>
                  <th className="px-3 py-2.5 font-medium">Description</th>
                  <th className="px-3 py-2.5 font-medium">Account</th>
                  <th className="px-5 py-2.5 text-right font-medium">Amount</th>
                </tr>
              </thead>
              <tbody>
                {(q.data?.recentTransactions ?? []).map((t, i) => (
                  <motion.tr
                    key={t.id}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 + i * 0.04 }}
                    onClick={() => navigate(`/banking/accounts/${t.accountId}`)}
                    className="cursor-pointer border-t border-slate-50 transition hover:bg-slate-50"
                  >
                    <td className="whitespace-nowrap px-5 py-3 text-subtle">{fmtDate(t.occurredAt, "MMM d")}</td>
                    <td className="px-3 py-3 font-medium text-body">{t.description}</td>
                    <td className="whitespace-nowrap px-3 py-3 text-subtle">
                      {t.accountNickname} ••••{t.accountLast4}
                    </td>
                    <td className="px-5 py-3 text-right font-medium tabular-nums">
                      <MoneyText amount={txnAmount(t)} />
                    </td>
                  </motion.tr>
                ))}
                {(q.data?.recentTransactions ?? []).length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-5 py-10 text-center text-subtle">
                      No recent activity.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>

        <div className="space-y-6 lg:col-span-4">
          {/* Alerts */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="font-display text-[17px] font-semibold text-navy">Alerts</h3>
            <div className="mt-3 space-y-2.5">
              {q.isLoading &&
                [0, 1].map((i) => <div key={i} className="h-12 animate-pulse rounded-lg bg-slate-50" />)}
              {!q.isLoading && notifs.length === 0 && (
                <p className="py-3 text-sm text-subtle">No new alerts.</p>
              )}
              {notifs.map((n) => {
                const Icon = n.type === "warning" ? AlertTriangle : n.type === "action" ? CheckCircle2 : Info;
                const tone =
                  n.type === "warning"
                    ? "border-amber-200 bg-amber-50 text-amber-800"
                    : n.type === "action"
                      ? "border-emerald-200 bg-emerald-50 text-emerald-800"
                      : "border-blue-200 bg-blue-50 text-blue-800";
                return (
                  <motion.div
                    key={n.id}
                    layout
                    exit={{ opacity: 0, height: 0 }}
                    className={`flex items-start gap-2.5 rounded-lg border p-3 text-xs ${tone}`}
                  >
                    <Icon className="mt-0.5 h-4 w-4 shrink-0" />
                    <p className="flex-1 leading-snug">{n.title}</p>
                    <button
                      onClick={() => setDismissed((d) => [...d, n.id])}
                      className="opacity-50 transition hover:opacity-100"
                      aria-label="Dismiss"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Spending snapshot */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="font-display text-[17px] font-semibold text-navy">Spending snapshot</h3>
            <div className="relative mt-2 h-44">
              <ResponsiveContainer>
                <PieChart>
                  <Pie
                    data={SPENDING}
                    dataKey="value"
                    innerRadius={52}
                    outerRadius={78}
                    paddingAngle={2}
                    strokeWidth={0}
                    isAnimationActive
                    animationDuration={800}
                  >
                    {SPENDING.map((s) => (
                      <Cell key={s.name} fill={s.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v) => fmtMoney(Number(v))} />
                </PieChart>
              </ResponsiveContainer>
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                <p className="font-display text-lg font-bold tabular-nums text-navy">$1,780</p>
                <p className="text-[11px] text-subtle">this month</p>
              </div>
            </div>
            <ul className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
              {SPENDING.map((s) => (
                <li key={s.name} className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-sm" style={{ background: s.color }} />
                  <span className="text-slate-600">{s.name}</span>
                  <span className="ml-auto tabular-nums text-body">{fmtMoney(s.value)}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Row 4 — offers strip */}
      <motion.div
        {...cardAnim(4)}
        className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-gold/40 bg-gradient-to-r from-amber-50 to-white p-5"
      >
        <div>
          <p className="font-display text-[17px] font-semibold text-navy">
            You're pre-qualified for a Personal Loan up to $25,000 at 9.9% APR
          </p>
          <p className="mt-0.5 text-sm text-subtle">No impact to your credit score to check rates.</p>
        </div>
        <Link
          to="/banking/loans?apply=1"
          className="flex items-center gap-1.5 rounded-lg bg-gold px-4 py-2.5 text-sm font-semibold text-navy transition hover:scale-[1.02] hover:bg-gold-hover"
        >
          Apply in 3 minutes <ArrowRight className="h-4 w-4" />
        </Link>
      </motion.div>
    </BankingLayout>
  );
}
