import type { ReactNode } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

/**
 * Public layout wrapper (landing page only).
 * The customer portal (/banking/*) and staff console (/staff/*) render
 * their own shells — they must NOT be wrapped in this Layout.
 */
export default function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="theme-front flex min-h-[100dvh] flex-col bg-white">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}
