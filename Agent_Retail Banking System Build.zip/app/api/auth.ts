import { z } from "zod";
import { randomBytes } from "crypto";
import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery, protectedProcedure } from "./middleware";
import { getDb } from "./queries/connection";
import { sessions, users } from "@db/schema";
import { sha256, appendAudit } from "./queries/audit";

const SESSION_TTL_MS = 1000 * 60 * 60 * 12; // 12h

export const authRouter = createRouter({
  login: publicQuery
    .input(z.object({ username: z.string().min(1), password: z.string().min(1) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.username, input.username.toLowerCase().trim()))
        .limit(1);
      if (!user || user.passwordHash !== sha256(input.password)) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid username or password" });
      }
      const token = randomBytes(32).toString("hex");
      await db.insert(sessions).values({
        token,
        userId: user.id,
        expiresAt: new Date(Date.now() + SESSION_TTL_MS),
      });
      await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
      await appendAudit({
        actorType: user.role === "customer" ? "customer" : "staff",
        actorName: user.name,
        action: "session.login",
        entityType: "user",
        entityId: user.username,
        detail: `Login successful (${user.role}).`,
      });
      return {
        token,
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          role: user.role,
          customerId: user.customerId,
        },
      };
    }),

  me: protectedProcedure.query(({ ctx }) => ({ user: ctx.session })),

  logout: protectedProcedure.mutation(async ({ ctx }) => {
    const token = ctx.req.headers.get("x-session-token");
    if (token) {
      await getDb().delete(sessions).where(eq(sessions.token, token));
    }
    return { ok: true };
  }),
});
