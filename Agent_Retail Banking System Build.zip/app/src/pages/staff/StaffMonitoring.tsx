import { useMemo, useState } from "react";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { toast, Toaster } from "sonner";
import { AlertTriangle, Flag, Search, ShieldAlert, Send, CircleDot } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useSession } from "@/hooks/useSession";
import DataTable, { type Column } from "@/components/shared/DataTable";
import StatusBadge from "@/components/shared/StatusBadge";
import MoneyText from "@/components/shared/MoneyText";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from "@/components/ui/sheet";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

type AlertRow = {
  id: number;
  alertNo: string;
  type: "structuring" | "high_velocity" | "unusual_amount" | "geo_anomaly";
  severity: "low" | "medium" | "high" | "critical";
  status: "open" | "investigating" | "resolved" | "dismissed";
  description: string;
  createdAt: Date;
  assignedTo: string | null;
  customerId: number;
  customerName: string;
  customerNo: string;
};

type TxnRow = {
  id: number;
  txnId: string;
  type: string;
  amount: string;
  direction: "dr" | "cr";
  merchant: string | null;
  description: string;
  category: string;
  status: "posted" | "pending" | "flagged";
  flagReason: string | null;
  occurredAt: Date;
  accountNickname: string;
  accountLast4: string;
  customerName: string;
  customerNo: string;
};

const SEV_STYLE: Record<string, string> = {
  critical: "bg-red-500/20 text-red-300 border-red-500/40",
  high: "bg-red-500/10 text-red-300 border-red-500/30",
  medium: "bg-amber-500/15 text-amber-300 border-amber-500/30",
  low: "bg-slate-500/20 text-slate-300 border-slate-500/30",
};
const SEV_BORDER: Record<string, string> = {
  critical: "border-l-red-500",
  high: "border-l-red-400",
  medium: "border-l-amber-400",
  low: "border-l-slate-500",
};
const RULE_LABEL: Record<string, string> = {
  structuring: "RULE-03: Aggregate cash deposits ≥ $10,000 within 72h (CTR threshold)",
  high_velocity: "RULE-05: Card velocity > 10 txns/hour",
  unusual_amount: "RULE-01: Single transaction > $10,000",
  geo_anomaly: "RULE-06: IP geolocation mismatch at login",
};
const ALERT_STATUS_LABEL: Record<string, string> = {
  open: "Pending", investigating: "Under Review", resolved: "Approved", dismissed: "Closed",
};

const DETECTION_RULES = [
  { id: "RULE-01", desc: "Single transaction > $10,000", threshold: "$10,000", active: true },
  { id: "RULE-02", desc: "Wire to high-risk jurisdiction", threshold: "list: FATF grey", active: true },
  { id: "RULE-03", desc: "Structuring: aggregate cash ≥ $10k/72h", threshold: "$10,000 / 72h", active: true },
  { id: "RULE-04", desc: "Dormant reactivation + large transfer", threshold: "180d + $5,000", active: true },
  { id: "RULE-05", desc: "Card velocity > 10 txns/hour", threshold: "10/hr", active: false },
];

export default function StaffMonitoring() {
  const { user } = useSession();
  const utils = trpc.useUtils();
  const [tab, setTab] = useState<"alerts" | "txns" | "rules">("alerts");
  const [alertStatus, setAlertStatus] = useState<string>("all");
  const alertsQuery = trpc.staff.listAlerts.useQuery(
    alertStatus === "all" ? {} : { status: alertStatus as "open" }
  );
  const [selectedAlert, setSelectedAlert] = useState<AlertRow | null>(null);
  const [comment, setComment] = useState("");
  const [comments, setComments] = useState<Record<number, { by: string; text: string; at: string }[]>>({});

  // txn filters
  const [search, setSearch] = useState("");
  const [txnStatus, setTxnStatus] = useState<string>("all");
  const [txnType, setTxnType] = useState<string>("all");
  const [page, setPage] = useState(1);
  const txnsQuery = trpc.staff.monitoringTxns.useQuery({
    search: search || undefined,
    status: txnStatus === "all" ? undefined : (txnStatus as "flagged"),
    type: txnType === "all" ? undefined : txnType,
    page,
  });
  const flaggedQuery = trpc.staff.flaggedQueue.useQuery();
  const [selectedTxn, setSelectedTxn] = useState<TxnRow | null>(null);
  const [rules, setRules] = useState(DETECTION_RULES);

  const updateAlert = trpc.staff.updateAlert.useMutation({
    onSuccess: (_d, vars) => {
      toast.success(`Alert ${selectedAlert?.alertNo} → ${vars.status}`);
      void utils.staff.listAlerts.invalidate();
      setSelectedAlert((prev) => (prev && vars.id === prev.id ? { ...prev, status: vars.status, assignedTo: user?.name ?? prev.assignedTo } : prev));
    },
    onError: (e) => toast.error(e.message),
  });

  const alerts = (alertsQuery.data ?? []) as AlertRow[];
  const openCount = alerts.filter((a) => a.status === "open" || a.status === "investigating").length;
  const txns = (txnsQuery.data?.transactions ?? []) as TxnRow[];
  const total = txnsQuery.data?.total ?? 0;
  const flagged = (flaggedQuery.data ?? []) as TxnRow[];

  const txnColumns: Column<TxnRow>[] = useMemo(() => [
    { key: "id", header: "Txn ID", render: (r) => <span className="font-mono text-[12px] text-[#2DD4A8]">{r.txnId}</span>, sortValue: (r) => r.txnId },
    { key: "date", header: "Date/Time", render: (r) => <span className="font-mono text-[12px] tabular-nums text-staff-subtle">{format(new Date(r.occurredAt), "MMM dd HH:mm")}</span>, sortValue: (r) => new Date(r.occurredAt).getTime() },
    { key: "customer", header: "Customer", render: (r) => <span className="text-staff-text">{r.customerName}</span>, sortValue: (r) => r.customerName },
    { key: "account", header: "Account", render: (r) => <span className="font-mono text-[12px] text-staff-subtle">••••{r.accountLast4}</span> },
    { key: "type", header: "Type", render: (r) => <span className="capitalize text-staff-subtle">{r.type}</span>, sortValue: (r) => r.type },
    { key: "counterparty", header: "Counterparty", render: (r) => <span className="text-staff-subtle">{r.merchant ?? "—"}</span> },
    {
      key: "amount", header: "Amount", headerClassName: "text-right", className: "text-right",
      render: (r) => (
        <MoneyText
          amount={r.direction === "dr" ? -Number(r.amount) : Number(r.amount)}
          className={cn("font-mono text-[12.5px]", r.direction === "dr" ? "text-red-300" : "text-emerald-300")}
        />
      ),
      sortValue: (r) => Number(r.amount),
    },
    {
      key: "flag", header: "Flag",
      render: (r) => r.status === "flagged"
        ? <span className="inline-flex items-center gap-1 text-red-400" title={r.flagReason ?? "flagged"}><CircleDot className="h-3.5 w-3.5" /><span className="text-[11px]">{r.flagReason ?? "flagged"}</span></span>
        : <span className="text-staff-subtle">—</span>,
    },
  ], []);

  const setAlertStatusAction = (status: "investigating" | "resolved" | "dismissed") => {
    if (!selectedAlert) return;
    if (status === "dismissed" && !comment.trim()) {
      toast.error("A note is required to dismiss as false positive");
      return;
    }
    updateAlert.mutate({ id: selectedAlert.id, status });
  };

  return (
    <div className="space-y-5">
      <Toaster position="top-right" theme="dark" richColors />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-semibold text-staff-text">Transaction Monitoring</h1>
          <p className="text-xs text-staff-subtle">AML detection · {openCount} open alerts · {flagged.length} flagged transactions</p>
        </div>
        <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
          <TabsList className="border border-staff-border bg-staff-panel">
            <TabsTrigger value="alerts">Alerts ({alerts.length})</TabsTrigger>
            <TabsTrigger value="txns">All Transactions</TabsTrigger>
            <TabsTrigger value="rules">Rules</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {tab === "alerts" && (
        <div className="grid gap-4 lg:grid-cols-[55%_1fr]">
          {/* Alerts list */}
          <div className="overflow-hidden rounded-xl border border-staff-border bg-staff-panel">
            <div className="flex items-center gap-2 border-b border-staff-border px-4 py-2.5">
              <span className="text-xs font-semibold uppercase tracking-[0.06em] text-staff-subtle">Alert queue</span>
              <div className="ml-auto">
                <Select value={alertStatus} onValueChange={setAlertStatus}>
                  <SelectTrigger className="h-8 w-36 border-staff-border bg-staff-raised text-xs text-staff-text">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
                    {["all", "open", "investigating", "resolved", "dismissed"].map((s) => (
                      <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            {alertsQuery.isLoading ? (
              <div className="space-y-2 p-4">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full bg-staff-raised" />)}</div>
            ) : alerts.length === 0 ? (
              <div className="p-10 text-center text-sm text-staff-subtle">No alerts match this filter.</div>
            ) : (
              <div className="max-h-[640px] overflow-y-auto">
                {alerts.map((a, i) => (
                  <motion.button
                    key={a.alertNo}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.03 }}
                    onClick={() => setSelectedAlert(a)}
                    className={cn(
                      "block w-full border-b border-l-[3px] border-staff-border px-4 py-3 text-left transition hover:bg-staff-hover",
                      SEV_BORDER[a.severity],
                      selectedAlert?.id === a.id && "bg-staff-hover",
                      a.severity === "critical" && a.status === "open" && "animate-pulse [animation-duration:2.5s]"
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[12px] text-[#2DD4A8]">{a.alertNo}</span>
                      <span className={cn("rounded-full border px-2 py-0.5 text-[10.5px] font-bold uppercase", SEV_STYLE[a.severity])}>{a.severity}</span>
                      <span className="ml-auto text-[11px] text-staff-subtle">{format(new Date(a.createdAt), "MMM dd")}</span>
                    </div>
                    <p className="mt-1 line-clamp-2 text-[12.5px] text-staff-text">{a.description}</p>
                    <div className="mt-1 flex items-center gap-2 text-[11px] text-staff-subtle">
                      <span>{a.customerName} · {a.customerNo}</span>
                      <span className="ml-auto capitalize">{a.status}{a.assignedTo ? ` · ${a.assignedTo}` : ""}</span>
                    </div>
                  </motion.button>
                ))}
              </div>
            )}
          </div>

          {/* Detail pane */}
          <div className="rounded-xl border border-staff-border bg-staff-panel">
            {selectedAlert ? (
              <motion.div key={selectedAlert.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex h-full flex-col">
                <div className="border-b border-staff-border px-5 py-4">
                  <div className="flex items-center gap-2">
                    <h2 className="font-mono text-sm text-[#2DD4A8]">{selectedAlert.alertNo}</h2>
                    <span className={cn("rounded-full border px-2 py-0.5 text-[10.5px] font-bold uppercase", SEV_STYLE[selectedAlert.severity])}>{selectedAlert.severity}</span>
                    <StatusBadge dark status={ALERT_STATUS_LABEL[selectedAlert.status] ?? "Pending"} className="ml-auto" />
                  </div>
                  <p className="mt-2 text-[13px] text-staff-text">{selectedAlert.description}</p>
                  <p className="mt-1 font-mono text-[11px] text-staff-subtle">{RULE_LABEL[selectedAlert.type]}</p>
                </div>
                <div className="space-y-4 p-5">
                  <div className="rounded-lg border border-staff-border bg-staff-raised p-3">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">Customer snapshot</div>
                    <div className="mt-1 flex items-center justify-between text-[13px]">
                      <span className="font-medium text-staff-text">{selectedAlert.customerName}</span>
                      <span className="font-mono text-[11px] text-staff-subtle">{selectedAlert.customerNo}</span>
                    </div>
                    <div className="mt-1 text-[11.5px] text-staff-subtle">Risk score {selectedAlert.severity === "critical" ? 82 : selectedAlert.severity === "high" ? 64 : 37}/100 · KYC verified</div>
                  </div>
                  <div>
                    <div className="mb-2 text-[11px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">Analyst comments</div>
                    <div className="space-y-2">
                      {(comments[selectedAlert.id] ?? []).map((c, i) => (
                        <div key={i} className="rounded-lg border border-staff-border bg-staff-raised px-3 py-2 text-[12px]">
                          <span className="font-medium text-staff-text">{c.by}</span>
                          <span className="ml-2 text-[10.5px] text-staff-subtle">{c.at}</span>
                          <p className="mt-0.5 text-staff-subtle">{c.text}</p>
                        </div>
                      ))}
                      {(comments[selectedAlert.id] ?? []).length === 0 && (
                        <p className="text-[12px] text-staff-subtle">No comments yet.</p>
                      )}
                    </div>
                    <div className="mt-2 flex gap-2">
                      <input
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder="Add analyst note…"
                        className="flex-1 rounded-lg border border-staff-border bg-staff-raised px-3 py-2 text-[12.5px] text-staff-text placeholder:text-staff-subtle focus:outline-none focus:ring-1 focus:ring-[#2DD4A8]"
                      />
                      <button
                        onClick={() => {
                          if (!comment.trim()) return;
                          setComments((m) => ({ ...m, [selectedAlert.id]: [...(m[selectedAlert.id] ?? []), { by: user?.name ?? "You", text: comment, at: "Feb 14, 2025" }] }));
                          setComment("");
                        }}
                        className="rounded-lg border border-staff-border px-3 text-staff-subtle hover:text-staff-text"
                      >
                        <Send className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
                <div className="mt-auto space-y-2 border-t border-staff-border p-4">
                  <div className="flex gap-2">
                    <button
                      disabled={updateAlert.isPending || selectedAlert.status === "investigating"}
                      onClick={() => setAlertStatusAction("investigating")}
                      className="flex-1 rounded-lg border border-blue-400/40 px-3 py-2 text-[12.5px] font-medium text-blue-300 hover:bg-blue-400/10 disabled:opacity-40"
                    >
                      Mark investigating
                    </button>
                    <button
                      disabled={updateAlert.isPending}
                      onClick={() => { setAlertStatusAction("resolved"); toast.success("SAR draft generated (stub)"); }}
                      className="flex-1 rounded-lg bg-red-500/90 px-3 py-2 text-[12.5px] font-semibold text-white hover:bg-red-500 disabled:opacity-40"
                    >
                      Escalate · file SAR draft
                    </button>
                  </div>
                  <button
                    disabled={updateAlert.isPending}
                    onClick={() => setAlertStatusAction("dismissed")}
                    className="w-full rounded-lg border border-staff-border px-3 py-2 text-[12.5px] text-staff-subtle hover:text-staff-text disabled:opacity-40"
                  >
                    Dismiss — false positive (requires note above)
                  </button>
                </div>
              </motion.div>
            ) : (
              <div className="flex h-full min-h-[320px] flex-col items-center justify-center gap-2 p-10 text-center">
                <ShieldAlert className="h-8 w-8 text-staff-subtle" />
                <p className="text-sm text-staff-subtle">Select an alert to review details.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {tab === "txns" && (
        <div className="space-y-4">
          {/* Flagged queue strip */}
          <div className="rounded-xl border border-staff-border bg-staff-panel">
            <div className="flex items-center gap-2 border-b border-staff-border px-4 py-2.5">
              <Flag className="h-4 w-4 text-red-400" />
              <span className="text-xs font-semibold uppercase tracking-[0.06em] text-staff-subtle">Flagged queue ({flagged.length})</span>
            </div>
            {flaggedQuery.isLoading ? (
              <div className="p-4"><Skeleton className="h-10 w-full bg-staff-raised" /></div>
            ) : flagged.length === 0 ? (
              <p className="p-4 text-[12.5px] text-staff-subtle">No transactions currently flagged.</p>
            ) : (
              <div className="max-h-56 overflow-y-auto">
                {flagged.map((t) => (
                  <button
                    key={t.txnId}
                    onClick={() => setSelectedTxn(t)}
                    className="flex w-full items-center gap-3 border-b border-l-[3px] border-l-red-500 border-staff-border px-4 py-2.5 text-left transition hover:bg-staff-hover"
                  >
                    <span className="font-mono text-[12px] text-[#2DD4A8]">{t.txnId}</span>
                    <span className="text-[12.5px] text-staff-text">{t.customerName}</span>
                    <span className="text-[12px] text-staff-subtle">{t.flagReason ?? t.description}</span>
                    <span className="ml-auto font-mono text-[12.5px] tabular-nums text-red-300">
                      <MoneyText amount={t.direction === "dr" ? -Number(t.amount) : Number(t.amount)} variant="neutral" />
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Filter bar */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-staff-subtle" />
              <input
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                placeholder="Search txn, merchant, customer…"
                className="w-64 rounded-lg border border-staff-border bg-staff-panel py-2 pl-8 pr-3 text-[12.5px] text-staff-text placeholder:text-staff-subtle focus:outline-none focus:ring-1 focus:ring-[#2DD4A8]"
              />
            </div>
            <Select value={txnStatus} onValueChange={(v) => { setTxnStatus(v); setPage(1); }}>
              <SelectTrigger className="h-9 w-40 border-staff-border bg-staff-panel text-xs text-staff-text"><SelectValue /></SelectTrigger>
              <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
                {["all", "posted", "pending", "flagged"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={txnType} onValueChange={(v) => { setTxnType(v); setPage(1); }}>
              <SelectTrigger className="h-9 w-40 border-staff-border bg-staff-panel text-xs text-staff-text"><SelectValue /></SelectTrigger>
              <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
                {["all", "transfer", "deposit", "withdrawal", "fee", "interest", "payment", "purchase"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="ml-auto flex items-center gap-2 text-xs text-staff-subtle">
              <span className="tabular-nums">{total.toLocaleString()} transactions</span>
              <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="rounded border border-staff-border px-2 py-1 disabled:opacity-30">Prev</button>
              <span className="font-mono tabular-nums">{page}</span>
              <button disabled={page * 20 >= total} onClick={() => setPage((p) => p + 1)} className="rounded border border-staff-border px-2 py-1 disabled:opacity-30">Next</button>
            </div>
          </div>

          {txnsQuery.isLoading ? (
            <div className="space-y-2 rounded-xl border border-staff-border bg-staff-panel p-4">
              {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-11 w-full bg-staff-raised" />)}
            </div>
          ) : (
            <DataTable
              dark
              columns={txnColumns}
              data={txns}
              pageSize={20}
              rowKey={(r) => r.txnId}
              onRowClick={setSelectedTxn}
              flagged={(r) => r.status === "flagged"}
              emptyMessage="No transactions match the current filters."
            />
          )}
        </div>
      )}

      {tab === "rules" && (
        <div className="overflow-hidden rounded-xl border border-staff-border bg-staff-panel">
          <div className="border-b border-staff-border px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.06em] text-staff-subtle">
            Detection rules · threshold edits are Admin-only and logged
          </div>
          {rules.map((r) => (
            <div key={r.id} className="flex items-center gap-4 border-b border-staff-border px-4 py-3 last:border-0">
              <span className="font-mono text-[12px] text-[#2DD4A8]">{r.id}</span>
              <span className="flex-1 text-[13px] text-staff-text">{r.desc}</span>
              <span className="rounded-md border border-staff-border bg-staff-raised px-2 py-1 font-mono text-[11.5px] text-staff-subtle">{r.threshold}</span>
              <span className={cn("text-[11.5px] font-medium", r.active ? "text-emerald-300" : "text-amber-300")}>{r.active ? "Active" : "Paused"}</span>
              <Switch
                checked={r.active}
                disabled={user?.role !== "admin"}
                onCheckedChange={(v) => {
                  setRules((rs) => rs.map((x) => (x.id === r.id ? { ...x, active: v } : x)));
                  toast.success(`${r.id} ${v ? "activated" : "paused"} — change logged`);
                }}
              />
            </div>
          ))}
          {user?.role !== "admin" && (
            <p className="px-4 py-2.5 text-[11.5px] text-staff-subtle">Rule changes require the Admin role.</p>
          )}
        </div>
      )}

      {/* Txn detail drawer */}
      <Sheet open={!!selectedTxn} onOpenChange={(o) => !o && setSelectedTxn(null)}>
        <SheetContent side="right" className="w-full border-l border-staff-border bg-staff-panel text-staff-text sm:max-w-[440px]">
          {selectedTxn && (
            <>
              <SheetHeader>
                <SheetTitle className="font-mono text-sm text-[#2DD4A8]">{selectedTxn.txnId}</SheetTitle>
                <SheetDescription className="text-staff-subtle">
                  {format(new Date(selectedTxn.occurredAt), "MMM dd, yyyy HH:mm")} · {selectedTxn.customerName} · ••••{selectedTxn.accountLast4}
                </SheetDescription>
              </SheetHeader>
              <div className="mt-4 space-y-4 px-1">
                <div className="rounded-lg border border-staff-border bg-staff-raised p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] text-staff-subtle">{selectedTxn.description}</span>
                    <StatusBadge dark status={selectedTxn.status === "flagged" ? "Flagged" : selectedTxn.status === "pending" ? "Pending" : "Approved"} />
                  </div>
                  <div className={cn("mt-2 font-mono text-2xl tabular-nums", selectedTxn.direction === "dr" ? "text-red-300" : "text-emerald-300")}>
                    <MoneyText amount={selectedTxn.direction === "dr" ? -Number(selectedTxn.amount) : Number(selectedTxn.amount)} />
                  </div>
                  {selectedTxn.flagReason && (
                    <div className="mt-2 flex items-center gap-1.5 text-[12px] text-red-300">
                      <AlertTriangle className="h-3.5 w-3.5" /> {selectedTxn.flagReason}
                    </div>
                  )}
                </div>
                <div className="rounded-lg border border-staff-border bg-staff-raised p-4">
                  <div className="mb-2 text-[11px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">Ledger entries</div>
                  {[
                    { leg: "Dr", acct: selectedTxn.direction === "dr" ? `Customer ${selectedTxn.accountNickname}` : "Cash / Clearing", amt: Number(selectedTxn.amount) },
                    { leg: "Cr", acct: selectedTxn.direction === "dr" ? (selectedTxn.merchant ?? "Counterparty") : `Customer ${selectedTxn.accountNickname}`, amt: Number(selectedTxn.amount) },
                  ].map((l) => (
                    <div key={l.leg} className="flex items-center justify-between py-1 font-mono text-[12px]">
                      <span className="text-staff-subtle"><span className="mr-2 text-[#2DD4A8]">{l.leg}</span>{l.acct}</span>
                      <span className="tabular-nums text-staff-text">${l.amt.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
                    </div>
                  ))}
                </div>
                <div className="space-y-1.5 text-[12.5px]">
                  <div className="flex justify-between"><span className="text-staff-subtle">Category</span><span className="text-staff-text">{selectedTxn.category}</span></div>
                  <div className="flex justify-between"><span className="text-staff-subtle">Type</span><span className="capitalize text-staff-text">{selectedTxn.type}</span></div>
                  <div className="flex justify-between"><span className="text-staff-subtle">Merchant / counterparty</span><span className="text-staff-text">{selectedTxn.merchant ?? "—"}</span></div>
                  <div className="flex justify-between"><span className="text-staff-subtle">Customer</span><span className="font-mono text-staff-text">{selectedTxn.customerNo}</span></div>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
