import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import { Eye, EyeOff, Lock, Loader2, ArrowRight } from "lucide-react";
import { useSession } from "@/hooks/useSession";
import { Toaster } from "@/components/ui/sonner";
import { cn } from "@/lib/utils";

const TIPS = [
  "We will never ask for your password by email.",
  "Enable two-factor authentication for an extra layer of protection.",
  "Always check the address bar for secure.meridian-bank.demo before signing in.",
];

export default function Login() {
  const { login } = useSession();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shakeKey, setShakeKey] = useState(0);
  const [tip, setTip] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setTip((v) => (v + 1) % TIPS.length), 4000);
    return () => clearInterval(t);
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const started = Date.now();
    try {
      const user = await login(email.trim(), password);
      // Simulated 800ms auth floor for realism
      const wait = Math.max(0, 800 - (Date.now() - started));
      await new Promise((r) => setTimeout(r, wait));
      if (user.role !== "customer") {
        navigate("/staff");
        return;
      }
      navigate("/banking");
    } catch {
      await new Promise((r) => setTimeout(r, Math.max(0, 800 - (Date.now() - started))));
      setError("Invalid credentials. 2 attempts remaining.");
      setShakeKey((k) => k + 1);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="theme-front flex min-h-[100dvh] bg-white">
      <Toaster position="top-right" richColors />
      {/* Left navy panel */}
      <div className="relative hidden w-[45%] overflow-hidden bg-navy-deep lg:block">
        <motion.img
          src="/hero-skyline.jpg"
          alt=""
          className="absolute inset-0 h-full w-full object-cover opacity-40"
          animate={{ scale: [1, 1.08] }}
          transition={{ duration: 24, repeat: Infinity, repeatType: "reverse", ease: "linear" }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-navy-deep/70 via-navy-deep/40 to-navy-deep/90" />
        <div className="relative z-10 flex h-full flex-col p-12">
          <Link to="/">
            <img src="/logo.svg" alt="Meridian Bank" className="h-8 w-auto brightness-0 invert" />
          </Link>
          <div className="mt-auto">
            <h1 className="font-display text-4xl font-bold leading-tight text-white">
              Welcome back
              <br />
              to Meridian.
            </h1>
            <div className="mt-8 h-12">
              <AnimatePresence mode="wait">
                <motion.p
                  key={tip}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.4 }}
                  className="flex items-center gap-2 text-sm text-slate-300"
                >
                  <Lock className="h-4 w-4 text-gold" />
                  {TIPS[tip]}
                </motion.p>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      {/* Right login panel */}
      <div className="flex flex-1 items-center justify-center bg-slate-50 px-6">
        <motion.div
          key={shakeKey}
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0, x: error ? [0, -8, 8, -6, 6, 0] : 0 }}
          transition={{
            opacity: { duration: 0.5, ease: "easeOut" },
            y: { duration: 0.5, ease: "easeOut" },
            x: { duration: 0.3 },
          }}
          className="w-full max-w-[400px] rounded-2xl border border-slate-200 bg-white p-8 shadow-sm"
        >
          <img src="/logo.svg" alt="Meridian Bank" className="mb-6 h-7 w-auto lg:hidden" />
          <h2 className="font-display text-[22px] font-semibold text-navy">
            Sign in to Online Banking
          </h2>

          <form onSubmit={submit} className="mt-6 space-y-4">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.07 }}
            >
              <label className="mb-1.5 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">
                Email
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className={cn(
                  "h-11 w-full rounded-lg border bg-white px-3 text-sm outline-none transition focus:border-navy",
                  error ? "border-[#B42318]" : "border-slate-300"
                )}
              />
              <button
                type="button"
                onClick={() => setEmail("elena.vasquez@demo.meridian")}
                className="mt-1.5 rounded-full bg-amber-50 px-2.5 py-1 text-[11px] font-medium text-amber-800 transition hover:bg-amber-100"
              >
                Demo: elena.vasquez@demo.meridian
              </button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.14 }}
            >
              <label className="mb-1.5 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPw ? "text" : "password"}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="demo1234"
                  className={cn(
                    "h-11 w-full rounded-lg border bg-white px-3 pr-10 text-sm outline-none transition focus:border-navy",
                    error ? "border-[#B42318]" : "border-slate-300"
                  )}
                />
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-navy"
                  aria-label={showPw ? "Hide password" : "Show password"}
                >
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </motion.div>

            <AnimatePresence>
              {error && (
                <motion.p
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="rounded-lg bg-red-50 px-3 py-2 text-xs font-medium text-[#B42318]"
                >
                  {error}
                </motion.p>
              )}
            </AnimatePresence>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.21 }}
              className="flex items-center justify-between text-sm"
            >
              <label className="flex items-center gap-2 text-slate-600">
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={(e) => setRemember(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 accent-[#0B2545]"
                />
                Remember this device
              </label>
              <span className="cursor-pointer font-medium text-navy hover:underline">
                Forgot password?
              </span>
            </motion.div>

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-gold font-semibold text-navy transition-colors hover:bg-gold-hover disabled:opacity-70"
            >
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              {loading ? "Signing in…" : "Sign In"}
            </motion.button>
          </form>

          <div className="my-5 flex items-center gap-3 text-xs text-slate-400">
            <span className="h-px flex-1 bg-slate-200" />
            or
            <span className="h-px flex-1 bg-slate-200" />
          </div>

          <p className="text-center text-sm text-slate-600">
            New to Meridian?{" "}
            <Link to="/" className="font-medium text-navy hover:underline">
              Open an account
            </Link>
          </p>

          <div className="mt-6 border-t border-slate-100 pt-4 text-center">
            <p className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
              <Lock className="h-3 w-3" /> Secured with 256-bit encryption
            </p>
            <Link
              to="/staff/login"
              className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-navy hover:underline"
            >
              Staff? Sign in to the Staff Console <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
