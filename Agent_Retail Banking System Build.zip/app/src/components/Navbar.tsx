import { useEffect, useState } from "react";
import { Link } from "react-router";
import { Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";

const LINKS = [
  { label: "Personal", href: "/#personal" },
  { label: "Cards", href: "/#cards" },
  { label: "Loans", href: "/#loans" },
  { label: "Mortgages", href: "/#mortgages" },
  { label: "About", href: "/#about" },
];

/**
 * Public landing navbar — sticky, transparent over the hero,
 * transitions to solid white + shadow after 80px of scroll.
 */
export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-300",
        scrolled
          ? "bg-white/95 shadow-md backdrop-blur supports-[backdrop-filter]:bg-white/85"
          : "bg-transparent"
      )}
    >
      <nav className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center">
          <img
            src="/logo.svg"
            alt="Meridian Bank"
            className={cn("h-9 w-auto transition", !scrolled && "brightness-0 invert")}
          />
        </Link>

        <div className="hidden items-center gap-7 lg:flex">
          {LINKS.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-gold",
                scrolled ? "text-navy" : "text-white/90"
              )}
            >
              {l.label}
            </a>
          ))}
        </div>

        <div className="hidden items-center gap-3 lg:flex">
          <Link
            to="/login"
            className={cn(
              "rounded-lg px-4 py-2 text-sm font-semibold transition-colors",
              scrolled
                ? "text-navy hover:bg-slate-100"
                : "text-white hover:bg-white/10"
            )}
          >
            Log In
          </Link>
          <Link
            to="/login"
            className="rounded-lg bg-gold px-4 py-2 text-sm font-semibold text-navy-deep shadow-sm transition hover:bg-gold-hover"
          >
            Open an Account
          </Link>
        </div>

        <button
          className={cn("lg:hidden", scrolled ? "text-navy" : "text-white")}
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {/* Mobile drawer */}
      {open && (
        <div className="border-t border-slate-200 bg-white px-4 py-4 shadow-lg lg:hidden">
          <div className="flex flex-col gap-1">
            {LINKS.map((l) => (
              <a
                key={l.label}
                href={l.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm font-medium text-navy hover:bg-slate-50"
              >
                {l.label}
              </a>
            ))}
            <div className="mt-3 flex gap-3 border-t border-slate-100 pt-3">
              <Link
                to="/login"
                className="flex-1 rounded-lg border border-navy px-4 py-2 text-center text-sm font-semibold text-navy"
              >
                Log In
              </Link>
              <Link
                to="/login"
                className="flex-1 rounded-lg bg-gold px-4 py-2 text-center text-sm font-semibold text-navy-deep"
              >
                Open an Account
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
