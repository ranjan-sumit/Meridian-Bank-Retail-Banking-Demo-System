import type { ReactNode } from "react";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * KPI card: label, big value, delta chip vs last month, optional sparkline
 * (pass a recharts sparkline element via `sparkline`).
 */
export default function KpiCard({
  label,
  value,
  delta,
  deltaLabel = "vs last month",
  sparkline,
  dark = false,
  className,
}: {
  label: string;
  value: ReactNode;
  /** Percent change, e.g. 4.2 or -1.8 */
  delta?: number;
  deltaLabel?: string;
  sparkline?: ReactNode;
  dark?: boolean;
  className?: string;
}) {
  const positive = (delta ?? 0) >= 0;
  return (
    <div
      className={cn(
        "rounded-xl border p-5 shadow-sm",
        dark ? "border-staff-border bg-staff-panel" : "border-slate-200 bg-white",
        className
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p
            className={cn(
              "text-[11px] font-medium uppercase tracking-[0.06em]",
              dark ? "text-staff-subtle" : "text-slate-500"
            )}
          >
            {label}
          </p>
          <p
            className={cn(
              "mt-1.5 font-display text-2xl font-bold tabular-nums",
              dark ? "text-staff-text" : "text-navy"
            )}
          >
            {value}
          </p>
          {delta !== undefined && (
            <p className="mt-1.5 flex items-center gap-1 text-xs">
              <span
                className={cn(
                  "inline-flex items-center gap-0.5 rounded-full px-1.5 py-0.5 font-medium tabular-nums",
                  positive
                    ? "bg-emerald-500/10 text-emerald-600"
                    : "bg-red-500/10 text-red-500"
                )}
              >
                {positive ? (
                  <ArrowUpRight className="h-3 w-3" />
                ) : (
                  <ArrowDownRight className="h-3 w-3" />
                )}
                {Math.abs(delta).toFixed(1)}%
              </span>
              <span className={dark ? "text-staff-subtle" : "text-slate-400"}>{deltaLabel}</span>
            </p>
          )}
        </div>
        {sparkline && <div className="h-12 w-24 shrink-0">{sparkline}</div>}
      </div>
    </div>
  );
}
