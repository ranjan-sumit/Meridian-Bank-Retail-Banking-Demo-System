# Research Brief — Meridian Bank (Retail Banking Demo System)

## Product
A realistic-looking **fictional retail bank** web system used to develop and demo AI agents. Two portals in one app:

### Front Office (customer-facing online banking)
- Public marketing landing page (bank brand "Meridian Bank", products: checking, savings, credit cards, personal loans, mortgages)
- Customer login (demo credentials), dashboard with account balance cards, recent activity
- Accounts list + account detail with paginated transaction history, search/filter, e-statements
- Transfers (between own accounts, to payees/other customers), payment flow with confirmation
- Cards page (debit/credit cards, card status, limits, freeze/unfreeze)
- Loans page (existing loans with schedules, apply for a new loan, application status)
- Profile/settings, notifications/alerts

### Back Office (staff admin console — separate dark/professional theme area)
- Staff login, role model: Teller / Relationship Manager / Admin
- Dashboard: KPIs (total deposits, active loans, pending KYC, flagged transactions), charts
- Customer management: searchable customer list, 360° customer detail (accounts, cards, loans, KYC, notes)
- KYC review queue: pending applications with documents, approve/reject with reason
- Transaction monitoring: all transactions, filters, flagged/suspicious list, AML-style alerts
- Loan approval queue: applications in Pending → Approved/Rejected → Active lifecycle, repayment schedules
- Card management: issuance requests, block/unblock
- Employee & branch management
- Audit log viewer (who did what, when — maker-checker)

## Domain model (borrow from Apache Fineract + Bank of Anthos)
customers, users/credentials, branches, employees(roles), accounts (checking/savings, IBAN-style numbers), transactions (double-entry-ish ledger, types: transfer/deposit/withdrawal/fee/interest), cards, loans (products, applications, schedules), kyc_cases, payees, notifications, audit_log.

## Realism requirements
- Fictional brand "Meridian Bank" — professional banking aesthetic (deep navy/emerald, trust cues), NOT playful
- Dense, data-rich screens like real online banking (Chase/Wells Fargo/Mifos-like), tables, badges, statuses
- Every workflow state represented in seed data: pending KYC, flagged transactions, loans in each stage
- Currency formatting, account number masking (•••• 4821), realistic merchant names in transactions
