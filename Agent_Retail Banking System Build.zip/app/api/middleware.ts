import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";
import { STAFF_ROLES } from "@contracts/types";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const createRouter = t.router;
export const publicQuery = t.procedure;

/** Requires an authenticated session (any role). */
export const protectedProcedure = t.procedure.use(({ ctx, next }) => {
  if (!ctx.session) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Not authenticated" });
  }
  return next({ ctx: { ...ctx, session: ctx.session } });
});

/** Requires a staff role (teller/manager/admin). */
export const staffProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!STAFF_ROLES.includes(ctx.session.role)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Staff access required" });
  }
  return next({ ctx });
});

/** Requires manager or admin. */
export const managerProcedure = staffProcedure.use(({ ctx, next }) => {
  if (ctx.session.role !== "manager" && ctx.session.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Manager access required" });
  }
  return next({ ctx });
});

/** Requires a customer session with a linked customer record. */
export const customerProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.session.role !== "customer" || ctx.session.customerId == null) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Customer access required" });
  }
  return next({ ctx: { ...ctx, session: { ...ctx.session, customerId: ctx.session.customerId } } });
});

export * from "@contracts/errors";
