import { cn } from "@/lib/utils";

export type StatusKind =
  | "Active"
  | "Pending"
  | "Under Review"
  | "Flagged"
  | "Frozen"
  | "Blocked"
  | "Approved"
  | "Rejected"
  | "Closed"
  | "Delinquent"
  | "Paid Off"
  | "Verified";

const STYLES: Record<StatusKind, string> = {
  Active: "bg-emerald-100 text-emerald-800 [&>span]:bg-emerald-600",
  Approved: "bg-emerald-100 text-emerald-800 [&>span]:bg-emerald-600",
  Verified: "bg-emerald-100 text-emerald-800 [&>span]:bg-emerald-600",
  "Paid Off": "bg-teal-100 text-teal-800 [&>span]:bg-teal-600",
  Pending: "bg-amber-100 text-amber-800 [&>span]:bg-amber-500",
  "Under Review": "bg-blue-100 text-blue-800 [&>span]:bg-blue-600",
  Flagged: "bg-red-100 text-red-800 [&>span]:bg-red-600",
  Rejected: "bg-red-100 text-red-800 [&>span]:bg-red-600",
  Delinquent: "bg-red-100 text-red-800 [&>span]:bg-red-600",
  Frozen: "bg-slate-200 text-slate-700 [&>span]:bg-slate-500",
  Blocked: "bg-slate-200 text-slate-700 [&>span]:bg-slate-500",
  Closed: "bg-slate-200 text-slate-700 [&>span]:bg-slate-500",
};

/** Dark-theme variants for the staff console (applied with `dark` prop). */
const STYLES_DARK: Record<StatusKind, string> = {
  Active: "bg-emerald-500/15 text-emerald-300 [&>span]:bg-emerald-400",
  Approved: "bg-emerald-500/15 text-emerald-300 [&>span]:bg-emerald-400",
  Verified: "bg-emerald-500/15 text-emerald-300 [&>span]:bg-emerald-400",
  "Paid Off": "bg-teal-500/15 text-teal-300 [&>span]:bg-teal-400",
  Pending: "bg-amber-500/15 text-amber-300 [&>span]:bg-amber-400",
  "Under Review": "bg-blue-500/15 text-blue-300 [&>span]:bg-blue-400",
  Flagged: "bg-red-500/15 text-red-300 [&>span]:bg-red-400",
  Rejected: "bg-red-500/15 text-red-300 [&>span]:bg-red-400",
  Delinquent: "bg-red-500/15 text-red-300 [&>span]:bg-red-400",
  Frozen: "bg-slate-500/20 text-slate-300 [&>span]:bg-slate-400",
  Blocked: "bg-slate-500/20 text-slate-300 [&>span]:bg-slate-400",
  Closed: "bg-slate-500/20 text-slate-300 [&>span]:bg-slate-400",
};

export default function StatusBadge({
  status,
  dark = false,
  className,
}: {
  status: StatusKind | string;
  dark?: boolean;
  className?: string;
}) {
  const map = dark ? STYLES_DARK : STYLES;
  const style = map[status as StatusKind] ?? (dark ? STYLES_DARK.Closed : STYLES.Closed);
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11.5px] font-medium",
        style,
        className
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full" />
      {status}
    </span>
  );
}
