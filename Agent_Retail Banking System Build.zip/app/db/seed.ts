import "dotenv/config";
import { createHash } from "crypto";
import { sql } from "drizzle-orm";
import { getDb } from "../api/queries/connection";
import * as s from "./schema";

/* ---------- helpers ---------- */
function sha256(input: string) {
  return createHash("sha256").update(input).digest("hex");
}
// deterministic PRNG
let _seed = 42;
function rand() {
  _seed |= 0;
  _seed = (_seed + 0x6d2b79f5) | 0;
  let t = Math.imul(_seed ^ (_seed >>> 15), 1 | _seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
const pick = <T>(arr: T[]): T => arr[Math.floor(rand() * arr.length)];
const between = (min: number, max: number) => min + rand() * (max - min);
const money = (n: number) => n.toFixed(2);
const D = (y: number, m: number, d: number, h = 12, min = 0) =>
  new Date(Date.UTC(y, m - 1, d, h, min));
const TODAY = D(2025, 2, 14, 12);

/* ---------- data ---------- */
const BRANCHES = [
  { code: "BR-001", name: "Downtown HQ", address: "400 Meridian Ave, Boston, MA 02110", phone: "(617) 555-0100" },
  { code: "BR-002", name: "Westside", address: "88 Westside Plaza, Worcester, MA 01608", phone: "(508) 555-0142" },
  { code: "BR-003", name: "Harbor Point", address: "12 Harbor Point Rd, Quincy, MA 02171", phone: "(617) 555-0177" },
];

const CUSTOMERS: Array<{
  first: string; last: string; email: string; phone: string; dob: string;
  address: string; ssn4: string; kyc: "verified" | "pending" | "under_review" | "rejected";
  branch: number; since: Date;
}> = [
  { first: "Elena", last: "Vasquez", email: "elena.vasquez@demo.meridian", phone: "(617) 555-0119", dob: "1988-04-22", address: "27 Beacon St Apt 4B, Boston, MA 02108", ssn4: "4471", kyc: "verified", branch: 0, since: D(2016, 3, 11) },
  { first: "Maya", last: "Ortiz", email: "maya.ortiz@example.com", phone: "(617) 555-0128", dob: "1992-09-03", address: "410 Columbus Ave, Boston, MA 02116", ssn4: "8823", kyc: "verified", branch: 0, since: D(2018, 6, 2) },
  { first: "Daniel", last: "Kim", email: "daniel.kim@example.com", phone: "(617) 555-0133", dob: "1985-12-14", address: "9 Park Dr, Boston, MA 02215", ssn4: "2290", kyc: "verified", branch: 0, since: D(2019, 1, 24) },
  { first: "Aisha", last: "Rahman", email: "aisha.rahman@example.com", phone: "(617) 555-0148", dob: "1990-07-30", address: "1520 Beacon St, Brookline, MA 02446", ssn4: "5574", kyc: "verified", branch: 0, since: D(2020, 4, 9) },
  { first: "Tom", last: "Okafor", email: "tom.okafor@example.com", phone: "(508) 555-0151", dob: "1979-02-11", address: "33 Shrewsbury St, Worcester, MA 01604", ssn4: "3301", kyc: "verified", branch: 1, since: D(2017, 9, 18) },
  { first: "Grace", last: "Muller", email: "grace.muller@example.com", phone: "(508) 555-0166", dob: "1986-05-25", address: "14 Elm Park Ave, Worcester, MA 01605", ssn4: "7719", kyc: "verified", branch: 1, since: D(2021, 2, 5) },
  { first: "Liam", last: "Donnelly", email: "liam.donnelly@example.com", phone: "(617) 555-0172", dob: "1994-11-08", address: "78 Squantum St, Quincy, MA 02171", ssn4: "1188", kyc: "verified", branch: 2, since: D(2022, 8, 14) },
  { first: "Sofia", last: "Petrova", email: "sofia.petrova@example.com", phone: "(617) 555-0184", dob: "1983-03-19", address: "221 Marina Bay, Quincy, MA 02171", ssn4: "6645", kyc: "verified", branch: 2, since: D(2015, 11, 30) },
  { first: "Noah", last: "Bennett", email: "noah.bennett@example.com", phone: "(617) 555-0195", dob: "1991-08-07", address: "5 Charles River Rd, Cambridge, MA 02138", ssn4: "9032", kyc: "verified", branch: 0, since: D(2020, 10, 21) },
  { first: "Isabella", last: "Rossi", email: "isabella.rossi@example.com", phone: "(617) 555-0203", dob: "1987-01-27", address: "64 Hanover St, Boston, MA 02113", ssn4: "3410", kyc: "verified", branch: 0, since: D(2019, 5, 17) },
  { first: "Ethan", last: "Nguyen", email: "ethan.nguyen@example.com", phone: "(508) 555-0217", dob: "1995-06-12", address: "9 Vernon St, Worcester, MA 01610", ssn4: "7856", kyc: "verified", branch: 1, since: D(2023, 3, 8) },
  { first: "Chloe", last: "Fitzgerald", email: "chloe.fitz@example.com", phone: "(617) 555-0229", dob: "1989-10-02", address: "301 D St, South Boston, MA 02127", ssn4: "2167", kyc: "verified", branch: 0, since: D(2018, 12, 1) },
  { first: "Omar", last: "Haddad", email: "omar.haddad@example.com", phone: "(617) 555-0238", dob: "1984-04-15", address: "18 Tremont St, Boston, MA 02108", ssn4: "4521", kyc: "under_review", branch: 0, since: D(2024, 11, 20) },
  { first: "Priya", last: "Nair", email: "priya.nair@example.com", phone: "(617) 555-0244", dob: "1993-02-28", address: "77 Massachusetts Ave, Cambridge, MA 02139", ssn4: "6893", kyc: "pending", branch: 0, since: D(2025, 1, 30) },
  { first: "Jack", last: "Sullivan", email: "jack.sullivan@example.com", phone: "(617) 555-0255", dob: "1976-09-21", address: "455 E 4th St, South Boston, MA 02127", ssn4: "1274", kyc: "verified", branch: 0, since: D(2014, 7, 7) },
  { first: "Amara", last: "Diallo", email: "amara.diallo@example.com", phone: "(508) 555-0261", dob: "1990-12-05", address: "61 Main St, Worcester, MA 01608", ssn4: "9902", kyc: "pending", branch: 1, since: D(2025, 2, 3) },
  { first: "Victor", last: "Lindqvist", email: "victor.lindqvist@example.com", phone: "(617) 555-0270", dob: "1982-06-18", address: "12 Battery St, Boston, MA 02109", ssn4: "3346", kyc: "verified", branch: 0, since: D(2021, 9, 2) },
  { first: "Hannah", last: "Goldstein", email: "hannah.goldstein@example.com", phone: "(617) 555-0286", dob: "1997-03-09", address: "250 Brookline Ave, Boston, MA 02215", ssn4: "5519", kyc: "verified", branch: 0, since: D(2022, 4, 25) },
  { first: "Marcus", last: "Webb", email: "marcus.webb@example.com", phone: "(508) 555-0293", dob: "1980-08-30", address: "7 Institute Rd, Worcester, MA 01609", ssn4: "8064", kyc: "verified", branch: 1, since: D(2016, 10, 12) },
  { first: "Yuki", last: "Tanaka", email: "yuki.tanaka@example.com", phone: "(617) 555-0307", dob: "1992-01-16", address: "1399 Boylston St, Boston, MA 02215", ssn4: "2718", kyc: "verified", branch: 0, since: D(2020, 6, 19) },
  { first: "Diego", last: "Fuentes", email: "diego.fuentes@example.com", phone: "(617) 555-0318", dob: "1988-11-24", address: "88 Chelsea St, East Boston, MA 02128", ssn4: "6357", kyc: "under_review", branch: 0, since: D(2024, 12, 15) },
  { first: "Fatima", last: "Al-Sayed", email: "fatima.alsayed@example.com", phone: "(617) 555-0322", dob: "1991-05-04", address: "42 Meridian St, East Boston, MA 02128", ssn4: "9483", kyc: "pending", branch: 0, since: D(2025, 2, 8) },
  { first: "Patrick", last: "Callahan", email: "patrick.callahan@example.com", phone: "(617) 555-0339", dob: "1973-07-08", address: "19 Neponset Ave, Dorchester, MA 02122", ssn4: "4190", kyc: "verified", branch: 2, since: D(2012, 2, 14) },
  { first: "Ingrid", last: "Johansson", email: "ingrid.johansson@example.com", phone: "(617) 555-0345", dob: "1986-10-27", address: "6 Winthrop St, Cambridge, MA 02138", ssn4: "7620", kyc: "verified", branch: 0, since: D(2019, 8, 30) },
  { first: "Kwame", last: "Mensah", email: "kwame.mensah@example.com", phone: "(508) 555-0351", dob: "1984-02-02", address: "210 Grove St, Worcester, MA 01605", ssn4: "1855", kyc: "rejected", branch: 1, since: D(2024, 10, 9) },
  { first: "Lucia", last: "Moretti", email: "lucia.moretti@example.com", phone: "(617) 555-0368", dob: "1994-04-11", address: "374 Commercial St, Boston, MA 02109", ssn4: "5046", kyc: "verified", branch: 0, since: D(2023, 1, 16) },
  { first: "Henry", last: "Abara", email: "henry.abara@example.com", phone: "(212) 555-0373", dob: "1981-09-13", address: "512 W 148th St, New York, NY 10031", ssn4: "8874", kyc: "verified", branch: 0, since: D(2017, 4, 3) },
  { first: "Zoe", last: "Papadopoulos", email: "zoe.papadopoulos@example.com", phone: "(212) 555-0388", dob: "1990-06-29", address: "30-14 Steinway St, Astoria, NY 11103", ssn4: "2431", kyc: "pending", branch: 0, since: D(2025, 2, 11) },
];

const EMPLOYEES = [
  { no: "EMP-0001", name: "Marcus Chen", email: "marcus.chen@meridian.bank", role: "admin" as const, branch: 0, hired: "2013-05-06" },
  { no: "EMP-0002", name: "Priya Sharma", email: "priya.sharma@meridian.bank", role: "manager" as const, branch: 0, hired: "2016-08-22" },
  { no: "EMP-0003", name: "Jordan Ellis", email: "jordan.ellis@meridian.bank", role: "teller" as const, branch: 0, hired: "2021-03-15" },
  { no: "EMP-0004", name: "Renata Alvarez", email: "renata.alvarez@meridian.bank", role: "teller" as const, branch: 1, hired: "2022-06-01" },
  { no: "EMP-0005", name: "Samuel Osei", email: "samuel.osei@meridian.bank", role: "manager" as const, branch: 1, hired: "2018-11-05" },
  { no: "EMP-0006", name: "Karen Doyle", email: "karen.doyle@meridian.bank", role: "teller" as const, branch: 2, hired: "2023-02-20" },
];

const LOAN_PRODUCTS = [
  { code: "PL-STD", name: "Personal Loan", rateApr: "9.990", minAmount: "1000.00", maxAmount: "50000.00", termMonths: 60 },
  { code: "MTG-30F", name: "30-yr Fixed Mortgage", rateApr: "6.125", minAmount: "50000.00", maxAmount: "2000000.00", termMonths: 360 },
  { code: "AUTO-60", name: "Auto Loan", rateApr: "7.250", minAmount: "5000.00", maxAmount: "100000.00", termMonths: 60 },
];

/* ---------- seed ---------- */
async function main() {
  const db = getDb();
  console.log("Wiping demo tables...");
  await db.execute(sql`SET FOREIGN_KEY_CHECKS=0`);
  for (const t of [
    "auditLog", "notifications", "alerts", "kycCases", "loanPayments", "loans",
    "loanProducts", "cards", "payees", "transactions", "accounts", "employees",
    "sessions", "users", "customers", "branches",
  ]) {
    await db.execute(sql.raw(`DELETE FROM \`${t}\``));
    await db.execute(sql.raw(`ALTER TABLE \`${t}\` AUTO_INCREMENT=1`));
  }
  await db.execute(sql`SET FOREIGN_KEY_CHECKS=1`);

  /* branches */
  await db.insert(s.branches).values(BRANCHES);
  const branchRows = await db.select().from(s.branches);
  const branchId = (i: number) => branchRows[i].id;

  /* customers */
  await db.insert(s.customers).values(
    CUSTOMERS.map((c, i) => ({
      customerNo: `CUS-${1001 + i}`,
      firstName: c.first,
      lastName: c.last,
      email: c.email,
      phone: c.phone,
      dob: c.dob,
      address: c.address,
      ssnLast4: c.ssn4,
      kycStatus: c.kyc,
      branchId: branchId(c.branch),
      createdAt: c.since,
    })),
  );
  const custRows = await db.select().from(s.customers);
  const custId = (i: number) => custRows[i].id;
  const elena = custRows[0];

  /* users */
  await db.insert(s.users).values([
    { username: "elena.vasquez@demo.meridian", passwordHash: sha256("demo1234"), role: "customer", customerId: elena.id, name: "Elena Vasquez" },
    { username: "marcus.chen@meridian.bank", passwordHash: sha256("admin1234"), role: "admin", name: "Marcus Chen" },
    { username: "priya.sharma@meridian.bank", passwordHash: sha256("manager1234"), role: "manager", name: "Priya Sharma" },
    { username: "jordan.ellis@meridian.bank", passwordHash: sha256("teller1234"), role: "teller", name: "Jordan Ellis" },
    { username: "maya.ortiz@example.com", passwordHash: sha256("demo1234"), role: "customer", customerId: custId(1), name: "Maya Ortiz" },
  ]);

  /* employees */
  await db.insert(s.employees).values(
    EMPLOYEES.map((e) => ({
      employeeNo: e.no, name: e.name, email: e.email, role: e.role,
      branchId: branchId(e.branch), status: "active" as const, hiredAt: e.hired,
    })),
  );

  /* loan products */
  await db.insert(s.loanProducts).values(LOAN_PRODUCTS);
  const productRows = await db.select().from(s.loanProducts);
  const [plProd, mtgProd, autoProd] = productRows;

  /* ---------- accounts + transactions ---------- */
  type TxnSeed = {
    accountIdx: number; // index into accounts we insert
    type: "transfer" | "deposit" | "withdrawal" | "fee" | "interest" | "payment" | "purchase";
    amount: number; direction: "dr" | "cr"; merchant?: string; description: string;
    category: string; status?: "posted" | "pending" | "flagged"; flagReason?: string;
    occurredAt: Date; createdBy?: string; counterAccountIdx?: number;
  };
  const acctDefs: Array<{
    accountNumber: string; last4: string;
    type: "checking" | "savings" | "credit" | "mortgage";
    nickname: string; balance: number; apy?: string; creditLimit?: number;
    custIdx: number; branchIdx: number; openedAt: string; status?: "active" | "frozen" | "closed";
  }> = [];
  const txns: TxnSeed[] = [];

  const acctNo = (() => { let n = 100000000; return () => String(++n); })();
  function addAcct(def: Omit<(typeof acctDefs)[number], "accountNumber"> & { accountNumber?: string }) {
    acctDefs.push({ accountNumber: acctNo(), ...def });
    return acctDefs.length - 1;
  }
  function txn(t: TxnSeed) { txns.push(t); }

  // -- Elena (custIdx 0): accounts must match design anchors exactly
  const eCheck = addAcct({ accountNumber: "1100004821", last4: "4821", type: "checking", nickname: "Everyday Checking", balance: 0, custIdx: 0, branchIdx: 0, openedAt: "2016-03-11" });
  const eSave = addAcct({ accountNumber: "1100009034", last4: "9034", type: "savings", nickname: "High-Yield Savings", balance: 0, apy: "4.350", custIdx: 0, branchIdx: 0, openedAt: "2018-05-02" });
  const eCredit = addAcct({ accountNumber: "4400007712", last4: "7712", type: "credit", nickname: "Platinum Rewards Credit Card", balance: 0, creditLimit: 15000, custIdx: 0, branchIdx: 0, openedAt: "2019-09-15" });
  const eMortgage = addAcct({ accountNumber: "9900000442", last4: "0442", type: "mortgage", nickname: "30-yr Fixed Mortgage", balance: -312400, custIdx: 0, branchIdx: 0, openedAt: "2019-06-20" });

  // opening balances (reconcile() adjusts these to hit the design anchors exactly)
  txn({ accountIdx: eCheck, type: "deposit", amount: 15000.0, direction: "cr", description: "OPENING BALANCE — ACCOUNT FUNDING", category: "Deposit", occurredAt: D(2024, 11, 1, 7) });
  txn({ accountIdx: eSave, type: "deposit", amount: 40000.0, direction: "cr", description: "OPENING BALANCE — ACCOUNT FUNDING", category: "Deposit", occurredAt: D(2024, 11, 1, 7) });
  txn({ accountIdx: eCredit, type: "purchase", amount: 800.0, direction: "dr", description: "BALANCE CARRIED FORWARD", category: "General", occurredAt: D(2024, 11, 1, 7) });

  const months = [
    { y: 2024, m: 11 }, { y: 2024, m: 12 }, { y: 2025, m: 1 }, { y: 2025, m: 2 },
  ];
  // Elena checking history
  for (const { y, m } of months) {
    txn({ accountIdx: eCheck, type: "deposit", amount: 3420.0, direction: "cr", merchant: "Northwind Digital", description: "ACH CREDIT NORTHWIND DIGITAL PAYROLL", category: "Income", occurredAt: D(y, m, 1, 9) });
    if (!(y === 2025 && m === 2)) {
      txn({ accountIdx: eCheck, type: "deposit", amount: 3420.0, direction: "cr", merchant: "Northwind Digital", description: "ACH CREDIT NORTHWIND DIGITAL PAYROLL", category: "Income", occurredAt: D(y, m, 15, 9) });
    }
    txn({ accountIdx: eCheck, type: "payment", amount: 1850.0, direction: "dr", merchant: "Harbourview Properties LLC", description: "ZELLE RENT HARBOURVIEW PROPERTIES", category: "Housing", occurredAt: D(y, m, 3, 8) });
    txn({ accountIdx: eCheck, type: "payment", amount: 15.49, direction: "dr", merchant: "Netflix", description: "NETFLIX.COM SUBSCRIPTION", category: "Entertainment", occurredAt: D(y, m, 12, 6) });
    txn({ accountIdx: eCheck, type: "payment", amount: +between(92, 158).toFixed(2), direction: "dr", merchant: "Con Edison", description: "CON EDISON UTILITY BILL AUTOPAY", category: "Utilities", occurredAt: D(y, m, m === 2 ? 11 : 20, 7) });
    txn({ accountIdx: eCheck, type: "payment", amount: 2187.6, direction: "dr", merchant: "Meridian Mortgage", description: "MORTGAGE PAYMENT LN-2019-0442", category: "Housing", occurredAt: D(y, m, 5, 6), counterAccountIdx: eMortgage });
  }
  txn({ accountIdx: eCheck, type: "deposit", amount: 3420.0, direction: "cr", merchant: "Northwind Digital", description: "ACH CREDIT NORTHWIND DIGITAL PAYROLL", category: "Income", occurredAt: D(2025, 2, 14, 9) });
  for (let i = 0; i < 14; i++) {
    const { y, m } = months[i % 4];
    txn({ accountIdx: eCheck, type: "purchase", amount: +between(58, 142).toFixed(2), direction: "dr", merchant: "Whole Foods", description: "WHOLE FOODS MKT #1021 BOSTON MA", category: "Groceries", occurredAt: D(y, m, 2 + Math.floor(between(0, 25)), 17) });
  }
  for (let i = 0; i < 6; i++) {
    const { y, m } = months[i % 4];
    txn({ accountIdx: eCheck, type: "purchase", amount: +between(38, 72).toFixed(2), direction: "dr", merchant: "Shell", description: "SHELL OIL 57441 BOSTON MA", category: "Transport", occurredAt: D(y, m, 2 + Math.floor(between(0, 25)), 8) });
  }
  for (let i = 0; i < 8; i++) {
    const { y, m } = months[i % 4];
    txn({ accountIdx: eCheck, type: "purchase", amount: +between(4.5, 12.8).toFixed(2), direction: "dr", merchant: "Starbucks", description: "STARBUCKS #8841 BOSTON MA", category: "Dining", occurredAt: D(y, m, 2 + Math.floor(between(0, 25)), 8) });
  }
  for (let i = 0; i < 3; i++) {
    const { y, m } = months[i % 4];
    txn({ accountIdx: eCheck, type: "purchase", amount: +between(11, 48).toFixed(2), direction: "dr", merchant: "CVS Pharmacy", description: "CVS/PHARMACY #0229 BOSTON MA", category: "Health", occurredAt: D(y, m, 3 + Math.floor(between(0, 24)), 13) });
  }
  for (let i = 0; i < 5; i++) {
    const { y, m } = months[i % 4];
    txn({ accountIdx: eCheck, type: "purchase", amount: +between(18, 130).toFixed(2), direction: "dr", merchant: "Amazon", description: "AMAZON.COM AMZN.COM/BILL WA", category: "Shopping", occurredAt: D(y, m, 2 + Math.floor(between(0, 25)), 20) });
  }
  txn({ accountIdx: eCheck, type: "transfer", amount: 250.0, direction: "dr", merchant: "Zelle", description: "ZELLE TO MAYA ORTIZ", category: "Transfer", occurredAt: D(2024, 12, 21, 19) });
  txn({ accountIdx: eCheck, type: "transfer", amount: 90.0, direction: "dr", merchant: "Zelle", description: "ZELLE TO MAYA ORTIZ — DINNER SPLIT", category: "Transfer", occurredAt: D(2025, 1, 18, 20) });
  txn({ accountIdx: eCheck, type: "transfer", amount: 1500.0, direction: "dr", description: "ONLINE TRANSFER TO HIGH-YIELD SAVINGS ••••9034", category: "Transfer", occurredAt: D(2025, 1, 6, 10), counterAccountIdx: eSave });
  txn({ accountIdx: eCheck, type: "purchase", amount: 486.2, direction: "dr", merchant: "Delta Air Lines", description: "DELTA AIR LINES BOS-SFO", category: "Travel", occurredAt: D(2025, 1, 24, 14) });
  // flagged wire — structuring pattern
  txn({ accountIdx: eCheck, type: "transfer", amount: 9800.0, direction: "dr", merchant: "Wire: INT'L TRANSFER SARL", description: "WIRE OUT INT'L TRANSFER SARL REF 88X221", category: "Transfer", status: "flagged", flagReason: "Wire just under $10k CTR threshold — structuring pattern", occurredAt: D(2025, 2, 10, 11) });

  // Elena savings history
  txn({ accountIdx: eSave, type: "deposit", amount: 1500.0, direction: "cr", description: "ONLINE TRANSFER FROM EVERYDAY CHECKING ••••4821", category: "Transfer", occurredAt: D(2025, 1, 6, 10), counterAccountIdx: eCheck });
  for (const { y, m } of months) {
    txn({ accountIdx: eSave, type: "interest", amount: +between(148, 182).toFixed(2), direction: "cr", merchant: "Meridian Bank", description: "INTEREST PAYMENT 4.35% APY", category: "Interest", occurredAt: D(y, m, m === 2 ? 14 : 28, 6) });
  }
  txn({ accountIdx: eSave, type: "deposit", amount: 5000.0, direction: "cr", description: "MOBILE CHECK DEPOSIT", category: "Deposit", occurredAt: D(2024, 12, 27, 12) });

  // Elena credit card history
  for (let i = 0; i < 12; i++) {
    const { y, m } = months[i % 4];
    txn({ accountIdx: eCredit, type: "purchase", amount: +between(20, 320).toFixed(2), direction: "dr", merchant: pick(["Amazon", "Whole Foods", "Delta Air Lines", "Starbucks", "CVS Pharmacy"]), description: "CARD PURCHASE ••••7712", category: pick(["Shopping", "Groceries", "Travel", "Dining"]), occurredAt: D(y, m, 2 + Math.floor(between(0, 25)), 15) });
  }
  for (const { y, m } of months) {
    txn({ accountIdx: eCredit, type: "payment", amount: 1200.0, direction: "cr", merchant: "Meridian Bank", description: "CARD PAYMENT RECEIVED — THANK YOU", category: "Payment", occurredAt: D(y, m, m === 2 ? 12 : 24, 9) });
  }

  // -- other customers: ~41 accounts, simple reconciled histories

  const otherAcctIdx: Record<number, number[]> = {};
  const employers = ["HubSpot Inc", "Mass General Brigham", "Wayfair LLC", "State Street Corp", "Boston Scientific", "Toast Inc", "Rapid7", "Akamai Technologies"];
  for (let ci = 1; ci < CUSTOMERS.length; ci++) {
    const nAcct = ci % 3 === 0 ? 3 : ci % 3 === 1 ? 1 : 2;
    otherAcctIdx[ci] = [];
    for (let k = 0; k < nAcct; k++) {
      const type = k === 0 ? "checking" : k === 1 ? "savings" : rand() < 0.5 ? "savings" : "credit";
      const last4 = String(Math.floor(between(1000, 9999)));
      const status = ci === 25 && k === 0 ? "frozen" : "active";
      const idx = addAcct({
        last4, type: type as "checking" | "savings" | "credit",
        nickname: type === "checking" ? "Everyday Checking" : type === "savings" ? "High-Yield Savings" : "Rewards Credit Card",
        balance: 0,
        apy: type === "savings" ? "4.350" : undefined,
        creditLimit: type === "credit" ? 8000 : undefined,
        custIdx: ci, branchIdx: CUSTOMERS[ci].branch,
        openedAt: CUSTOMERS[ci].since.toISOString().slice(0, 10),
        status: status as "active" | "frozen",
      });
      otherAcctIdx[ci].push(idx);
      // opening deposit
      txn({ accountIdx: idx, type: "deposit", amount: +between(800, 12000).toFixed(2), direction: "cr", description: type === "credit" ? "BALANCE TRANSFER IN" : "OPENING DEPOSIT", category: "Deposit", occurredAt: D(2024, 11, 1, 10) });
      // payroll
      for (const { y, m } of months) {
        if (type === "checking") {
          txn({ accountIdx: idx, type: "deposit", amount: +between(1800, 5200).toFixed(2), direction: "cr", merchant: pick(employers), description: "ACH CREDIT PAYROLL", category: "Income", occurredAt: D(y, m, 1, 9) });
          txn({ accountIdx: idx, type: "payment", amount: +between(950, 2400).toFixed(2), direction: "dr", description: "RENT / MORTGAGE PAYMENT", category: "Housing", occurredAt: D(y, m, 3, 8) });
          txn({ accountIdx: idx, type: "payment", amount: 15.49, direction: "dr", merchant: "Netflix", description: "NETFLIX.COM SUBSCRIPTION", category: "Entertainment", occurredAt: D(y, m, 12, 6) });
          txn({ accountIdx: idx, type: "payment", amount: +between(80, 190).toFixed(2), direction: "dr", merchant: "Con Edison", description: "CON EDISON UTILITY BILL", category: "Utilities", occurredAt: D(y, m, 20, 7) });
          for (let g = 0; g < 3; g++) {
            txn({ accountIdx: idx, type: "purchase", amount: +between(25, 160).toFixed(2), direction: "dr", merchant: pick(["Whole Foods", "Shell", "Amazon", "Starbucks", "CVS Pharmacy"]), description: "CARD PURCHASE", category: pick(["Groceries", "Transport", "Shopping", "Dining"]), occurredAt: D(y, m, 2 + Math.floor(between(0, 25)), 16) });
          }
        } else if (type === "savings") {
          txn({ accountIdx: idx, type: "interest", amount: +between(8, 90).toFixed(2), direction: "cr", merchant: "Meridian Bank", description: "INTEREST PAYMENT", category: "Interest", occurredAt: D(y, m, m === 2 ? 14 : 28, 6) });
        }
      }
    }
  }
  // A couple of notable flagged transactions on other customers
  const henryChk = otherAcctIdx[26][0];
  txn({ accountIdx: henryChk, type: "transfer", amount: 9600.0, direction: "dr", merchant: "Wire: INT'L TRANSFER SARL", description: "WIRE OUT INT'L TRANSFER SARL REF 77Q109", category: "Transfer", status: "flagged", flagReason: "Wire just under $10k CTR threshold — structuring pattern", occurredAt: D(2025, 2, 7, 10) });
  txn({ accountIdx: henryChk, type: "deposit", amount: 9800.0, direction: "cr", description: "CASH DEPOSIT — BRANCH BR-002", category: "Deposit", status: "flagged", flagReason: "Cash deposit just under CTR threshold, 3rd this month", occurredAt: D(2025, 2, 5, 14) });
  const tomChk = otherAcctIdx[4][0];
  txn({ accountIdx: tomChk, type: "purchase", amount: 2410.55, direction: "dr", merchant: "Amazon", description: "AMAZON MARKETPLACE — HIGH VALUE ELECTRONICS", category: "Shopping", status: "flagged", flagReason: "Unusual amount vs 90-day average", occurredAt: D(2025, 2, 12, 22) });
  const diegoChk = otherAcctIdx[20][0];
  txn({ accountIdx: diegoChk, type: "withdrawal", amount: 2500.0, direction: "dr", description: "ATM WITHDRAWAL — LAGOS, NG", category: "Cash", status: "flagged", flagReason: "Geo anomaly: card used in Lagos, NG; customer resides in Boston, MA", occurredAt: D(2025, 2, 9, 3) });
  // one pending transaction (maker-checker: transfer awaiting second approval)
  const sofiaChk = otherAcctIdx[7][0];
  txn({ accountIdx: sofiaChk, type: "transfer", amount: 12000.0, direction: "dr", description: "WIRE OUT — ESCROW PAYMENT (PENDING SECOND APPROVAL)", category: "Transfer", status: "pending", occurredAt: D(2025, 2, 13, 16), createdBy: "Jordan Ellis" });

  /* reconcile Elena's anchor balances by adjusting first credit txn */
  function reconcile(acctIdx: number, target: number) {
    const rel = txns.filter((t) => t.accountIdx === acctIdx);
    const net = rel.reduce((a, t) => a + (t.direction === "cr" ? t.amount : -t.amount), 0);
    const delta = target - net;
    const first = [...rel].sort((a, b) => a.occurredAt.getTime() - b.occurredAt.getTime())[0];
    first.direction = delta >= 0 ? "cr" : "dr";
    first.amount = +(first.amount + Math.abs(delta)).toFixed(2);
  }
  reconcile(eCheck, 12450.33);
  reconcile(eSave, 48920.15);
  reconcile(eCredit, -2340.18);
  // clamp any random dates past "today" (Feb 14, 2025)
  for (const t of txns) {
    if (t.occurredAt > TODAY) t.occurredAt = new Date(t.occurredAt.getTime() - 14 * 86400000);
  }

  /* insert accounts; compute balances for non-anchor accounts */
  const netByAcct = new Map<number, number>();
  for (const t of txns) {
    netByAcct.set(t.accountIdx, (netByAcct.get(t.accountIdx) ?? 0) + (t.direction === "cr" ? t.amount : -t.amount));
  }
  const anchors = new Set([eCheck, eSave, eCredit, eMortgage]);
  for (let i = 0; i < acctDefs.length; i++) {
    if (!anchors.has(i)) {
      acctDefs[i].balance = +((netByAcct.get(i) ?? 0)).toFixed(2);
    } else if (i !== eMortgage) {
      acctDefs[i].balance = +((netByAcct.get(i) ?? 0)).toFixed(2);
    }
  }
  await db.insert(s.accounts).values(
    acctDefs.map((a) => ({
      accountNumber: a.accountNumber, last4: a.last4, type: a.type,
      nickname: a.nickname, balance: money(a.balance), currency: "USD",
      status: a.status ?? "active", apy: a.apy ?? null,
      creditLimit: a.creditLimit != null ? money(a.creditLimit) : null,
      customerId: custId(a.custIdx), branchId: branchId(a.branchIdx), openedAt: a.openedAt,
    })),
  );
  const acctRows = await db.select().from(s.accounts);
  const acctId = (idx: number) => acctRows[idx].id;

  /* insert transactions with stable txnIds */
  const perDay = new Map<string, number>();
  await db.insert(s.transactions).values(
    txns.map((t) => {
      const day = t.occurredAt.toISOString().slice(0, 10).replace(/-/g, "");
      const n = (perDay.get(day) ?? 0) + 1;
      perDay.set(day, n);
      return {
        txnId: `TXN-${t.occurredAt.getUTCFullYear()}-${day.slice(4)}-${String(n).padStart(4, "0")}`,
        accountId: acctId(t.accountIdx),
        counterAccountId: t.counterAccountIdx != null ? acctId(t.counterAccountIdx) : null,
        type: t.type, amount: money(t.amount), direction: t.direction,
        merchant: t.merchant ?? null, description: t.description, category: t.category,
        status: t.status ?? "posted", flagReason: t.flagReason ?? null,
        occurredAt: t.occurredAt, createdBy: t.createdBy ?? "system",
      };
    }),
  );
  const txnRows = await db.select().from(s.transactions);
  console.log(`Seeded ${acctRows.length} accounts, ${txnRows.length} transactions`);

  /* ---------- cards ---------- */
  await db.insert(s.cards).values([
    { last4: "2210", fullNumber: "4102 8890 1145 2210", type: "debit", network: "visa", holder: "ELENA VASQUEZ", customerId: elena.id, accountId: acctId(eCheck), status: "active", expiresAt: "2028-03-31", issuedAt: "2023-03-10" },
    { last4: "7712", fullNumber: "4485 2910 3384 7712", type: "credit", network: "visa", holder: "ELENA VASQUEZ", customerId: elena.id, accountId: acctId(eCredit), status: "active", creditLimit: "15000.00", availableCredit: "12659.82", expiresAt: "2027-09-30", issuedAt: "2019-09-15" },
    { last4: "5561", fullNumber: "4102 8890 7712 5561", type: "debit", network: "visa", holder: "MAYA ORTIZ", customerId: custId(1), accountId: acctId(otherAcctIdx[1][0]), status: "active", expiresAt: "2027-06-30", issuedAt: "2022-06-01" },
    { last4: "8834", fullNumber: "5424 1900 2234 8834", type: "debit", network: "mastercard", holder: "TOM OKAFOR", customerId: custId(4), accountId: acctId(otherAcctIdx[4][0]), status: "frozen", expiresAt: "2026-11-30", issuedAt: "2021-11-12" },
    { last4: "3308", fullNumber: "4102 8890 5541 3308", type: "debit", network: "visa", holder: "HENRY ABARA", customerId: custId(26), accountId: acctId(otherAcctIdx[26][0]), status: "blocked", expiresAt: "2026-02-28", issuedAt: "2021-02-19" },
    { last4: "9921", fullNumber: "4485 2910 7761 9921", type: "credit", network: "visa", holder: "SOFIA PETROVA", customerId: custId(7), accountId: acctId(otherAcctIdx[7][0]), status: "active", creditLimit: "10000.00", availableCredit: "9450.00", expiresAt: "2028-01-31", issuedAt: "2023-01-09" },
    // pending issuance requests
    { last4: "1187", fullNumber: "4102 8890 9023 1187", type: "debit", network: "visa", holder: "PRIYA NAIR", customerId: custId(13), accountId: acctId(otherAcctIdx[13][0]), status: "pending", expiresAt: "2029-02-28", issuedAt: "2025-02-12" },
    { last4: "6640", fullNumber: "4485 2910 3390 6640", type: "credit", network: "visa", holder: "DIEGO FUENTES", customerId: custId(20), accountId: acctId(otherAcctIdx[20][0]), status: "pending", creditLimit: "5000.00", availableCredit: "5000.00", expiresAt: "2029-02-28", issuedAt: "2025-02-13" },
  ]);

  /* ---------- payees (Elena) ---------- */
  await db.insert(s.payees).values([
    { customerId: elena.id, name: "Harbourview Properties LLC (Rent)", accountNumber: "8800112233", bank: "Zelle", createdAt: D(2022, 4, 2) },
    { customerId: elena.id, name: "Con Edison", accountNumber: "CE-00981422", bank: "Meridian Bill Pay", createdAt: D(2020, 9, 14) },
    { customerId: elena.id, name: "Maya Ortiz", accountNumber: "1100005561", bank: "Zelle", createdAt: D(2023, 1, 25) },
  ]);

  /* ---------- loans ---------- */
  // Elena's active 30-yr fixed mortgage LN-2019-0442
  const rM = 6.125 / 1200;
  const pmt = 360000 * (rM / (1 - Math.pow(1 + rM, -360))); // ≈ 2187.60
  const [elenaLoan] = await db.insert(s.loans).values({
    loanNo: "LN-2019-0442", customerId: elena.id, productId: mtgProd.id,
    principal: "360000.00", remainingBalance: "312400.00", rateApr: "6.125",
    termMonths: 360, monthlyPayment: money(pmt), purpose: "Home purchase — 27 Beacon St Apt 4B, Boston MA",
    status: "active", appliedAt: D(2019, 4, 8), decidedAt: D(2019, 4, 30), decidedBy: "Marcus Chen",
    disbursementAt: D(2019, 6, 20), branchId: branchId(0),
  }).$returningId();
  // 24 payments paid + 12 upcoming; amortize backwards so remaining == 312,400 today
  const pays: Array<Record<string, unknown>> = [];
  const schedule: Array<{ due: Date; status: "paid" | "due"; paidAt: Date | null }> = [];
  for (let i = 24; i >= 1; i--) {
    const dt = new Date(Date.UTC(2025, 1 - i + 1, 1));
    schedule.push({ due: dt, status: "paid", paidAt: dt });
  }
  for (let i = 1; i <= 12; i++) {
    schedule.push({ due: new Date(Date.UTC(2025, 1 + i, 1)), status: "due", paidAt: null });
  }
  let balBack = 312400;
  for (let i = 0; i < 24; i++) {
    balBack = (balBack + pmt) / (1 + rM); // inverse amortization step
  }
  let runBal = balBack;
  for (const sch of schedule) {
    const interest = +(runBal * rM).toFixed(2);
    const principalPart = +(pmt - interest).toFixed(2);
    pays.push({
      loanId: elenaLoan.id, dueDate: sch.due.toISOString().slice(0, 10),
      amount: money(pmt), principalPart: money(principalPart), interestPart: money(interest),
      status: sch.status, paidAt: sch.paidAt,
    });
    runBal = +(runBal - principalPart).toFixed(2);
  }
  await db.insert(s.loanPayments).values(pays as never);

  /* other loans across every lifecycle state */
  const otherLoans = await db.insert(s.loans).values([
    { loanNo: "LN-2023-0118", customerId: custId(4), productId: autoProd.id, principal: "28500.00", remainingBalance: "14220.50", rateApr: "7.250", termMonths: 60, monthlyPayment: "567.84", purpose: "Auto purchase — 2023 Honda CR-V", status: "active", appliedAt: D(2023, 5, 2), decidedAt: D(2023, 5, 5), decidedBy: "Priya Sharma", disbursementAt: D(2023, 5, 9), branchId: branchId(1) },
    { loanNo: "LN-2025-0061", customerId: custId(8), productId: plProd.id, principal: "15000.00", remainingBalance: "15000.00", rateApr: "9.990", termMonths: 48, monthlyPayment: "380.35", purpose: "Home renovation", status: "pending", appliedAt: D(2025, 2, 10), branchId: branchId(0) },
    { loanNo: "LN-2025-0064", customerId: custId(11), productId: autoProd.id, principal: "22000.00", remainingBalance: "22000.00", rateApr: "7.250", termMonths: 60, monthlyPayment: "438.31", purpose: "Auto purchase — 2021 Toyota Camry", status: "pending", appliedAt: D(2025, 2, 12), branchId: branchId(0) },
    { loanNo: "LN-2025-0052", customerId: custId(6), productId: plProd.id, principal: "8000.00", remainingBalance: "8000.00", rateApr: "9.990", termMonths: 36, monthlyPayment: "258.12", purpose: "Debt consolidation", status: "approved", appliedAt: D(2025, 2, 4), decidedAt: D(2025, 2, 8), decidedBy: "Priya Sharma", branchId: branchId(2) },
    { loanNo: "LN-2024-0987", customerId: custId(24), productId: plProd.id, principal: "12000.00", remainingBalance: "12000.00", rateApr: "9.990", termMonths: 48, monthlyPayment: "304.28", purpose: "Medical expenses", status: "rejected", appliedAt: D(2024, 12, 18), decidedAt: D(2024, 12, 22), decidedBy: "Marcus Chen", branchId: branchId(1) },
    { loanNo: "LN-2022-0331", customerId: custId(18), productId: autoProd.id, principal: "31000.00", remainingBalance: "18940.77", rateApr: "7.250", termMonths: 60, monthlyPayment: "617.21", purpose: "Auto purchase — 2022 Ford F-150", status: "delinquent", appliedAt: D(2022, 9, 12), decidedAt: D(2022, 9, 15), decidedBy: "Marcus Chen", disbursementAt: D(2022, 9, 20), branchId: branchId(1) },
    { loanNo: "LN-2020-0205", customerId: custId(22), productId: plProd.id, principal: "20000.00", remainingBalance: "0.00", rateApr: "9.990", termMonths: 60, monthlyPayment: "424.94", purpose: "Home improvement", status: "paid_off", appliedAt: D(2020, 2, 10), decidedAt: D(2020, 2, 14), decidedBy: "Marcus Chen", disbursementAt: D(2020, 2, 18), branchId: branchId(2) },
    { loanNo: "LN-2021-0770", customerId: custId(16), productId: mtgProd.id, principal: "415000.00", remainingBalance: "389550.20", rateApr: "6.125", termMonths: 360, monthlyPayment: "2522.10", purpose: "Home purchase — 12 Battery St, Boston MA", status: "active", appliedAt: D(2021, 7, 1), decidedAt: D(2021, 7, 28), decidedBy: "Priya Sharma", disbursementAt: D(2021, 9, 3), branchId: branchId(0) },
  ]).$returningId();

  // a few payments for the delinquent auto loan (some overdue)
  const delinqId = otherLoans[5].id;
  await db.insert(s.loanPayments).values([
    { loanId: delinqId, dueDate: "2024-12-01", amount: "617.21", principalPart: "430.10", interestPart: "187.11", status: "paid", paidAt: D(2024, 12, 2, 10) },
    { loanId: delinqId, dueDate: "2025-01-01", amount: "617.21", principalPart: "432.70", interestPart: "184.51", status: "overdue", paidAt: null },
    { loanId: delinqId, dueDate: "2025-02-01", amount: "617.21", principalPart: "435.32", interestPart: "181.89", status: "overdue", paidAt: null },
    { loanId: delinqId, dueDate: "2025-03-01", amount: "617.21", principalPart: "437.95", interestPart: "179.26", status: "due", paidAt: null },
  ]);

  /* ---------- KYC cases ---------- */
  await db.insert(s.kycCases).values([
    { caseNo: "KYC-2016-0101", customerId: elena.id, level: "standard", status: "approved", idDocType: "US Passport", riskRating: "low", submittedAt: D(2016, 3, 11), reviewedBy: "Marcus Chen", reviewedAt: D(2016, 3, 12), notes: "Verified via passport + utility bill. Periodic refresh clean." },
    { caseNo: "KYC-2024-0442", customerId: custId(12), level: "standard", status: "approved", idDocType: "Driver's License", riskRating: "low", submittedAt: D(2024, 11, 2), reviewedBy: "Priya Sharma", reviewedAt: D(2024, 11, 4) },
    { caseNo: "KYC-2025-0009", customerId: custId(12), level: "enhanced", status: "under_review", idDocType: "Driver's License", riskRating: "high", submittedAt: D(2025, 2, 6), notes: "EDD triggered: high-velocity international wires in Jan 2025. Awaiting source-of-funds documentation.", },
    { caseNo: "KYC-2025-0011", customerId: custId(13), level: "standard", status: "pending", idDocType: "Passport (Foreign)", riskRating: "medium", submittedAt: D(2025, 2, 10), notes: "New customer onboarding." },
    { caseNo: "KYC-2025-0013", customerId: custId(15), level: "standard", status: "pending", idDocType: "Driver's License", riskRating: "low", submittedAt: D(2025, 2, 11) },
    { caseNo: "KYC-2025-0015", customerId: custId(20), level: "enhanced", status: "under_review", idDocType: "Driver's License", riskRating: "high", submittedAt: D(2025, 2, 3), notes: "Geo-anomaly alerts on linked debit card; verify residency." },
    { caseNo: "KYC-2024-0398", customerId: custId(24), level: "standard", status: "rejected", idDocType: "Driver's License", riskRating: "medium", submittedAt: D(2024, 10, 9), reviewedBy: "Marcus Chen", reviewedAt: D(2024, 10, 12), rejectionReason: "ID document expired; proof of address illegible." },
    { caseNo: "KYC-2022-0207", customerId: custId(6), level: "standard", status: "approved", idDocType: "US Passport", riskRating: "low", submittedAt: D(2022, 8, 14), reviewedBy: "Priya Sharma", reviewedAt: D(2022, 8, 16) },
    { caseNo: "KYC-2025-0018", customerId: custId(27), level: "standard", status: "pending", idDocType: "Driver's License", riskRating: "low", submittedAt: D(2025, 2, 13) },
  ]);

  /* ---------- AML alerts ---------- */
  const flaggedTxns = txnRows.filter((t) => t.status === "flagged");
  const elenaWire = txnRows.find((t) => t.description.includes("88X221"))!;
  const henryWire = txnRows.find((t) => t.description.includes("77Q109"))!;
  const henryCash = txnRows.find((t) => t.description.includes("CASH DEPOSIT — BRANCH BR-002"))!;
  const tomPurchase = txnRows.find((t) => t.description.includes("HIGH VALUE ELECTRONICS"))!;
  const diegoAtm = txnRows.find((t) => t.description.includes("LAGOS"))!;
  await db.insert(s.alerts).values([
    { alertNo: "AML-2025-0141", type: "structuring", severity: "critical", customerId: elena.id, transactionId: elenaWire.id, status: "investigating", description: "Wire of $9,800 to INT'L TRANSFER SARL just under $10k CTR threshold; second sub-threshold wire this quarter.", createdAt: D(2025, 2, 10, 12), assignedTo: "Priya Sharma" },
    { alertNo: "AML-2025-0132", type: "structuring", severity: "high", customerId: custId(26), transactionId: henryWire.id, status: "open", description: "Outbound wire $9,600 under CTR threshold following large cash deposit.", createdAt: D(2025, 2, 7, 11), assignedTo: "Marcus Chen" },
    { alertNo: "AML-2025-0129", type: "high_velocity", severity: "high", customerId: custId(26), transactionId: henryCash.id, status: "investigating", description: "3rd cash deposit under $10k within 30 days (velocity rule HV-3).", createdAt: D(2025, 2, 5, 15), assignedTo: "Priya Sharma" },
    { alertNo: "AML-2025-0148", type: "unusual_amount", severity: "medium", customerId: custId(4), transactionId: tomPurchase.id, status: "open", description: "Purchase $2,410.55 is 6.2× the 90-day average card spend.", createdAt: D(2025, 2, 12, 23) },
    { alertNo: "AML-2025-0137", type: "geo_anomaly", severity: "high", customerId: custId(20), transactionId: diegoAtm.id, status: "investigating", description: "ATM withdrawal in Lagos, NG; customer resides in Boston, MA; no travel notice on file.", createdAt: D(2025, 2, 9, 4), assignedTo: "Marcus Chen" },
    { alertNo: "AML-2025-0115", type: "high_velocity", severity: "low", customerId: custId(7), transactionId: null, status: "open", description: "Elevated P2P transfer frequency (14 Zelle sends in 7 days).", createdAt: D(2025, 2, 1, 9) },
  ]);
  void flaggedTxns;

  /* ---------- notifications (Elena) ---------- */
  await db.insert(s.notifications).values([
    { customerId: elena.id, title: "Unusual activity on Everyday Checking", body: "A wire transfer of $9,800.00 to INT'L TRANSFER SARL was flagged for review. If you did not authorize this, contact us immediately.", type: "warning", read: false, createdAt: D(2025, 2, 10, 12) },
    { customerId: elena.id, title: "Your February statement is ready", body: "Your January statement for Everyday Checking ••••4821 is available to download.", type: "info", read: false, createdAt: D(2025, 2, 1, 9) },
    { customerId: elena.id, title: "Mortgage payment received", body: "Payment of $2,187.60 toward LN-2019-0442 was received on Feb 5, 2025.", type: "info", read: true, createdAt: D(2025, 2, 5, 10) },
    { customerId: elena.id, title: "Payroll deposit received", body: "$3,420.00 from NORTHWIND DIGITAL was deposited to Everyday Checking ••••4821.", type: "info", read: true, createdAt: D(2025, 2, 14, 9) },
    { customerId: elena.id, title: "Action required: verify your card", body: "Please confirm recent activity on Platinum Rewards ••••7712 to keep your card active.", type: "action", read: false, createdAt: D(2025, 2, 12, 8) },
    { customerId: elena.id, title: "Savings rate update", body: "High-Yield Savings ••••9034 continues to earn 4.35% APY.", type: "info", read: true, createdAt: D(2025, 1, 31, 12) },
  ]);

  /* ---------- audit log (hash chain) ---------- */
  type AuditSeed = { actorType: "customer" | "staff" | "system"; actorName: string; action: string; entityType: string; entityId: string; detail?: string; at: Date };
  const auditSeeds: AuditSeed[] = [
    { actorType: "staff", actorName: "Marcus Chen", action: "customer.kyc_approved", entityType: "customer", entityId: "CUS-1001", detail: "KYC approved for Elena Vasquez (US Passport).", at: D(2016, 3, 12, 10) },
    { actorType: "system", actorName: "system", action: "account.opened", entityType: "account", entityId: "1100004821", detail: "Everyday Checking opened at Downtown HQ.", at: D(2016, 3, 11, 11) },
    { actorType: "staff", actorName: "Marcus Chen", action: "loan.approved", entityType: "loan", entityId: "LN-2019-0442", detail: "30-yr Fixed Mortgage $360,000 approved.", at: D(2019, 4, 30, 14) },
    { actorType: "system", actorName: "system", action: "loan.disbursed", entityType: "loan", entityId: "LN-2019-0442", detail: "Disbursement of $360,000 to escrow.", at: D(2019, 6, 20, 9) },
    { actorType: "staff", actorName: "Priya Sharma", action: "card.blocked", entityType: "card", entityId: "card-3308", detail: "Debit card ••••3308 blocked — suspected compromise (Henry Abara).", at: D(2025, 2, 8, 9) },
    { actorType: "customer", actorName: "Tom Okafor", action: "card.frozen", entityType: "card", entityId: "card-8834", detail: "Card frozen via online banking.", at: D(2025, 2, 11, 21) },
    { actorType: "customer", actorName: "Elena Vasquez", action: "transfer.initiated", entityType: "transaction", entityId: elenaWire.txnId, detail: "Wire $9,800.00 to INT'L TRANSFER SARL.", at: D(2025, 2, 10, 11) },
    { actorType: "system", actorName: "aml-engine", action: "alert.created", entityType: "alert", entityId: "AML-2025-0141", detail: "Structuring rule ST-2 triggered.", at: D(2025, 2, 10, 12) },
    { actorType: "staff", actorName: "Priya Sharma", action: "alert.assigned", entityType: "alert", entityId: "AML-2025-0141", detail: "Alert assigned to Priya Sharma for investigation.", at: D(2025, 2, 10, 13) },
    { actorType: "staff", actorName: "Jordan Ellis", action: "transfer.initiated", entityType: "transaction", entityId: "WIRE-12000-ESCROW", detail: "Wire $12,000.00 for Sofia Petrova — maker entry.", at: D(2025, 2, 13, 16) },
    { actorType: "system", actorName: "system", action: "transfer.pending_second_approval", entityType: "transaction", entityId: "WIRE-12000-ESCROW", detail: "Amount exceeds teller limit $10,000 — awaiting manager approval (maker-checker).", at: D(2025, 2, 13, 16, 5) },
    { actorType: "staff", actorName: "Priya Sharma", action: "loan.approved", entityType: "loan", entityId: "LN-2025-0052", detail: "Personal Loan $8,000 approved (Liam Donnelly).", at: D(2025, 2, 8, 11) },
    { actorType: "staff", actorName: "Marcus Chen", action: "loan.rejected", entityType: "loan", entityId: "LN-2024-0987", detail: "Rejected: insufficient income documentation.", at: D(2024, 12, 22, 15) },
    { actorType: "staff", actorName: "Priya Sharma", action: "kyc.review_started", entityType: "kycCase", entityId: "KYC-2025-0009", detail: "EDD case opened; source-of-funds requested.", at: D(2025, 2, 7, 10) },
    { actorType: "system", actorName: "system", action: "interest.credited", entityType: "account", entityId: "1100009034", detail: "Monthly interest credited to High-Yield Savings.", at: D(2025, 1, 28, 6) },
    { actorType: "customer", actorName: "Elena Vasquez", action: "profile.updated", entityType: "customer", entityId: "CUS-1001", detail: "Phone number updated via online banking.", at: D(2025, 1, 20, 19) },
  ];
  // pad to ~50 entries with routine system events
  const routineActions = [
    ["session.login", "user", "elena.vasquez@demo.meridian", "Customer login via web."],
    ["statement.generated", "account", "1100004821", "Monthly e-statement generated."],
    ["session.login", "user", "priya.sharma@meridian.bank", "Staff login via console."],
    ["txn.posted", "account", "1100004821", "Batch posting completed."],
    ["notification.sent", "customer", "CUS-1001", "Push notification delivered."],
  ] as const;
  let padDate = D(2024, 11, 2, 8);
  while (auditSeeds.length < 50) {
    const [action, et, eid, detail] = routineActions[auditSeeds.length % routineActions.length];
    auditSeeds.push({ actorType: action === "session.login" ? "staff" : "system", actorName: action === "session.login" ? String(eid) : "system", action, entityType: et, entityId: String(eid), detail, at: padDate });
    padDate = new Date(padDate.getTime() + 1000 * 60 * 60 * 26);
  }
  auditSeeds.sort((a, b) => a.at.getTime() - b.at.getTime());
  let prevHash = "0".repeat(64);
  const auditRows = auditSeeds.map((a) => {
    const payload = `${a.at.toISOString()}|${a.actorType}|${a.actorName}|${a.action}|${a.entityType}|${a.entityId}|${a.detail ?? ""}`;
    const hash = sha256(prevHash + payload);
    const row = {
      actorType: a.actorType, actorName: a.actorName, action: a.action,
      entityType: a.entityType, entityId: a.entityId, detail: a.detail ?? null,
      prevHash, hash, createdAt: a.at,
    };
    prevHash = hash;
    return row;
  });
  await db.insert(s.auditLog).values(auditRows);

  const counts = {
    branches: BRANCHES.length, customers: CUSTOMERS.length, users: 5,
    employees: EMPLOYEES.length, accounts: acctRows.length, transactions: txnRows.length,
    loans: 1 + otherLoans.length, auditLog: auditRows.length,
  };
  console.log("Seed complete:", counts);
  console.log("Anchor check — Elena balances:", {
    checking: acctDefs[eCheck].balance, savings: acctDefs[eSave].balance, credit: acctDefs[eCredit].balance,
  });
  process.exit(0);
}

main().catch((e) => { console.error(e); process.exit(1); });
