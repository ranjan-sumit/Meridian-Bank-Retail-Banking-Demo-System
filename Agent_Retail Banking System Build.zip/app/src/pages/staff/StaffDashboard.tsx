import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate } from "react-router";
import { motion } from "framer-motion";
import {
  Area,
  AreaChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Line,
  LineChart,
} from "recharts";
import { format } from "date-fns";
import { ArrowRight } from "lucide-react";
import { trpc } from "@/providers/trpc";
import KpiCard from "@/components/shared/KpiCard";
import StatusBadge from "@/components/shared/StatusBadge";
import { formatMoney } from "@/components/shared/MoneyText";
import StaffLayout from "@/components/staff/StaffLayout";
import { cn } from "@/lib/utils";

/** Animated count-up for KPI values. */
function useCountUp(target: number, durationMs = 900): number {
  const [value, setValue] = useState(0);
  const raf = useRef<number>(0);
  useEffect(() => {
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / durationMs);
      const eased = 1 - Math.pow(1 - t, 3);
      setValue(target * eased);
      if (t < 1) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [target, durationMs]);
  return value;
}

function compactMoney(v: number): string {
  if (Math.abs(v) >= 1_000_000) return `$${(v / 1_000_000).toFixed(1)}M`;
  if (Math.abs(v) >= 10_000) return `$${(v / 1_000).toFixed(1)}K`;
  return formatMoney(v);
}

function Sparkline({ data, color }: { data: { day: string; total: number }[]; color: string }) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data} margin={{ top: 2, bottom: 2, left: 0, right: 0 }}>
        <Line type="monotone" dataKey="total" stroke={color} strokeWidth={1.5} dot={false} isAnimationActive />
      </LineChart>
    </ResponsiveContainer>
  );
}

function KycStatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending: "Pending",
    under_review: "Under Review",
    approved: "Approved",
    rejected: "Rejected",
  };
  return <StatusBadge dark status={map[status] ?? status} />;
}

const CHANNELS = [
  { name: "ACH", value: 38, color: "#2DD4A8" },
  { name: "Card", value: 31, color: "#60A5FA" },
  { name: "Zelle", value: 14, color: "#FBBF24" },
  { name: "Wire", value: 9, color: "#A78BFA" },
  { name: "ATM", value: 8, color: "#8B9BB0" },
];

const BRANCHES = [
  { code: "BR-001", name: "Downtown HQ", manager: "Priya Sharma", deposits: 198_200_000, opened: 14, staff: 22 },
  { code: "BR-002", name: "Westside", manager: "Omar Farah", deposits: 121_500_000, opened: 8, staff: 13 },
  { code: "BR-003", name: "Harbor Point", manager: "Lisa Grant", deposits: 92_900_000, opened: 5, staff: 11 },
];

const SEVERITY_COLOR: Record<string, string> = {
  critical: "text-red-400",
  high: "text-red-300",
  medium: "text-amber-300",
  low: "text-staff-subtle",
};

function Panel({ title, action, children, className }: { title: string; action?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-xl border border-staff-border bg-staff-panel", className)}>
      <header className="flex items-center justify-between border-b border-staff-border px-4 py-3">
        <h2 className="text-[13px] font-semibold text-staff-text">{title}</h2>
        {action}
      </header>
      {children}
    </section>
  );
}

function ViewAll({ to, label }: { to: string; label: string }) {
  return (
    <Link to={to} className="inline-flex items-center gap-1 text-[11.5px] font-medium text-staff-accent hover:underline">
      {label} <ArrowRight className="h-3 w-3" />
    </Link>
  );
}

function DashboardBody() {
  const navigate = useNavigate();
  const kpis = trpc.staff.dashboardKpis.useQuery();
  const kycQueue = trpc.staff.kycQueue.useQuery({});
  const loanQueue = trpc.staff.loanQueue.useQuery({ status: "pending" });
  const alerts = trpc.staff.listAlerts.useQuery({ status: "open" });

  useEffect(() => {
    for (const q of [kpis, kycQueue, loanQueue, alerts]) {
      if (q.error) {
        // eslint-disable-next-line no-console
        console.error(q.error);
      }
    }
  }, [kpis.error, kycQueue.error, loanQueue.error, alerts.error, kpis, kycQueue, loanQueue, alerts]);

  const d = kpis.data;
  const deposits = useCountUp(d?.totalDeposits ?? 0);
  const activeLoans = useCountUp(d?.activeLoans ?? 0);
  const pendingKyc = useCountUp(d?.pendingKyc ?? 0);
  const flagged = useCountUp((d?.flaggedTxns ?? 0) + (d?.openAlerts ?? 0));

  const sparkData = useMemo(() => d?.depositSeries ?? [], [d]);

  return (
    <div className="mx-auto max-w-[1400px] space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-lg font-semibold text-staff-text">Operations Dashboard</h1>
          <p className="text-[12px] text-staff-subtle">Friday, February 14, 2025 · All branches · DEMO data</p>
        </div>
      </div>

      {/* KPI row */}
      {kpis.isLoading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-[118px] animate-pulse rounded-xl border border-staff-border bg-staff-panel" />
          ))}
        </div>
      ) : kpis.isError ? (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-[13px] text-red-300">
          Failed to load dashboard metrics. Please retry.
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {[
            <KpiCard
              key="dep"
              dark
              label="Total Deposits"
              value={compactMoney(deposits)}
              delta={2.1}
              deltaLabel="vs Jan"
              sparkline={<Sparkline data={sparkData} color="#2DD4A8" />}
            />,
            <KpiCard
              key="loans"
              dark
              label="Active Loans"
              value={Math.round(activeLoans).toLocaleString()}
              delta={0.8}
              deltaLabel={`${compactMoney(d?.loanVolume ?? 0)} book`}
              sparkline={<Sparkline data={sparkData} color="#60A5FA" />}
            />,
            <KpiCard
              key="kyc"
              dark
              label="Pending KYC"
              value={
                <span className="flex items-center gap-2">
                  {Math.round(pendingKyc)}
                  <span className="rounded-full bg-amber-400/10 px-2 py-0.5 text-[10.5px] font-medium text-amber-300">
                    review queue
                  </span>
                </span>
              }
              sparkline={<Sparkline data={sparkData} color="#FBBF24" />}
            />,
            <KpiCard
              key="flag"
              dark
              label="Flagged Transactions"
              value={
                <span className="flex items-center gap-2">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-60" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-red-400" />
                  </span>
                  {Math.round(flagged)}
                  <span className="rounded-full bg-red-400/10 px-2 py-0.5 text-[10.5px] font-medium text-red-300">
                    open alerts
                  </span>
                </span>
              }
              sparkline={<Sparkline data={sparkData} color="#F87171" />}
            />,
          ].map((card, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.07 }}
            >
              {card}
            </motion.div>
          ))}
        </div>
      )}

      {/* Charts row */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Panel title="Deposits — last 30 days" className="xl:col-span-2">
          <div className="h-[260px] p-4">
            {kpis.isLoading ? (
              <div className="h-full animate-pulse rounded-lg bg-staff-raised" />
            ) : sparkData.length === 0 ? (
              <div className="flex h-full items-center justify-center text-[12.5px] text-staff-subtle">
                No deposit activity in the last 30 days.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={sparkData} margin={{ top: 6, right: 8, bottom: 0, left: 0 }}>
                  <defs>
                    <linearGradient id="depGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#2DD4A8" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#2DD4A8" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis
                    dataKey="day"
                    tick={{ fill: "#8B9BB0", fontSize: 10 }}
                    tickFormatter={(v: string) => format(new Date(v + "T00:00:00"), "MMM d")}
                    axisLine={{ stroke: "#263343" }}
                    tickLine={false}
                    minTickGap={24}
                  />
                  <YAxis
                    tick={{ fill: "#8B9BB0", fontSize: 10 }}
                    tickFormatter={(v: number) => compactMoney(v)}
                    axisLine={false}
                    tickLine={false}
                    width={64}
                  />
                  <Tooltip
                    contentStyle={{ background: "#1C2735", border: "1px solid #263343", borderRadius: 8, fontSize: 12 }}
                    labelStyle={{ color: "#8B9BB0" }}
                    formatter={(v) => [formatMoney(Number(v)), "Deposits"]}
                    labelFormatter={(v) => format(new Date(String(v) + "T00:00:00"), "MMM d, yyyy")}
                  />
                  <Area
                    type="monotone"
                    dataKey="total"
                    stroke="#2DD4A8"
                    strokeWidth={2}
                    fill="url(#depGrad)"
                    animationDuration={1000}
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </Panel>

        <Panel title="Transaction volume by channel">
          <div className="flex h-[260px] items-center p-4">
            <div className="h-full w-1/2">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={CHANNELS}
                    dataKey="value"
                    nameKey="name"
                    innerRadius="58%"
                    outerRadius="88%"
                    paddingAngle={2}
                    strokeWidth={0}
                  >
                    {CHANNELS.map((c) => (
                      <Cell key={c.name} fill={c.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: "#1C2735", border: "1px solid #263343", borderRadius: 8, fontSize: 12 }}
                    formatter={(v) => [`${v}%`, "Share"]}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <ul className="w-1/2 space-y-2">
              {CHANNELS.map((c) => (
                <li key={c.name} className="flex items-center gap-2 text-[12px]">
                  <span className="h-2 w-2 rounded-sm" style={{ background: c.color }} />
                  <span className="flex-1 text-staff-subtle">{c.name}</span>
                  <span className="font-mono tabular-nums text-staff-text">{c.value}%</span>
                </li>
              ))}
            </ul>
          </div>
        </Panel>
      </div>

      {/* Work queues */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Panel title="KYC review queue" action={<ViewAll to="/staff/kyc" label={`View all ${d?.pendingKyc ?? ""}`} />}>
          <ul className="divide-y divide-staff-border">
            {kycQueue.isLoading &&
              Array.from({ length: 4 }).map((_, i) => (
                <li key={i} className="px-4 py-3"><div className="h-8 animate-pulse rounded bg-staff-raised" /></li>
              ))}
            {kycQueue.data?.length === 0 && (
              <li className="px-4 py-6 text-center text-[12.5px] text-staff-subtle">Queue is clear — no pending cases.</li>
            )}
            {kycQueue.data?.slice(0, 5).map((k, i) => (
              <motion.li
                key={k.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: i * 0.05 }}
              >
                <button
                  type="button"
                  onClick={() => navigate("/staff/kyc")}
                  className="flex w-full items-center gap-3 px-4 py-2.5 text-left transition hover:bg-staff-hover"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-medium text-staff-text">
                      {k.customer.firstName} {k.customer.lastName}
                      {k.riskRating === "high" && (
                        <span className="ml-2 rounded bg-red-400/10 px-1.5 py-0.5 text-[10px] font-semibold text-red-300">HIGH</span>
                      )}
                    </p>
                    <p className="text-[11px] text-staff-subtle">
                      {k.level === "enhanced" ? "Enhanced Due Diligence" : "Standard"} · submitted{" "}
                      {format(new Date(k.submittedAt), "MMM d")}
                    </p>
                  </div>
                  <KycStatusBadge status={k.status} />
                </button>
              </motion.li>
            ))}
          </ul>
        </Panel>

        <Panel title="Loan approvals" action={<ViewAll to="/staff/loans" label="View queue" />}>
          <ul className="divide-y divide-staff-border">
            {loanQueue.isLoading &&
              Array.from({ length: 3 }).map((_, i) => (
                <li key={i} className="px-4 py-3"><div className="h-8 animate-pulse rounded bg-staff-raised" /></li>
              ))}
            {loanQueue.data?.length === 0 && (
              <li className="px-4 py-6 text-center text-[12.5px] text-staff-subtle">No pending applications.</li>
            )}
            {loanQueue.data?.slice(0, 4).map((l, i) => (
              <motion.li
                key={l.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: i * 0.05 }}
              >
                <button
                  type="button"
                  onClick={() => navigate("/staff/loans")}
                  className="flex w-full items-center gap-3 px-4 py-2.5 text-left transition hover:bg-staff-hover"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-medium text-staff-text">
                      <span className="font-mono text-[11.5px] text-staff-accent">{l.loanNo}</span> {l.customerName}
                    </p>
                    <p className="text-[11px] text-staff-subtle">
                      {formatMoney(Number(l.principal))} · {l.product.name}
                    </p>
                  </div>
                  <StatusBadge dark status="Pending" />
                </button>
              </motion.li>
            ))}
          </ul>
        </Panel>

        <Panel title="Recent flagged activity" action={<ViewAll to="/staff/monitoring" label="Open monitoring" />}>
          <ul className="divide-y divide-staff-border">
            {alerts.isLoading &&
              Array.from({ length: 3 }).map((_, i) => (
                <li key={i} className="px-4 py-3"><div className="h-8 animate-pulse rounded bg-staff-raised" /></li>
              ))}
            {alerts.data?.length === 0 && (
              <li className="px-4 py-6 text-center text-[12.5px] text-staff-subtle">No open alerts.</li>
            )}
            {alerts.data?.slice(0, 4).map((a, i) => (
              <motion.li
                key={a.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: i * 0.05 }}
              >
                <button
                  type="button"
                  onClick={() => navigate("/staff/monitoring")}
                  className={cn(
                    "flex w-full items-center gap-3 border-l-[3px] px-4 py-2.5 text-left transition hover:bg-staff-hover",
                    a.severity === "critical" || a.severity === "high" ? "border-l-red-500" : "border-l-amber-400"
                  )}
                >
                  <div className="min-w-0 flex-1">
                    <p className={cn("truncate text-[12.5px] font-medium", SEVERITY_COLOR[a.severity])}>
                      {a.description}
                    </p>
                    <p className="font-mono text-[10.5px] text-staff-subtle">
                      {a.alertNo} · {a.customerName} · {format(new Date(a.createdAt), "MMM d, HH:mm")}
                    </p>
                  </div>
                  <span className="rounded bg-staff-raised px-1.5 py-0.5 font-mono text-[10px] uppercase text-staff-subtle">
                    {a.type.replace("_", " ")}
                  </span>
                </button>
              </motion.li>
            ))}
          </ul>
        </Panel>
      </div>

      {/* Branch snapshot */}
      <Panel title="Branch snapshot">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[13px]">
            <thead className="bg-staff-raised text-staff-subtle">
              <tr>
                {["Branch", "Manager", "Deposits", "Open accounts today", "Staff"].map((h) => (
                  <th key={h} className="px-4 py-2.5 text-[11px] font-semibold uppercase tracking-[0.06em]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {BRANCHES.map((b, i) => (
                <tr key={b.code} className={cn("h-11 border-t border-staff-border hover:bg-staff-hover", i % 2 === 1 && "bg-staff-zebra")}>
                  <td className="px-4 py-2.5">
                    <span className="font-medium text-staff-text">{b.name}</span>{" "}
                    <span className="font-mono text-[11px] text-staff-subtle">({b.code})</span>
                  </td>
                  <td className="px-4 py-2.5 text-staff-subtle">{b.manager}</td>
                  <td className="px-4 py-2.5 font-mono tabular-nums text-staff-text">{compactMoney(b.deposits)}</td>
                  <td className="px-4 py-2.5 font-mono tabular-nums text-staff-text">{b.opened}</td>
                  <td className="px-4 py-2.5 font-mono tabular-nums text-staff-text">{b.staff}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}

export default function StaffDashboard() {
  return (
    <StaffLayout>
      <DashboardBody />
    </StaffLayout>
  );
}
