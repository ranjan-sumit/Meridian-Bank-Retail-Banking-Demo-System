import { Link } from "react-router";

const COLS = [
  {
    title: "Personal",
    links: ["Everyday Checking", "High-Yield Savings", "Certificates of Deposit", "Money Market", "Personal Loans"],
  },
  {
    title: "Cards & Lending",
    links: ["Platinum Rewards Card", "Debit Cards", "Home Mortgages", "Auto Loans", "Home Equity"],
  },
  {
    title: "Company",
    links: ["About Meridian", "Careers", "Branches & ATMs", "Newsroom", "Investor Relations"],
  },
  {
    title: "Support",
    links: ["Help Center", "Contact Us", "Security Center", "Accessibility", "Privacy Policy"],
  },
];

export default function Footer() {
  return (
    <footer className="bg-navy-deep text-slate-300">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-5">
          <div className="col-span-2 md:col-span-1">
            <img src="/logo.svg" alt="Meridian Bank" className="h-9 w-auto brightness-0 invert" />
            <p className="mt-4 text-xs leading-relaxed text-slate-400">
              Banking that moves at the speed of your life. Serving customers since 1924.
            </p>
            <p className="mt-3 font-mono text-[11px] text-slate-500">
              Routing Number 021000089 (demo)
            </p>
          </div>
          {COLS.map((col) => (
            <div key={col.title}>
              <h4 className="font-display text-[11px] font-semibold uppercase tracking-[0.08em] text-gold">
                {col.title}
              </h4>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l}>
                    <Link to="/login" className="text-[13px] text-slate-400 transition-colors hover:text-white">
                      {l}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 border-t border-white/10 pt-6">
          <p className="text-[11.5px] leading-relaxed text-slate-500">
            Member FDIC. Equal Housing Lender. Meridian Bank is a fictional demo institution — no real accounts,
            deposits, or financial services are offered. All data is simulated for demonstration purposes.
          </p>
          <div className="mt-3 flex flex-col justify-between gap-2 text-[11.5px] text-slate-500 sm:flex-row">
            <span>© 2025 Meridian Bank, N.A. All rights reserved.</span>
            <span>NMLS ID 402115 (demo) · Downtown HQ, 400 Meridian Ave</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
