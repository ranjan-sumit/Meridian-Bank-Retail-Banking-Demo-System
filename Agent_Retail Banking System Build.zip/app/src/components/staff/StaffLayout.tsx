import type { ReactNode } from "react";
import { Navigate, NavLink, useNavigate } from "react-router";
import {
  LayoutDashboard,
  Users,
  ShieldCheck,
  Radar,
  ScrollText,
  Landmark,
  CreditCard,
  Building2,
  Search,
  LogOut,
  ChevronDown,
} from "lucide-react";
import { useState } from "react";
import { Toaster } from "@/components/ui/sonner";
import { useSession } from "@/hooks/useSession";
import { STAFF_ROLES } from "@contracts/types";
import { cn } from "@/lib/utils";

const NAV_GROUPS: {
  label: string;
  items: { to: string; label: string; icon: typeof LayoutDashboard; end?: boolean }[];
}[] = [
  {
    label: "Overview",
    items: [{ to: "/staff", label: "Dashboard", icon: LayoutDashboard, end: true }],
  },
  {
    label: "Customers",
    items: [{ to: "/staff/customers", label: "Customers", icon: Users }],
  },
  {
    label: "Risk & Compliance",
    items: [
      { to: "/staff/kyc", label: "KYC Review", icon: ShieldCheck },
      { to: "/staff/monitoring", label: "Transaction Monitoring", icon: Radar },
      { to: "/staff/audit", label: "Audit Log", icon: ScrollText },
    ],
  },
  {
    label: "Operations",
    items: [
      { to: "/staff/loans", label: "Loans", icon: Landmark },
      { to: "/staff/cards", label: "Cards", icon: CreditCard },
    ],
  },
  {
    label: "Administration",
    items: [{ to: "/staff/employees", label: "Employees & Branches", icon: Building2 }],
  },
];

const ROLE_LABEL: Record<string, string> = {
  teller: "Teller",
  manager: "Manager",
  admin: "Admin",
};

function avatarFor(name: string): string | null {
  if (name.includes("Marcus")) return "/avatar-marcus.png";
  if (name.includes("Priya")) return "/avatar-priya.png";
  if (name.includes("Jordan")) return "/avatar-jordan.png";
  return null;
}

export default function StaffLayout({ children }: { children: ReactNode }) {
  const { user, role, isAuthenticated, logout } = useSession();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  if (!isAuthenticated || !user || !role || !STAFF_ROLES.includes(role)) {
    return <Navigate to="/staff/login" replace />;
  }

  const avatar = avatarFor(user.name);
  const initials = user.name
    .split(" ")
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <div className="theme-staff min-h-[100dvh] bg-staff-canvas font-sans text-[13.5px] text-staff-text">
      {/* Top bar */}
      <header className="fixed inset-x-0 top-0 z-40 flex h-14 items-center gap-4 border-b border-staff-border bg-staff-canvas/95 px-4 backdrop-blur">
        <div className="flex w-[204px] items-center gap-2.5">
          <img src="/logo-mark.svg" alt="Meridian" className="h-7 w-7 [filter:hue-rotate(120deg)_saturate(1.4)]" />
          <div className="leading-tight">
            <p className="text-[13px] font-semibold tracking-wide text-staff-text">
              Meridian <span className="text-staff-accent">Staff</span>
            </p>
            <p className="text-[10px] uppercase tracking-[0.08em] text-staff-subtle">
              Back Office Console
            </p>
          </div>
        </div>

        {/* Global search (visual) */}
        <button
          type="button"
          className="hidden h-8 w-72 items-center gap-2 rounded-md border border-staff-border bg-staff-panel px-3 text-[12.5px] text-staff-subtle transition hover:border-staff-accent/40 md:flex"
        >
          <Search className="h-3.5 w-3.5" />
          <span className="flex-1 text-left">Search customers, accounts, txns…</span>
          <kbd className="rounded border border-staff-border bg-staff-raised px-1.5 py-0.5 font-mono text-[10px] text-staff-subtle">
            ⌘K
          </kbd>
        </button>

        <div className="flex-1" />

        <span className="rounded border border-amber-400/30 bg-amber-400/10 px-2 py-0.5 font-mono text-[10.5px] font-semibold tracking-widest text-amber-300">
          DEMO
        </span>
        <span className="hidden rounded-full border border-staff-accent/30 bg-staff-accent/10 px-2.5 py-0.5 text-[11px] font-medium text-staff-accent sm:inline">
          {ROLE_LABEL[role] ?? role}
        </span>

        {/* Avatar menu */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setMenuOpen((o) => !o)}
            className="flex items-center gap-2 rounded-md px-1.5 py-1 transition hover:bg-staff-hover"
          >
            {avatar ? (
              <img src={avatar} alt={user.name} className="h-7 w-7 rounded-full object-cover ring-1 ring-staff-border" />
            ) : (
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-staff-accent/20 text-[11px] font-semibold text-staff-accent">
                {initials}
              </span>
            )}
            <span className="hidden text-left leading-tight lg:block">
              <span className="block text-[12.5px] font-medium text-staff-text">{user.name}</span>
              <span className="block font-mono text-[10px] text-staff-subtle">{user.username}</span>
            </span>
            <ChevronDown className="h-3.5 w-3.5 text-staff-subtle" />
          </button>
          {menuOpen && (
            <div className="absolute right-0 top-full mt-1 w-48 rounded-lg border border-staff-border bg-staff-raised p-1 shadow-xl">
              <button
                type="button"
                onClick={async () => {
                  await logout();
                  navigate("/staff/login");
                }}
                className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-[12.5px] text-red-300 transition hover:bg-red-500/10"
              >
                <LogOut className="h-3.5 w-3.5" /> Sign out
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Sidebar */}
      <aside className="fixed bottom-0 left-0 top-14 z-30 w-[220px] overflow-y-auto border-r border-staff-border bg-staff-sidebar px-3 py-4">
        {NAV_GROUPS.map((group) => (
          <div key={group.label} className="mb-5">
            <p className="mb-1.5 px-2 text-[10px] font-semibold uppercase tracking-[0.1em] text-staff-subtle/70">
              {group.label}
            </p>
            <nav className="space-y-0.5">
              {group.items.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.end}
                  className={({ isActive }) =>
                    cn(
                      "flex items-center gap-2.5 rounded-md border-l-2 px-2.5 py-2 text-[12.5px] font-medium transition-colors duration-150",
                      isActive
                        ? "border-staff-accent bg-staff-accent/10 text-staff-accent"
                        : "border-transparent text-staff-subtle hover:bg-staff-hover hover:text-staff-text"
                    )
                  }
                >
                  <item.icon className="h-4 w-4 shrink-0" />
                  {item.label}
                </NavLink>
              ))}
            </nav>
          </div>
        ))}
        <p className="mt-8 border-t border-staff-border px-2 pt-3 font-mono text-[10px] leading-relaxed text-staff-subtle/60">
          Meridian Bank is a fictional demo institution. All activity is logged.
        </p>
      </aside>

      {/* Content */}
      <main className="ml-[220px] mt-14 min-h-[calc(100dvh-56px)] p-6">{children}</main>

      <Toaster theme="dark" position="top-right" richColors />
    </div>
  );
}
