import { useState } from "react";
import { useSearchParams } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, CheckCircle2, X } from "lucide-react";
import { toast } from "sonner";
import BankingLayout from "@/components/banking/BankingLayout";
import StatusBadge from "@/components/shared/StatusBadge";
import { trpc } from "@/providers/trpc";
import { fmtMoney, fmtDate, num, statusLabel } from "@/components/banking/format";
import { cn } from "@/lib/utils";

const monthlyPayment = (amount: number, apr: number, months: number) => {
  const r = apr / 1200;
  return r > 0 ? (amount * r) / (1 - Math.pow(1 + r, -months)) : amount / months;
};

export default function Loans() {
  const [params, setParams] = useSearchParams();
  const tab = params.get("apply") === "1" ? "apply" : "my";
  const setTab = (t: "my" | "apply") => setParams(t === "apply" ? { apply: "1" } : {});

  return (
    <BankingLayout>
      <h1 className="font-display text-[28px] font-bold text-navy">Loans</h1>
      <div className="mt-4 flex gap-6 border-b border-slate-200">
        {(
          [
            ["my", "My Loans"],
            ["apply", "Apply for a Loan"],
          ] as const
        ).map(([v, label]) => (
          <button
            key={v}
            onClick={() => setTab(v)}
            className={cn(
              "relative pb-2.5 text-sm font-medium transition",
              tab === v ? "text-navy" : "text-subtle hover:text-navy"
            )}
          >
            {label}
            {tab === v && <motion.span layoutId="loans-tab" className="absolute inset-x-0 -bottom-px h-0.5 bg-gold" />}
          </button>
        ))}
      </div>
      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, x: tab === "apply" ? 24 : -24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
        >
          {tab === "my" ? <MyLoans /> : <ApplyWizard onDone={() => setTab("my")} />}
        </motion.div>
      </AnimatePresence>
    </BankingLayout>
  );
}

function MyLoans() {
  const q = trpc.customer.listLoans.useQuery();
  const [expanded, setExpanded] = useState<number | null>(null);
  const [payOpen, setPayOpen] = useState(false);
  const [payAmt, setPayAmt] = useState("");
  const [extraPrincipal, setExtraPrincipal] = useState(false);

  if (q.isLoading)
    return <div className="mt-6 h-72 animate-pulse rounded-xl border border-slate-200 bg-white" />;
  if (q.isError)
    return (
      <div className="mt-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-[#B42318]">
        Couldn't load loans.
      </div>
    );

  const loans = q.data ?? [];
  const active = loans.filter((l) => l.status === "active");
  const others = loans.filter((l) => l.status !== "active");

  return (
    <div className="mt-6 space-y-6">
      {active.map((loan) => {
        const principal = num(loan.principal);
        const remaining = num(loan.remainingBalance);
        const paidPct = Math.min(100, Math.max(0, (1 - remaining / principal) * 100));
        const upcoming = loan.schedule.filter((p) => p.status !== "paid");
        const hist = loan.schedule.filter((p) => p.status === "paid").slice(-6).reverse();
        return (
          <div key={loan.id} className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="font-display text-lg font-semibold text-navy">{loan.product.name}</h2>
                  <StatusBadge status={statusLabel(loan.status)} />
                </div>
                <p className="mt-0.5 font-mono text-xs text-subtle">{loan.loanNo}</p>
                <p className="mt-1 text-sm text-subtle">
                  128 Willow Creek Dr, Jersey City, NJ · {num(loan.rateApr).toFixed(2)}% fixed
                </p>
              </div>
              <div className="text-right">
                <p className="text-[11px] uppercase tracking-[0.06em] text-slate-500">Remaining balance</p>
                <p className="font-display text-[28px] font-bold tabular-nums text-navy">
                  {fmtMoney(remaining)}
                </p>
                <p className="text-xs text-subtle">of {fmtMoney(principal)} original</p>
              </div>
            </div>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-100">
              <motion.div
                className="h-full rounded-full bg-navy"
                initial={{ width: 0 }}
                animate={{ width: `${paidPct}%` }}
                transition={{ duration: 0.9, ease: "easeOut" }}
              />
            </div>
            <p className="mt-1 text-xs text-subtle tabular-nums">{paidPct.toFixed(1)}% paid</p>

            {loan.nextPayment && (
              <div className="mt-5 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-amber-200 bg-amber-50/60 p-4">
                <div>
                  <p className="text-sm font-semibold text-navy">
                    Next payment: {fmtMoney(loan.nextPayment.amount)} due {fmtDate(loan.nextPayment.dueDate)}
                  </p>
                  <p className="mt-0.5 text-xs text-subtle tabular-nums">
                    Principal {fmtMoney(loan.nextPayment.principalPart)} · Interest{" "}
                    {fmtMoney(loan.nextPayment.interestPart)} · Escrow $200.00
                  </p>
                </div>
                <button
                  onClick={() => {
                    setPayAmt(num(loan.nextPayment!.amount).toFixed(2));
                    setPayOpen(true);
                  }}
                  className="rounded-lg bg-navy px-4 py-2 text-sm font-semibold text-white transition hover:bg-navy-deep"
                >
                  Make a payment
                </button>
              </div>
            )}

            <div className="mt-5 grid grid-cols-3 gap-4 text-center">
              {[
                ["Payoff date", "Aug 2049"],
                ["Payments made", `${loan.schedule.filter((p) => p.status === "paid").length}/${loan.termMonths}`],
                ["YTD interest", "$4,512.30"],
              ].map(([k, v]) => (
                <div key={k} className="rounded-lg bg-slate-50 p-3">
                  <p className="text-[11px] uppercase tracking-[0.06em] text-slate-500">{k}</p>
                  <p className="mt-1 font-medium tabular-nums text-body">{v}</p>
                </div>
              ))}
            </div>

            {/* Amortization schedule */}
            <button
              onClick={() => setExpanded(expanded === loan.id ? null : loan.id)}
              className="mt-5 flex items-center gap-1.5 text-sm font-semibold text-navy hover:underline"
            >
              Amortization schedule
              <ChevronDown className={cn("h-4 w-4 transition-transform", expanded === loan.id && "rotate-180")} />
            </button>
            <AnimatePresence>
              {expanded === loan.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <table className="mt-3 w-full text-sm">
                    <thead>
                      <tr className="text-left text-[11px] uppercase tracking-[0.06em] text-slate-500">
                        {["Due", "Payment", "Principal", "Interest", "Status"].map((h) => (
                          <th key={h} className="px-3 py-2 font-medium">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {upcoming.slice(0, 12).map((p, i) => (
                        <motion.tr
                          key={p.id}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: i * 0.03 }}
                          className="border-t border-slate-50"
                        >
                          <td className="px-3 py-2 text-subtle">{fmtDate(p.dueDate, "MMM yyyy")}</td>
                          <td className="px-3 py-2 tabular-nums text-body">{fmtMoney(p.amount)}</td>
                          <td className="px-3 py-2 tabular-nums text-body">{fmtMoney(p.principalPart)}</td>
                          <td className="px-3 py-2 tabular-nums text-body">{fmtMoney(p.interestPart)}</td>
                          <td className="px-3 py-2">
                            <StatusBadge status={p.status === "due" ? "Pending" : statusLabel(p.status)} />
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                  <p className="mt-2 text-xs text-subtle">
                    Showing next 12 of {upcoming.length} remaining payments.
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* History */}
            <h3 className="mt-6 text-[11px] font-semibold uppercase tracking-[0.06em] text-slate-500">
              Payment history
            </h3>
            <ul className="mt-2 divide-y divide-slate-50 text-sm">
              {hist.map((p) => (
                <li key={p.id} className="flex items-center justify-between py-2">
                  <span className="text-subtle">{fmtDate(p.dueDate, "MMM d, yyyy")}</span>
                  <span className="tabular-nums text-body">{fmtMoney(p.amount)}</span>
                  <StatusBadge status="Paid Off" />
                </li>
              ))}
              {hist.length === 0 && <li className="py-3 text-subtle">No payments yet.</li>}
            </ul>
          </div>
        );
      })}

      {others.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="font-display text-[15px] font-semibold text-navy">Other applications</h3>
          <ul className="mt-3 space-y-2.5 text-sm">
            {others.map((l) => (
              <li key={l.id} className="flex flex-wrap items-center gap-3 rounded-lg bg-slate-50 px-4 py-3">
                <span className="font-mono text-xs text-subtle">{l.loanNo}</span>
                <span className="text-body">
                  {l.product.name} — {fmtMoney(l.principal)} @ {num(l.rateApr).toFixed(1)}%
                </span>
                <StatusBadge status={statusLabel(l.status)} />
                {l.status === "rejected" && (
                  <span className="text-xs text-subtle">Nov 2024 · Reason: debt-to-income ratio</span>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Payment modal */}
      <AnimatePresence>
        {payOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end justify-center bg-navy-deep/50 p-4 sm:items-center"
            onClick={() => setPayOpen(false)}
          >
            <motion.div
              initial={{ y: 48, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 32, opacity: 0 }}
              transition={{ type: "spring", damping: 26, stiffness: 300 }}
              className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between">
                <h3 className="font-display text-lg font-semibold text-navy">Make a loan payment</h3>
                <button onClick={() => setPayOpen(false)} className="text-slate-400 hover:text-navy">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <input
                value={payAmt}
                onChange={(e) => setPayAmt(e.target.value.replace(/[^0-9.]/g, ""))}
                className="mt-4 h-11 w-full rounded-lg border border-slate-300 px-3 text-lg tabular-nums outline-none focus:border-navy"
              />
              <label className="mt-3 flex items-center gap-2 text-sm text-body">
                <input
                  type="checkbox"
                  checked={extraPrincipal}
                  onChange={(e) => setExtraPrincipal(e.target.checked)}
                  className="accent-[#0B2545]"
                />
                Apply extra to principal
              </label>
              <select className="mt-3 h-11 w-full rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-navy">
                <option>Everyday Checking •••• 4821</option>
                <option>High-Yield Savings •••• 9034</option>
              </select>
              <button
                onClick={() => {
                  setPayOpen(false);
                  toast.success("Payment scheduled", { description: `${fmtMoney(payAmt)} will post on the next business day.` });
                }}
                className="mt-5 h-11 w-full rounded-lg bg-gold font-semibold text-navy transition hover:bg-gold-hover"
              >
                Confirm payment
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ApplyWizard({ onDone }: { onDone: () => void }) {
  const productsQ = trpc.customer.listLoanProducts.useQuery();
  const utils = trpc.useUtils();
  const apply = trpc.customer.applyForLoan.useMutation({
    onError: (e) => toast.error("Application failed", { description: e.message }),
  });

  const [step, setStep] = useState(0);
  const [productId, setProductId] = useState<number | null>(null);
  const [amount, setAmount] = useState(15000);
  const [term, setTerm] = useState(48);
  const [purpose, setPurpose] = useState("Debt consolidation");
  const [employment, setEmployment] = useState("Full-time employed");
  const [income, setIncome] = useState("118000");
  const [housing, setHousing] = useState("2412");
  const [consent, setConsent] = useState(false);
  const [result, setResult] = useState<{ loanNo: string } | null>(null);

  const product = (productsQ.data ?? []).find((p) => p.id === productId) ?? null;
  const apr = product ? num(product.rateApr) : 9.9;
  const pmt = monthlyPayment(amount, apr, term);

  if (result) {
    return (
      <div className="mx-auto mt-10 max-w-md rounded-xl border border-slate-200 bg-white p-8 text-center shadow-sm">
        <motion.div
          initial={{ scale: 0.5 }}
          animate={{ scale: [0.5, 1.1, 1] }}
          transition={{ duration: 0.5 }}
          className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-amber-50"
        >
          <CheckCircle2 className="h-9 w-9 text-gold" />
        </motion.div>
        <h2 className="mt-4 font-display text-xl font-bold text-navy">
          Application <span className="font-mono">{result.loanNo}</span> received
        </h2>
        <div className="mt-3">
          <StatusBadge status="Pending" />
        </div>
        <p className="mt-3 text-sm text-subtle">
          Typical decision within 2 business days. Track status under My Loans.
        </p>
        <button
          onClick={onDone}
          className="mt-6 rounded-lg bg-navy px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-navy-deep"
        >
          Back to My Loans
        </button>
      </div>
    );
  }

  return (
    <div className="mx-auto mt-6 max-w-[720px] rounded-xl border border-slate-200 bg-white shadow-sm">
      {/* progress */}
      <div className="border-b border-slate-100 p-5">
        <div className="flex justify-between text-[11px] font-medium uppercase tracking-[0.06em] text-slate-500">
          <span className={step >= 0 ? "text-navy" : ""}>1 · Product</span>
          <span className={step >= 1 ? "text-navy" : ""}>2 · Details</span>
          <span className={step >= 2 ? "text-navy" : ""}>3 · Review &amp; submit</span>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100">
          <motion.div
            className="h-full rounded-full bg-gold"
            animate={{ width: `${((step + 1) / 3) * 100}%` }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          />
        </div>
      </div>

      <AnimatePresence mode="wait">
        {step === 0 && (
          <motion.div key="p0" initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} className="space-y-3 p-6">
            {productsQ.isLoading && <div className="h-24 animate-pulse rounded-lg bg-slate-50" />}
            {(productsQ.data ?? []).map((p) => {
              const min = num(p.minAmount);
              const max = num(p.maxAmount);
              return (
                <button
                  key={p.id}
                  onClick={() => {
                    setProductId(p.id);
                    setAmount(Math.min(Math.max(amount, min), max));
                  }}
                  className={cn(
                    "w-full rounded-xl border p-4 text-left transition",
                    productId === p.id ? "border-gold bg-amber-50/40" : "border-slate-200 hover:border-navy/40"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-navy">{p.name}</p>
                    {productId === p.id && <CheckCircle2 className="h-5 w-5 text-gold" />}
                  </div>
                  <p className="mt-0.5 text-xs text-subtle">
                    {fmtMoney(min)}–{fmtMoney(max)} · from {num(p.rateApr).toFixed(1)}% APR · up to {p.termMonths} months
                  </p>
                </button>
              );
            })}

            {/* live calculator */}
            <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-5">
              <div className="flex justify-between text-sm">
                <label className="font-medium text-navy">Amount</label>
                <span className="font-semibold tabular-nums text-navy">{fmtMoney(amount)}</span>
              </div>
              <input
                type="range"
                min={product ? num(product.minAmount) : 5000}
                max={product ? num(product.maxAmount) : 50000}
                step={500}
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="mt-2 w-full accent-[#C9A227]"
              />
              <div className="mt-4 flex justify-between text-sm">
                <label className="font-medium text-navy">Term</label>
                <span className="font-semibold tabular-nums text-navy">{term} months</span>
              </div>
              <input
                type="range"
                min={12}
                max={product?.termMonths ?? 72}
                step={6}
                value={term}
                onChange={(e) => setTerm(Number(e.target.value))}
                className="mt-2 w-full accent-[#C9A227]"
              />
              <p className="mt-4 text-center text-sm text-subtle">
                {fmtMoney(amount)} / {term} mo @ {apr.toFixed(1)}% ={" "}
                <span className="font-display text-lg font-bold tabular-nums text-navy">
                  {fmtMoney(pmt)}/mo
                </span>
              </p>
            </div>

            <button
              disabled={productId == null}
              onClick={() => setStep(1)}
              className="h-11 w-full rounded-lg bg-gold font-semibold text-navy transition hover:bg-gold-hover disabled:opacity-40"
            >
              Continue
            </button>
          </motion.div>
        )}

        {step === 1 && (
          <motion.div key="p1" initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} className="space-y-4 p-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1.5 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">Amount</label>
                <input
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value.replace(/[^0-9]/g, "")) || 0)}
                  className="h-11 w-full rounded-lg border border-slate-300 px-3 tabular-nums outline-none focus:border-navy"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">Purpose</label>
                <select
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  className="h-11 w-full rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-navy"
                >
                  {["Debt consolidation", "Home improvement", "Major purchase", "Other"].map((p) => (
                    <option key={p}>{p}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">Employment</label>
                <select
                  value={employment}
                  onChange={(e) => setEmployment(e.target.value)}
                  className="h-11 w-full rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-navy"
                >
                  {["Full-time employed", "Part-time employed", "Self-employed", "Retired"].map((p) => (
                    <option key={p}>{p}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">Annual income ($)</label>
                <input
                  value={income}
                  onChange={(e) => setIncome(e.target.value.replace(/[^0-9]/g, ""))}
                  className="h-11 w-full rounded-lg border border-slate-300 px-3 tabular-nums outline-none focus:border-navy"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium uppercase tracking-[0.06em] text-slate-500">Housing payment / month ($)</label>
                <input
                  value={housing}
                  onChange={(e) => setHousing(e.target.value.replace(/[^0-9.]/g, ""))}
                  className="h-11 w-full rounded-lg border border-slate-300 px-3 tabular-nums outline-none focus:border-navy"
                />
              </div>
            </div>
            <label className="flex items-start gap-2 text-sm text-body">
              <input
                type="checkbox"
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
                className="mt-0.5 accent-[#0B2545]"
              />
              I authorize Meridian Bank to obtain my credit report to evaluate this application.
            </label>
            <div className="flex gap-3">
              <button onClick={() => setStep(0)} className="h-11 flex-1 rounded-lg border border-slate-300 font-medium text-navy">
                Back
              </button>
              <button
                disabled={!consent || amount <= 0}
                onClick={() => setStep(2)}
                className="h-11 flex-1 rounded-lg bg-gold font-semibold text-navy transition hover:bg-gold-hover disabled:opacity-40"
              >
                Review application
              </button>
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div key="p2" initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} className="p-6">
            <dl className="space-y-2.5 rounded-xl border border-slate-200 bg-slate-50/60 p-5 text-sm">
              {[
                ["Product", product?.name ?? "—"],
                ["Amount", fmtMoney(amount)],
                ["Term", `${term} months`],
                ["Estimated APR", `${apr.toFixed(2)}%`],
                ["Estimated payment", `${fmtMoney(pmt)}/mo`],
                ["Purpose", purpose],
                ["Annual income", fmtMoney(income)],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <dt className="text-subtle">{k}</dt>
                  <dd className="font-medium tabular-nums text-body">{v}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-4 text-[11px] leading-relaxed text-slate-400">
              Submitting this application authorizes a hard credit inquiry. Rates shown are estimates; final
              terms depend on creditworthiness. Fictional demo — no real application is filed.
            </p>
            <div className="mt-5 flex gap-3">
              <button onClick={() => setStep(1)} className="h-11 flex-1 rounded-lg border border-slate-300 font-medium text-navy">
                Back
              </button>
              <button
                disabled={apply.isPending || productId == null}
                onClick={() =>
                  apply.mutate(
                    { productId: productId!, amount, termMonths: term, purpose },
                    {
                      onSuccess: (res) => {
                        setResult({ loanNo: res.loanNo });
                        utils.customer.listLoans.invalidate();
                        toast.success("Application submitted");
                      },
                    }
                  )
                }
                className="h-11 flex-1 rounded-lg bg-gold font-semibold text-navy transition hover:bg-gold-hover disabled:opacity-40"
              >
                {apply.isPending ? "Submitting…" : "Submit application"}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
