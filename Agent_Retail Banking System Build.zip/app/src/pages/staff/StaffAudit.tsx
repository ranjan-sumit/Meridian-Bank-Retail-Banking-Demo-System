import { useEffect, useMemo, useState } from "react";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { toast, Toaster } from "sonner";
import { Search, Download, Link2, ShieldCheck, ArrowRight, RefreshCw } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useSession } from "@/hooks/useSession";
import StatusBadge from "@/components/shared/StatusBadge";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

type AuditEntry = {
  id: number;
  actorType: "customer" | "staff" | "system";
  actorName: string;
  action: string;
  entityType: string;
  entityId: string;
  detail: string | null;
  prevHash: string;
  hash: string;
  createdAt: Date;
};

const MODULES = ["All", "Accounts", "KYC", "Loans", "Cards", "Transfers", "Employees", "Auth", "Monitoring"];
const CRITICAL_ACTIONS = ["login_failed", "rule_trigger", "card.blocked", "alert.status_changed"];

function severityOf(e: AuditEntry): "info" | "warning" | "critical" {
  const a = e.action.toLowerCase();
  if (a.includes("failed") || a.includes("rule_trigger") || e.actorType === "system") return "critical";
  if (a.includes("block") || a.includes("reject") || a.includes("role") || a.includes("export") || a.includes("escalat")) return "warning";
  return "info";
}
const SEV_BORDER = { info: "border-l-transparent", warning: "border-l-amber-400", critical: "border-l-red-500" } as const;
const SEV_CHIP = {
  info: "bg-slate-500/20 text-slate-300",
  warning: "bg-amber-500/15 text-amber-300",
  critical: "bg-red-500/15 text-red-300",
} as const;

export default function StaffAudit() {
  const { role } = useSession();
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [actorType, setActorType] = useState("all");
  const [module, setModule] = useState("All");
  const [severity, setSeverity] = useState("all");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<AuditEntry | null>(null);
  const [showNewPill, setShowNewPill] = useState(false);

  const auditQuery = trpc.staff.auditLog.useQuery({
    page,
    search: search || undefined,
    actorType: actorType === "all" ? undefined : (actorType as "staff"),
  }, { refetchInterval: 30_000 });

  // Simulated live-poll pill (30s cadence matches refetchInterval).
  useEffect(() => {
    const t = setTimeout(() => setShowNewPill(true), 30_000);
    return () => clearTimeout(t);
  }, []);

  // Maker-checker sources
  const cardReqQuery = trpc.staff.cardRequests.useQuery();
  const kycQueueQuery = trpc.staff.kycQueue.useQuery({});
  const reviewKyc = trpc.staff.reviewKyc.useMutation({
    onSuccess: () => { toast.success("EDD case counter-approved"); void utils.staff.kycQueue.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const decideCard = trpc.staff.decideCardRequest.useMutation({
    onSuccess: () => { toast.success("Card request counter-approved"); void utils.staff.cardRequests.invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  const entries = (auditQuery.data?.entries ?? []) as AuditEntry[];
  const total = auditQuery.data?.total ?? 0;

  const filtered = useMemo(() => {
    let list = entries;
    if (module !== "All") list = list.filter((e) => e.entityType.toLowerCase().includes(module.toLowerCase()) || e.action.toLowerCase().startsWith(module.toLowerCase().slice(0, 4)));
    if (severity !== "all") list = list.filter((e) => severityOf(e) === severity);
    return list;
  }, [entries, module, severity]);

  const eddPending = (kycQueueQuery.data ?? []).filter((k) => k.level === "enhanced");
  const cardPending = cardReqQuery.data ?? [];
  const isAdmin = role === "admin";

  const exportCsv = () => {
    const header = "timestamp,actorType,actor,action,entityType,entityId,detail,hash";
    const lines = filtered.map((e) =>
      [format(new Date(e.createdAt), "yyyy-MM-dd HH:mm:ss"), e.actorType, e.actorName, e.action, e.entityType, e.entityId, JSON.stringify(e.detail ?? ""), e.hash].join(",")
    );
    const blob = new Blob([[header, ...lines].join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "meridian-audit-export.csv";
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${filtered.length} rows — this export is itself logged`);
  };

  return (
    <div className="space-y-5">
      <Toaster position="top-right" theme="dark" richColors />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-semibold text-staff-text">Audit Log</h1>
          <p className="text-xs text-staff-subtle">Immutable, append-only · hash-chained · {total.toLocaleString()} events</p>
        </div>
        <button
          onClick={exportCsv}
          className="flex items-center gap-1.5 rounded-lg border border-staff-border bg-staff-panel px-3.5 py-2 text-xs font-medium text-staff-text hover:border-[#2DD4A8]/40"
        >
          <Download className="h-3.5 w-3.5" /> Export CSV
        </button>
      </div>

      {/* Maker-checker panel */}
      <div className="rounded-xl border border-staff-border bg-staff-panel p-4">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-[#2DD4A8]" />
          <span className="text-sm font-semibold text-staff-text">Pending counter-approvals</span>
          <span className="rounded-full bg-[#2DD4A8]/15 px-2 py-0.5 font-mono text-[11px] text-[#2DD4A8]">{eddPending.length + cardPending.length}</span>
          {!isAdmin && <span className="ml-auto text-[11px] text-staff-subtle">Read-only — final approval requires Admin role</span>}
        </div>
        {eddPending.length + cardPending.length === 0 ? (
          <p className="mt-2 text-[12.5px] text-staff-subtle">Nothing awaiting counter-approval.</p>
        ) : (
          <div className="mt-3 space-y-2">
            {eddPending.map((k) => (
              <div key={k.caseNo} className="flex items-center gap-3 rounded-lg border border-staff-border bg-staff-raised px-3 py-2 text-[12.5px]">
                <span className="font-mono text-[#2DD4A8]">{k.caseNo}</span>
                <span className="text-staff-text">EDD KYC — {k.customer.firstName} {k.customer.lastName}</span>
                <span className="text-staff-subtle">needs Admin final approval</span>
                {isAdmin && (
                  <button
                    disabled={reviewKyc.isPending}
                    onClick={() => reviewKyc.mutate({ caseId: k.id, approve: true })}
                    className="ml-auto rounded-md bg-[#2DD4A8] px-3 py-1 text-xs font-semibold text-[#0B1118] disabled:opacity-40"
                  >
                    Approve
                  </button>
                )}
              </div>
            ))}
            {cardPending.map((c) => (
              <div key={c.id} className="flex items-center gap-3 rounded-lg border border-staff-border bg-staff-raised px-3 py-2 text-[12.5px]">
                <span className="font-mono text-[#2DD4A8]">CRD-REQ-{String(c.id).padStart(4, "0")}</span>
                <span className="text-staff-text">{c.type === "credit" ? "Credit card" : "Debit card"} issuance — {c.customerName}</span>
                <span className="text-staff-subtle">needs Admin counter-approval</span>
                {isAdmin && (
                  <button
                    disabled={decideCard.isPending}
                    onClick={() => decideCard.mutate({ cardId: c.id, approve: true })}
                    className="ml-auto rounded-md bg-[#2DD4A8] px-3 py-1 text-xs font-semibold text-[#0B1118] disabled:opacity-40"
                  >
                    Approve
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Filter bar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-staff-subtle" />
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search actor, action, entity…"
            className="w-64 rounded-lg border border-staff-border bg-staff-panel py-2 pl-8 pr-3 text-[12.5px] text-staff-text placeholder:text-staff-subtle focus:outline-none focus:ring-1 focus:ring-[#2DD4A8]"
          />
        </div>
        <Select value={actorType} onValueChange={(v) => { setActorType(v); setPage(1); }}>
          <SelectTrigger className="h-9 w-32 border-staff-border bg-staff-panel text-xs text-staff-text"><SelectValue /></SelectTrigger>
          <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
            {["all", "staff", "customer", "system"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s === "all" ? "All actors" : s}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={module} onValueChange={setModule}>
          <SelectTrigger className="h-9 w-36 border-staff-border bg-staff-panel text-xs text-staff-text"><SelectValue /></SelectTrigger>
          <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
            {MODULES.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={severity} onValueChange={setSeverity}>
          <SelectTrigger className="h-9 w-32 border-staff-border bg-staff-panel text-xs text-staff-text"><SelectValue /></SelectTrigger>
          <SelectContent className="border-staff-border bg-staff-raised text-staff-text">
            {["all", "info", "warning", "critical"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s === "all" ? "All severities" : s}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="ml-auto flex items-center gap-2 text-xs text-staff-subtle">
          <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="rounded border border-staff-border px-2 py-1 disabled:opacity-30">Prev</button>
          <span className="font-mono tabular-nums">{page} / {Math.max(1, Math.ceil(total / 20))}</span>
          <button disabled={page * 20 >= total} onClick={() => setPage((p) => p + 1)} className="rounded border border-staff-border px-2 py-1 disabled:opacity-30">Next</button>
        </div>
      </div>

      {/* New events pill */}
      <AnimatePresence>
        {showNewPill && (
          <motion.button
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            onClick={() => { setShowNewPill(false); void auditQuery.refetch(); }}
            className="flex items-center gap-1.5 rounded-full border border-[#2DD4A8]/40 bg-[#2DD4A8]/10 px-3 py-1 text-xs text-[#2DD4A8]"
          >
            <RefreshCw className="h-3 w-3" /> Check for new events
          </motion.button>
        )}
      </AnimatePresence>

      {/* Log table */}
      {auditQuery.isLoading ? (
        <div className="space-y-2 rounded-xl border border-staff-border bg-staff-panel p-4">
          {Array.from({ length: 10 }).map((_, i) => <Skeleton key={i} className="h-10 w-full bg-staff-raised" />)}
        </div>
      ) : auditQuery.isError ? (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-6 text-sm text-red-300">Failed to load audit log: {auditQuery.error.message}</div>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-staff-border bg-staff-panel p-10 text-center text-sm text-staff-subtle">No audit events match the filters.</div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-staff-border bg-staff-panel">
          <table className="w-full text-left text-[12.5px]">
            <thead className="bg-staff-raised text-[11px] uppercase tracking-[0.06em] text-staff-subtle">
              <tr>
                <th className="px-4 py-2.5">Timestamp</th>
                <th className="px-4 py-2.5">Event</th>
                <th className="px-4 py-2.5">Actor</th>
                <th className="px-4 py-2.5">Module</th>
                <th className="px-4 py-2.5">Target</th>
                <th className="px-4 py-2.5">Details</th>
                <th className="px-4 py-2.5">Severity</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((e, i) => {
                const sev = severityOf(e);
                return (
                  <motion.tr
                    key={e.id}
                    initial={i < 15 ? { opacity: 0 } : false}
                    animate={{ opacity: 1 }}
                    transition={{ delay: Math.min(i, 15) * 0.02 }}
                    onClick={() => setSelected(e)}
                    className={cn("cursor-pointer border-t border-l-[3px] border-staff-border transition hover:bg-staff-hover", SEV_BORDER[sev], i % 2 === 1 && "bg-staff-zebra")}
                  >
                    <td className="px-4 py-2.5 font-mono text-[11.5px] tabular-nums text-staff-subtle">{format(new Date(e.createdAt), "yyyy-MM-dd HH:mm:ss")}</td>
                    <td className="px-4 py-2.5">
                      <span className="font-mono text-[11.5px] text-[#2DD4A8]">EVT-{e.id}</span>
                      <span className="ml-2 font-mono text-[11.5px] uppercase text-staff-text">{e.action}</span>
                    </td>
                    <td className="px-4 py-2.5">
                      <span className="text-staff-text">{e.actorName}</span>
                      <span className="ml-1.5 text-[10.5px] capitalize text-staff-subtle">{e.actorType}</span>
                    </td>
                    <td className="px-4 py-2.5 capitalize text-staff-subtle">{e.entityType}</td>
                    <td className="px-4 py-2.5 font-mono text-[11.5px] text-staff-subtle">{e.entityId}</td>
                    <td className="max-w-[260px] truncate px-4 py-2.5 text-staff-subtle">{e.detail ?? "—"}</td>
                    <td className="px-4 py-2.5">
                      <span className={cn("rounded-full px-2 py-0.5 text-[10.5px] font-semibold uppercase", SEV_CHIP[sev])}>{sev}</span>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Detail drawer with hash chain */}
      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <SheetContent side="right" className="w-full border-l border-staff-border bg-staff-panel text-staff-text sm:max-w-[440px]">
          {selected && (
            <>
              <SheetHeader>
                <SheetTitle className="font-mono text-sm text-[#2DD4A8]">EVT-{selected.id} · {selected.action}</SheetTitle>
                <SheetDescription className="text-staff-subtle">
                  {format(new Date(selected.createdAt), "MMMM d, yyyy · HH:mm:ss")}
                </SheetDescription>
              </SheetHeader>
              <div className="mt-4 space-y-4 px-1">
                <div className="space-y-1.5 rounded-lg border border-staff-border bg-staff-raised p-4 text-[12.5px]">
                  {[
                    ["Actor", `${selected.actorName} (${selected.actorType})`],
                    ["Module", selected.entityType],
                    ["Target", selected.entityId],
                    ["Severity", severityOf(selected)],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between gap-3">
                      <span className="text-staff-subtle">{k}</span>
                      <span className="text-right font-medium capitalize text-staff-text">{v}</span>
                    </div>
                  ))}
                </div>
                {selected.detail && (
                  <div className="rounded-lg border border-staff-border bg-staff-raised p-4">
                    <div className="mb-1 text-[11px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">Details</div>
                    <p className="text-[12.5px] text-staff-text">{selected.detail}</p>
                    <p className="mt-2 text-[11px] text-staff-subtle">IP 10.24.18.6 · Meridian Staff Console (Chrome 133)</p>
                  </div>
                )}
                {/* Hash chain */}
                <div className="rounded-lg border border-staff-border bg-staff-raised p-4">
                  <div className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.06em] text-staff-subtle">
                    <Link2 className="h-3.5 w-3.5" /> Tamper-evidence chain (SHA-256)
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 font-mono text-[11px]">
                    <span className="rounded border border-staff-border bg-staff-canvas px-2 py-1 text-staff-subtle" title={selected.prevHash}>
                      prev {selected.prevHash.slice(0, 6)}…{selected.prevHash.slice(-4)}
                    </span>
                    <ArrowRight className="h-3.5 w-3.5 text-[#2DD4A8]" />
                    <span className="rounded border border-[#2DD4A8]/40 bg-[#2DD4A8]/10 px-2 py-1 text-[#2DD4A8]" title={selected.hash}>
                      {selected.hash.slice(0, 6)}…{selected.hash.slice(-4)}
                    </span>
                  </div>
                  <p className="mt-2 text-[11px] text-staff-subtle">Each entry commits to the previous entry's hash — any tampering breaks the chain.</p>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
